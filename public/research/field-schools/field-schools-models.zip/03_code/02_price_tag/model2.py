"""Price-tag model: ambiguity, extension, and the market for advice."""
import numpy as np
from math import erf, sqrt

from config2 import Config, price_path, budget_path

XG = np.linspace(0.0, 1.0, 11)


def phi_cdf(z):
    z = np.clip(np.asarray(z, dtype=float), -8.0, 8.0)
    return 0.5 * (1.0 + np.vectorize(erf)(z / sqrt(2.0)))


class Model:
    def __init__(self, cfg: Config):
        self.cfg = cfg
        S = cfg.S
        rng = np.random.default_rng(cfg.seed)
        self.rng = rng
        n = cfg.n

        self.village = rng.integers(0, cfg.n_villages, n)
        virr = S["irr0"] * np.exp(-S["irr_decay"] * np.arange(cfg.n_villages) / cfg.n_villages)
        self.sys = np.zeros(n, dtype=int)
        for v in range(cfg.n_villages):
            idx = self.village == v
            u = rng.random(idx.sum())
            self.sys[idx] = np.where(u < virr[v], 0, np.where(u < virr[v] + S["rain_split"], 1, 2))
        self.irr = (self.sys == 0).astype(float)

        self.L = np.clip(rng.lognormal(np.log(S["land_mean"]), cfg.land_sig, n), 0.2, 8.0)
        self.wealth = rng.lognormal(np.log(S["wealth_med"]), cfg.wealth_sig, n)
        A = np.array([S["A_mean"][s] for s in self.sys]) * np.exp(rng.normal(0, 0.12, n))
        self.A = A
        self.m_base = np.clip(rng.beta(cfg.m_alpha, cfg.m_beta, n), 0.15, 1.0)
        self.m_prog = np.zeros(n)          # program-specific skill, decays
        self.m = self.m_base + self.m_prog

        self.rho = (cfg.sigma - 1.0) / cfg.sigma
        self.delta = 1.0 - cfg.trad_share ** self.rho
        self.kappa = np.full(n, S["kappa"])
        self.ext_dose = np.zeros(n)

        self.scale_true = self.A * self.m
        self.A_prior = self.A * np.exp(rng.normal(0, 0.18, n))
        self.logA = np.log(self.A_prior)
        self.logA_prior = np.log(self.A_prior)
        self.conf = np.full(n, 0.3)

        self.x = np.zeros(n)
        self.active = np.ones(n, dtype=bool)
        self.bad_years = np.zeros(n)
        self.urban_link = rng.random(n) < cfg.urban_link
        self.q = np.clip(cfg.q_base + cfg.q_wealth_scale * np.exp(-self.wealth / 380.0), 0.03, 0.30)
        self.has_credit = rng.random(n) < cfg.credit_access
        self.credit_line = cfg.credit_share * self.L * cfg.land_value * self.has_credit

        self.trained = np.zeros(n, dtype=bool)
        self.last_profit = np.zeros(n)
        self.reach_cum = 0
        self.dc_v = np.full(cfg.n_villages, cfg.dc_amb)   # ambiguity premium by village
        self.advisor = np.zeros(cfg.n_villages, dtype=bool)
        self.last_signal = np.nan

        self.log = {k: [] for k in
                    ["year", "season", "p", "yield", "yield_irr", "yield_rf", "output",
                     "x_mean", "x_irr", "x_rf", "adopt", "adopt_irr", "adopt_rf",
                     "profit_irr", "profit_rf", "active", "reach", "gini", "signal",
                     "advisors", "exits"]}

    # ---------------------------------------------------------------- yield
    def g(self, x):
        d, r = self.delta, self.rho
        return ((1.0 - d) + d * np.power(np.clip(x, 1e-9, 1.0), r)) ** (1.0 / r)

    def sigma_y(self, x):
        x = np.asarray(x, float)
        base = np.array([self.cfg.S["sigma_y"][s] for s in self.sys])
        irr = self.irr
        if x.ndim == 2:
            base, irr = base[:, None], irr[:, None]
        return np.clip(base * (1.0 + self.cfg.lam * (1.0 - irr) * (x - 0.35)), 0.05, 0.90)

    # ---------------------------------------------------------------- costs
    def parts(self, x, w, px):
        """Return (cash, noncash) per hectare."""
        S = self.cfg.S
        lab = w * S["lab0"] * np.maximum(1.0 - self.cfg.lab_mu * x, 0.05)
        cash = px * x
        manage = self.kappa[:, None] * x ** 2 if np.ndim(x) == 2 else self.kappa * x ** 2
        return cash, lab + manage

    def ce(self, x, p, w, px, dc, gamma):
        """Certainty equivalent per hectare, with ambiguity premium on non-cash cost."""
        x = np.asarray(x, float)
        Ah = np.exp(self.logA)
        scale = (Ah * self.m)[:, None] if x.ndim == 2 else Ah * self.m
        mu_y = scale * self.g(x)
        cash, noncash = self.parts(x, w, px)
        c = (cash + noncash) * (1.0 + dc)
        # proportional risk premium: the farmer discounts the price by a
        # factor that rises with yield variance. Equivalent to a CRRA agent
        # facing a multiplicative shock, and it avoids the perverse result
        # that richer farmers take smaller bets.
        p_eff = p * (1.0 - gamma * self.sigma_y(x))
        return p_eff * mu_y - c

    # ---------------------------------------------------------------- choice
    def choose(self, p, w, px):
        G = len(XG)
        xg = XG[None, :]
        dc = self.dc_v[self.village][:, None]
        v = self.ce(xg, p, w, px, dc, self.cfg.gamma)
        cash, noncash = self.parts(xg, w, px)
        wealth_ha = (self.wealth / self.L)[:, None]
        credit_ha = (self.credit_line / self.L)[:, None]
        feasible = (cash <= wealth_ha + credit_ha + 1e-9)
        feasible[:, 0] = True
        v = np.where(feasible, v, -1e9)
        pick = np.argmax(v, axis=1)
        return XG[pick], v[np.arange(len(pick)), pick]

    def value_of_tag(self, p, w, px):
        """Per-farmer profit gain from resolving the ambiguity, by village."""
        xg = XG[None, :]
        v_amb = self.ce(xg, p, w, px, self.cfg.dc_amb, self.cfg.gamma)
        v_tag = self.ce(xg, p, w, px, self.cfg.dc_tag, self.cfg.gamma)
        g_amb = v_amb.max(axis=1) - v_amb[:, 0]
        g_tag = v_tag.max(axis=1) - v_tag[:, 0]
        gain = np.maximum(g_tag - g_amb, 0.0) * self.L * self.cfg.seasons
        out = np.zeros(self.cfg.n_villages)
        for v in range(self.cfg.n_villages):
            vi = (self.village == v) & self.active
            out[v] = gain[vi].mean() if vi.sum() else 0.0
        return out

    # ---------------------------------------------------------------- season
    def step(self, year, season, p, w, px):
        cfg = self.cfg
        idx = self.active
        if idx.sum() == 0:
            return

        x_new, _ = self.choose(p, w, px)
        x_new = np.where(idx, x_new, 0.0)
        adj = np.where(x_new < self.x, 0.14, 0.42)
        self.x = np.where(idx, (1 - adj) * self.x + adj * x_new, 0.0)
        self.x = np.clip(self.x, 0.0, 1.0)

        sy = self.sigma_y(self.x)
        eps = self.rng.normal(0, 1, cfg.n) * sy - 0.5 * sy ** 2
        y_obs = (self.A * self.m) * self.g(self.x) * np.exp(eps)
        y_obs *= np.exp(self.rng.normal(0, 0.06, cfg.n))
        p_eff = p * np.exp(self.rng.normal(0, 0.03, cfg.n))
        cash, noncash = self.parts(self.x, w, px)
        borrow = np.maximum(cash - self.wealth / self.L, 0.0)
        c = cash + noncash + borrow * cfg.r_credit * 0.5
        profit = np.where(idx, p_eff * y_obs - c, 0.0)

        log_implied = (np.log(np.maximum(y_obs, 1e-6))
                       - np.log(np.maximum(self.m * self.g(self.x), 1e-3)))
        for v in range(cfg.n_villages):
            vi = (self.village == v) & idx
            if vi.sum() > 2:
                nb = np.median(log_implied[vi])
                self.logA[vi] += cfg.learn_nb * (nb - self.logA[vi])
        self.logA += cfg.learn_own * (log_implied - self.logA)
        self.logA += cfg.belief_decay * (self.logA_prior - self.logA)
        self.logA = np.clip(self.logA, np.log(0.2), np.log(14.0))

        self.last_profit = np.where(idx, profit, self.last_profit)
        self.wealth = np.where(idx, self.wealth + cfg.savings * profit * self.L, self.wealth)
        self.wealth = np.maximum(self.wealth, 5.0)
        self._record(year, season, p, w, y_obs, profit, idx)

    # ---------------------------------------------------------------- machine
    def run_extension(self, year):
        cfg = self.cfg
        if not cfg.ext_on:
            return
        b = budget_path(cfg)[year]
        n_ffs = int(round(cfg.ffs_at_peak * b))
        if n_ffs <= 0:
            return
        n_treat = min(n_ffs * cfg.ffs_class, int(self.active.sum()))
        if n_treat <= 0:
            return
        if cfg.targeting == "measured":
            score = self.A
        elif cfg.targeting == "profit":
            score = self.A * self.m * self.irr
        else:
            score = np.zeros(cfg.n)
        score = score + cfg.target_noise * self.rng.random(cfg.n)
        cand = np.where(self.active)[0]
        pick = cand[np.argsort(-score[cand])][:n_treat]

        if cfg.agronomic:
            self.m_prog[pick] += cfg.ext_m_gain * (cfg.m_prog_cap - self.m_prog[pick])
            self.m = self.m_base + self.m_prog

        # the demonstration plot is one draw from the technology's own distribution
        base = np.array([cfg.S["A_mean"][s] for s in self.sys[pick]])
        if cfg.demo_luck:
            sy = np.array([cfg.S["sigma_y"][s] for s in self.sys[pick]]) * 1.4
            draw = np.exp(self.rng.normal(0, 1, len(pick)) * sy - 0.5 * sy ** 2)
        else:
            draw = np.ones(len(pick))
        signal = base * draw
        self.last_signal = float(np.mean(signal))
        if cfg.demo_bias:
            self.logA[pick] += cfg.learn_ext * (np.log(signal) - self.logA[pick])

        if cfg.price_tag:
            self.dc_v[:] = cfg.dc_tag
        new = ~self.trained[pick]
        self.trained[pick] = True
        self.ext_dose[pick] += 1.0
        self.reach_cum += int(new.sum())
        self.scale_true = self.A * self.m

    def run_advisors(self, year, p, w, px):
        cfg = self.cfg
        if not cfg.advisor_on:
            return
        wt = self.value_of_tag(p, w, px)
        for v in range(cfg.n_villages):
            n_v = max((self.village == v).sum(), 1)
            if not self.advisor[v] and wt[v] * n_v > cfg.advisor_cost:
                self.advisor[v] = True
            if self.advisor[v]:
                self.dc_v[v] = cfg.dc_tag

    def decay_extension(self):
        cfg = self.cfg
        self.m_prog *= (1.0 - cfg.ext_decay)
        self.m = self.m_base + self.m_prog
        self.kappa = np.minimum(self.kappa * 1.03, cfg.S["kappa"])

    # ---------------------------------------------------------------- exit
    def exit_round(self, year, w):
        cfg = self.cfg
        h = self.log
        n = len(self.active)
        ix = [i for i, y in enumerate(h["year"]) if y == year]
        if not ix:
            return
        prof = self.last_profit
        thresh = cfg.exit_threshold * w * 60.0
        self.bad_years = np.where(prof < thresh, self.bad_years + 1, 0)
        cand = self.active & (self.bad_years >= 2) & self.urban_link
        leavers = cand & (self.rng.random(n) < cfg.exit_prob)
        if leavers.sum() == 0:
            return
        for v in range(cfg.n_villages):
            vi = self.village == v
            lv = leavers & vi
            if lv.sum() == 0:
                continue
            free = self.L[lv].sum()
            rec = vi & self.active & ~leavers
            if rec.sum() == 0:
                continue
            best = np.argsort(-np.where(rec, prof, -1e9))[: max(1, int(0.25 * rec.sum()))]
            best = best[rec[best]]
            if len(best) == 0:
                continue
            self.L[best] += free / len(best)
            self.wealth[best] += 0.5 * (free / len(best)) * 260.0
        self.active[leavers] = False
        self.L[leavers] = 0.0
        h["exits"][-1] = int(leavers.sum())

    # ---------------------------------------------------------------- record
    def _record(self, year, season, p, w, y_obs, profit, idx):
        h = self.log
        L = np.maximum(self.L, 1e-9)
        h["year"].append(year); h["season"].append(season); h["p"].append(p)
        h["yield"].append(float(np.average(y_obs[idx], weights=L[idx])) if idx.sum() else 0.0)
        for s, key in [(0, "yield_irr"), (1, "yield_rf")]:
            si = idx & (self.sys == s)
            h[key].append(float(np.average(y_obs[si], weights=L[si])) if si.sum() else 0.0)
        h["output"].append(float((y_obs[idx] * L[idx]).sum()))
        h["x_mean"].append(float(np.average(self.x[idx], weights=L[idx])) if idx.sum() else 0.0)
        for s, key in [(0, "x_irr"), (1, "x_rf")]:
            si = idx & (self.sys == s)
            h[key].append(float(np.average(self.x[si], weights=L[si])) if si.sum() else 0.0)
        h["adopt"].append(float(np.average((self.x[idx] > 0.6), weights=L[idx])) if idx.sum() else 0)
        for s, key in [(0, "adopt_irr"), (1, "adopt_rf")]:
            si = idx & (self.sys == s)
            h[key].append(float(np.average((self.x[si] > 0.6), weights=L[si])) if si.sum() else 0)
        for s, key in [(0, "profit_irr"), (1, "profit_rf")]:
            si = idx & (self.sys == s)
            h[key].append(float(np.average(profit[si], weights=L[si])) if si.sum() else 0.0)
        h["active"].append(int(idx.sum()))
        h["reach"].append(self.reach_cum)
        h["advisors"].append(int(self.advisor.sum()))
        h["exits"].append(0)
        h["signal"].append(self.last_signal if self.last_signal == self.last_signal else 0.0)
        inc = profit[idx] * L[idx]
        h["gini"].append(_gini(inc))


def _gini(v):
    if len(v) < 2:
        return 0.0
    v = np.sort(np.maximum(v, 0)); n = len(v); i = np.arange(1, n + 1)
    s = v.sum()
    return 0.0 if s <= 0 else float((2 * (i * v).sum()) / (n * s) - (n + 1) / n)


def run(cfg: Config):
    m = Model(cfg)
    pp = price_path(cfg)
    for year in range(cfg.y0, cfg.y1 + 1):
        p_y = pp[year]
        w = cfg.S["w0"] * (1 + cfg.w_trend) ** (year - cfg.y0)
        px = cfg.S["px0"] * (1 + cfg.px_trend) ** (year - cfg.y0)
        m.run_extension(year)
        for s in range(cfg.seasons):
            m.step(year, s, p_y * (1 + 0.06 * (-1) ** s), w, px)
        m.run_advisors(year, p_y, w, px)
        m.exit_round(year, w)
        m.decay_extension()
    return m
