"""Site configurations for the price-tag model.

Two sites: Philippine irrigated lowland (where the curriculum was written)
and western Kenya rainfed (where it was transferred).
"""
import numpy as np
from dataclasses import dataclass, asdict

YEARS = list(range(2004, 2017))

P_RICE = {2004: 1.00, 2005: 1.04, 2006: 1.09, 2007: 1.17, 2008: 1.84,
          2009: 1.55, 2010: 1.44, 2011: 1.64, 2012: 1.57, 2013: 1.45,
          2014: 1.35, 2015: 1.17, 2016: 1.11}

P_MAIZE = {2004: 0.95, 2005: 0.92, 2006: 1.00, 2007: 1.18, 2008: 1.55,
           2009: 1.42, 2010: 1.30, 2011: 1.62, 2012: 1.55, 2013: 1.38,
           2014: 1.22, 2015: 1.12, 2016: 1.05}

BUDGET = {2004: 0.60, 2005: 0.35, 2006: 0.20, 2007: 0.17, 2008: 0.56,
          2009: 0.75, 2010: 1.00, 2011: 0.95, 2012: 0.48, 2013: 0.35,
          2014: 0.32, 2015: 0.30, 2016: 0.30}

SITES = {
    "PH": dict(
        price_series=P_RICE, p0=380.0, w0=3.5, lab0=75.0, px0=480.0,
        kappa=50.0, A_mean=(8.0, 4.5, 2.8), A_sd=(0.9, 0.7, 0.5),
        sigma_y=(0.13, 0.22, 0.28), irr0=0.62, irr_decay=2.1,
        land_mean=1.30, wealth_med=220.0, rain_split=0.68,
    ),
    "KE": dict(
        price_series=P_MAIZE, p0=300.0, w0=2.0, lab0=80.0, px0=320.0,
        kappa=62.0, A_mean=(6.0, 4.2, 2.6), A_sd=(0.7, 0.6, 0.4),
        sigma_y=(0.16, 0.34, 0.40), irr0=0.06, irr_decay=1.2,
        land_mean=1.00, wealth_med=140.0, rain_split=0.88,
    ),
}


@dataclass
class Config:
    site: str = "PH"
    seed: int = 1
    n: int = 1200
    n_villages: int = 12
    seasons: int = 2
    y0: int = 2004
    y1: int = 2016

    sigma: float = 1.9
    trad_share: float = 0.42
    m_alpha: float = 6.0
    m_beta: float = 3.5
    ext_m_gain: float = 0.45
    m_prog_cap: float = 0.12
    m_ceiling: tuple = (0.74, 0.66, 0.62)

    ka: float = 0.10            # kernel: cost is fixed per ha at x=0
    lab_mu: float = 0.35
    px_trend: float = -0.020
    w_trend: float = 0.030
    p_trend: float = -0.022
    price_endog: float = 0.0

    lam: float = 1.2
    gamma: float = 0.55         # risk aversion on the sd of profit
    dc_amb: float = 0.25        # ambiguity premium on unpriced non-cash cost
    dc_tag: float = 0.05        # residual uncertainty once a price tag exists

    pi_min: float = 140.0
    q_base: float = 0.035
    q_wealth_scale: float = 0.11
    learn_own: float = 0.40
    learn_nb: float = 0.08
    learn_ext: float = 0.25
    belief_decay: float = 0.10

    wealth_sig: float = 1.25
    land_sig: float = 0.72
    credit_share: float = 0.55
    credit_access: float = 0.55
    land_value: float = 250.0
    r_credit: float = 0.24
    savings: float = 0.10

    ext_on: bool = True
    price_tag: bool = False     # does the FFS attach costs and returns?
    ffs_at_peak: int = 26
    ffs_class: int = 25
    targeting: str = "measured"   # measured | profit | random
    target_noise: float = 0.55
    ext_decay: float = 0.12
    demo_luck: bool = True
    agronomic: bool = True
    demo_bias: bool = True      # demo plot is a single draw, not its mean

    advisor_on: bool = False    # private advice market
    advisor_cost: float = 15000.0

    exit_threshold: float = 0.62
    exit_prob: float = 0.30
    urban_link: float = 0.30
    interp: bool = False

    def d(self, **kw):
        c = asdict(self)
        c.update(kw)
        return Config(**c)

    @property
    def S(self):
        return SITES[self.site]


def price_path(cfg):
    S = cfg.S
    out = {}
    for y in YEARS:
        base = S["p0"] * (1 + cfg.p_trend) ** (y - cfg.y0)
        out[y] = base * S["price_series"][y]
    return out


def budget_path(cfg):
    return {y: (BUDGET[y] if cfg.ext_on else 0.0) for y in YEARS}
