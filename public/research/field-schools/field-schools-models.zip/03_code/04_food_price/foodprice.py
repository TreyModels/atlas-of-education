"""The food price dilemma.

A polity wants cheap food. Farmers want a price above their cost. The state
resolves this every year, and the resolution has a short-run fiscal and
distributional consequence: suppressing the farmgate price is cheap until the
country runs out of its own harvest, and then imports are expensive.

Model scope (read before interpreting output)
---------------------------------------------
* ``k`` is an *annually reoptimised input intensity* (e.g. fertiliser per
  hectare). It is chosen each period given the chosen farmgate price and the
  fixed farm aptitude ``apt``. It is NOT a capital stock and there is no
  capital accumulation. Aptitude ``apt`` is fixed for the life of a farm.
* Irreversible exit (a farm that exits never returns) gives *path dependence*
  in the cross-section of active farms. It does NOT generate cumulative TFP
  growth. Do not describe the output as endogenous or cumulative TFP.
* The political objective is a reduced-form support function. It is NOT a
  welfare planner. The ``planner`` name is retained only as a deprecated
  backward-compatible alias for ``political_counterfactual`` (gamma=1,
  budget_share=0). No true welfare planner is implemented.
* ``PW`` is an *undocumented supplied price index*. Its provenance is not
  recorded here and it is not verified against any source. Do not treat it as
  observed data.
* The objective's scaling with ``n`` is an unresolved assumption: the support
  weights are not normalised by population or farm counts. See
  ``objective_scaling_note``.

Timing within a year
--------------------
1. World price and budget are set from the exogenous path.
2. ``choose_price`` grids the farmgate price; for each candidate it
   re-optimises ``k`` and evaluates support subject to the deficit constraint.
3. The chosen price is applied; ``k`` is re-optimised at that price.
4. Production ``Q``, demand ``D``, imports and deficit are computed for the
   *pre-exit producing cohort* (farms active at the start of the year).
5. Exit is evaluated on that cohort's farm income vs. the outside wage; farms
   that have been below the line for ``exit_patience`` consecutive years exit.
6. ``farmers_producing`` (cohort size used for Q/profit) and ``farmers_end``
   (post-exit active count) are recorded. Legacy ``farmers`` equals
   ``farmers_end``.
"""
import numpy as np

YEARS = list(range(2004, 2025))

# Undocumented supplied price index. Provenance not recorded; not verified.
PW = {2004: 1.00, 2005: 1.04, 2006: 1.09, 2007: 1.17, 2008: 1.84,
      2009: 1.55, 2010: 1.44, 2011: 1.64, 2012: 1.57, 2013: 1.45,
      2014: 1.35, 2015: 1.17, 2016: 1.11, 2017: 1.12, 2018: 1.10,
      2019: 1.09, 2020: 1.12, 2021: 1.35, 2022: 1.62, 2023: 1.45,
      2024: 1.38}

BASELINE_PARAMS = {
    "n": 800, "urban0": 0.48, "gamma": 1.6, "budget_share": 0.020,
    "margin": 40.0, "cost": 850.0, "theta": 0.45, "seed": 0,
    "subst": 0.30, "p_world": 340.0, "pop_growth": 0.016,
    "exit_line": 0.02, "exit_patience": 3,
}

OBJECTIVE_SCALING_NOTE = (
    "The political support objective is not normalised by population or farm "
    "counts. Its scaling with n is an unresolved assumption; do not interpret "
    "cross-n comparisons as welfare comparisons."
)


class NoFeasiblePriceError(RuntimeError):
    """Raised when no grid price satisfies the deficit constraint."""


class Polity:
    def __init__(self, n=800, urban0=0.48, gamma=1.6, budget_share=0.020,
                 margin=40.0, cost=850.0, theta=0.45, seed=0,
                 subst=0.30, p_world=340.0, pop_growth=0.016,
                 exit_line=0.02, exit_patience=3, planner_mode=False):
        # ---- validation -------------------------------------------------
        # Explicit finiteness checks for every continuous parameter. These
        # run before the range checks so that NaN/inf produce a clear error
        # rather than silently passing comparisons.
        for _name, _val in (
                ("urban0", urban0), ("gamma", gamma),
                ("budget_share", budget_share), ("margin", margin),
                ("cost", cost), ("theta", theta), ("subst", subst),
                ("p_world", p_world), ("pop_growth", pop_growth),
                ("exit_line", exit_line)):
            try:
                _finite = bool(np.isfinite(_val))
            except TypeError:
                _finite = False
            if not _finite:
                raise ValueError(
                    f"{_name} must be a finite number, got {_val!r}")

        if not isinstance(n, (int, np.integer)) or n <= 0:
            raise ValueError(f"n must be a positive integer, got {n!r}")
        if not (0.0 <= urban0 <= 1.0):
            raise ValueError(f"urban0 must be in [0,1], got {urban0!r}")
        if gamma < 0:
            raise ValueError(f"gamma must be >= 0, got {gamma!r}")
        if budget_share < 0:
            raise ValueError(f"budget_share must be >= 0, got {budget_share!r}")
        if margin < 0:
            raise ValueError(f"margin must be >= 0, got {margin!r}")
        if cost <= 0:
            raise ValueError(f"cost must be > 0, got {cost!r}")
        if not (0.0 < theta < 1.0):
            raise ValueError(f"theta must be in (0,1), got {theta!r}")
        if subst < 0:
            raise ValueError(f"subst must be >= 0, got {subst!r}")
        if p_world <= 0:
            raise ValueError(f"p_world must be > 0, got {p_world!r}")
        if pop_growth <= -1.0:
            raise ValueError(f"pop_growth must be > -1, got {pop_growth!r}")
        if exit_line < 0:
            raise ValueError(f"exit_line must be >= 0, got {exit_line!r}")
        if not isinstance(exit_patience, (int, np.integer)) or exit_patience < 1:
            raise ValueError(
                f"exit_patience must be a positive integer, got {exit_patience!r}")

        self.rng = np.random.default_rng(seed)
        self.n = int(n)
        self.urban = float(urban0)
        # Deprecated alias: planner_mode maps to the political counterfactual
        # (gamma=1, budget_share=0). No true welfare planner is implemented.
        if planner_mode:
            gamma = 1.0
            budget_share = 0.0
        self.gamma = float(gamma)
        self.budget_share = float(budget_share)
        self.m = float(margin)
        self.c = float(cost)
        self.theta = float(theta)
        self.subst = float(subst)
        self.p_w = float(p_world)
        self.pop_growth = float(pop_growth)
        self.exit_line = float(exit_line)
        self.exit_patience = int(exit_patience)

        self.land = np.clip(self.rng.lognormal(np.log(1.3), 0.65, self.n), 0.2, 8.0)
        self.apt = np.clip(self.rng.lognormal(np.log(3.6), 0.26, self.n), 1.4, 8.0)
        self.active = np.ones(self.n, dtype=bool)
        self.k = np.full(self.n, 0.7)
        self.below = np.zeros(self.n, dtype=int)

        self.log = {key: [] for key in
                    ["year", "world", "pd", "pc", "breakeven", "tax", "Q", "D",
                     "imports", "deficit", "farmers", "farmers_producing",
                     "farmers_end", "urban", "profit_ha", "k",
                     "import_share"]}

    # ------------------------------------------------------------------ farm
    def invest(self, pd):
        """Re-optimise input intensity k given farmgate price pd.

        Interior FOC: theta * pd * apt * k**(theta-1) = c
        => k* = (theta * pd * apt / c)**(1/(1-theta)).
        """
        a, c, th = self.apt, self.c, self.theta
        kstar = (th * pd * a / c) ** (1.0 / (1.0 - th))
        self.k = np.where(self.active, np.clip(kstar, 0.05, 1.2), 0.0)

    def produce(self, pd):
        y = self.apt * self.k ** self.theta
        return y, pd * y - self.c * self.k

    def demand(self, pc):
        # inelastic, with a slow income drift
        return self.D0 * (pc / self.p_w) ** (-self.subst) * self.income

    # ------------------------------------------------------------- politics
    def choose_price(self, world, budget):
        """Grid the farmgate price; maximise political support subject to deficit.

        Raises NoFeasiblePriceError if no grid point satisfies the deficit
        constraint. There is no cheapest-price fallback.
        """
        try:
            world_finite = bool(np.isfinite(world))
        except TypeError:
            world_finite = False
        if not world_finite or world <= 0:
            raise ValueError(
                f"world must be a finite positive number, got {world!r}")
        try:
            budget_finite = bool(np.isfinite(budget))
        except TypeError:
            budget_finite = False
        if not budget_finite or budget < 0:
            raise ValueError(
                f"budget must be a finite nonnegative number, got {budget!r}")
        grid = np.linspace(0.45, 1.25, 81) * world
        best, best_v = None, -np.inf
        w_u = self.urban ** self.gamma
        w_r = max(1.0 - self.urban, 1e-3)
        for pd in grid:
            self.invest(pd)
            y, _ = self.produce(pd)
            Q = float((y * self.land * self.active).sum())
            pc = pd + self.m
            D = self.demand(pc)
            M = max(D - Q, 0.0)
            deficit = M * max(world - pd, 0.0)
            if deficit > budget:
                continue
            v = w_u * (-(pc / world) * D) + w_r * np.log(max(pd, 1.0))
            if v > best_v:
                best_v, best = v, pd
        if best is None:
            raise NoFeasiblePriceError(
                f"no grid price satisfies deficit constraint "
                f"(world={world!r}, budget={budget!r})")
        return best

    # ------------------------------------------------------------------ run
    def run(self):
        # self-sufficient at the baseline intensity
        self.invest(self.p_w)
        self.D0 = float((self.apt * self.k ** self.theta * self.land).sum())
        self.income = 1.0
        pop = 1.0
        gdp0 = self.p_w * self.D0
        for year in YEARS:
            world = self.p_w * PW[year]
            gdp = gdp0 * pop * (1.0 + 0.020 * (year - 2004))
            budget = self.budget_share * gdp

            pd = self.choose_price(world, budget)
            pc = pd + self.m

            self.invest(pd)
            y, profit = self.produce(pd)

            # Pre-exit producing cohort: farms active at start of year.
            producing = self.active.copy()
            n_producing = int(producing.sum())
            Q = float((y * self.land * producing).sum())
            D = self.demand(pc)
            M = max(D - Q, 0.0)
            deficit = M * max(world - pd, 0.0)

            # Operating break-even: zero operating profit at the chosen k,
            # aggregated over the producing cohort.
            #   sum(c * k * land) / sum(y * land)
            # This is NOT a wage-inclusive economic break-even.
            num = float((self.c * self.k * self.land * producing).sum())
            den = float((y * self.land * producing).sum())
            if den > 0.0:
                breakeven = num / den
            else:
                breakeven = float("nan")

            # exit is an opportunity-cost decision, not a bankruptcy one
            wage = 3.5 * (1.025 ** (year - 2004))
            farm_income = profit * self.land
            outside = 0.45 * wage * 250.0
            below = farm_income < outside
            self.below = np.where(below & self.active, self.below + 1, 0)
            self.active = self.active & ~(self.below >= self.exit_patience)
            n_end = int(self.active.sum())

            farm_share = n_end / self.n
            target = 1.0 - 0.52 * farm_share
            self.urban = float(np.clip(0.7 * self.urban + 0.3 * target, 0.30, 0.90))
            pop *= (1 + self.pop_growth)
            self.income *= 1.0 + 0.022

            self.log["year"].append(year)
            self.log["world"].append(world)
            self.log["pd"].append(pd)
            self.log["pc"].append(pc)
            self.log["breakeven"].append(breakeven)
            self.log["tax"].append(1.0 - pd / world)
            self.log["Q"].append(Q)
            self.log["D"].append(D)
            self.log["imports"].append(M)
            self.log["deficit"].append(deficit)
            self.log["farmers"].append(n_end)  # legacy: end-of-year count
            self.log["farmers_producing"].append(n_producing)
            self.log["farmers_end"].append(n_end)
            self.log["urban"].append(self.urban)
            self.log["profit_ha"].append(
                float(np.average(profit[producing], weights=self.land[producing]))
                if n_producing > 0 else 0.0)
            self.log["k"].append(
                float(self.k[producing].mean()) if n_producing > 0 else 0.0)
            self.log["import_share"].append(M / D if D > 0 else 0.0)
        return self


def political_counterfactual(**kw):
    """Political counterfactual: gamma=1, budget_share=0.

    This is NOT a welfare planner. It is a reduced-form political objective
    with different weights and no deficit constraint.

    ``budget_share=0`` means the subsidy allowance is ZERO: the deficit
    constraint is binding at zero, so any positive deficit is infeasible.
    It does NOT mean "no deficit constraint". The counterfactual is therefore
    the political objective evaluated under a zero subsidy allowance, not an
    unconstrained optimum.
    """
    kw.pop("planner_mode", None)
    return Polity(gamma=1.0, budget_share=0.0, **kw).run()


def planner(**kw):
    """DEPRECATED: use ``political_counterfactual``.

    Retained only for backward compatibility. This is NOT a welfare planner;
    it is the political counterfactual (gamma=1, budget_share=0), i.e. the
    political objective under a ZERO subsidy allowance (not an unconstrained
    optimum).
    """
    import warnings
    warnings.warn(
        "planner() is deprecated; use political_counterfactual(). "
        "This is not a welfare planner.",
        DeprecationWarning, stacklevel=2)
    return political_counterfactual(**kw)
