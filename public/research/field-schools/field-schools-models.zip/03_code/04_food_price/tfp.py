"""Portable wrapper: summary of factual sensitivity to baseline aptitude.

This script reports how the baseline run's summary statistics respond to a
shift in the baseline aptitude distribution. It is a *sensitivity* exercise
on the model's own parameters, not an empirical claim and not an estimate of
endogenous or cumulative TFP. Do not label its output as "endogenous TFP" or
"cumulative TFP".

Usage:
    python 03_code/04_food_price/tfp.py [--output-dir DIR] [--quick]
"""
import argparse
import json
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

from foodprice import Polity, BASELINE_PARAMS  # noqa: E402


def _summary(log):
    yr = np.array(log["year"])
    return {
        "years": yr.tolist(),
        "farmers_end_first": int(log["farmers_end"][0]),
        "farmers_end_last": int(log["farmers_end"][-1]),
        "imports_first": float(log["imports"][0]),
        "imports_last": float(log["imports"][-1]),
        "import_share_last": float(log["import_share"][-1]),
        "mean_tax": float(np.mean(log["tax"])),
        "max_tax": float(np.max(log["tax"])),
        "mean_pd": float(np.mean(log["pd"])),
        "mean_Q": float(np.mean(log["Q"])),
        "mean_D": float(np.mean(log["D"])),
    }


def _run_with_apt_shift(shift, seed):
    """Run baseline with aptitude multiplied by exp(shift).

    Uses the actual Polity API: construct with the baseline parameters, then
    scale the fixed aptitude vector before running. Aptitude is fixed for the
    life of a farm in the model; this is a sensitivity on that fixed
    distribution, not a cumulative TFP process.
    """
    params = {k: v for k, v in BASELINE_PARAMS.items()
              if k not in ("seed", "planner_mode")}
    p = Polity(seed=seed, **params)
    p.apt = np.clip(p.apt * np.exp(shift), 1.4, 8.0)
    return p.run().log


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--output-dir", default=os.path.join(
        os.path.dirname(os.path.dirname(HERE)), "07_results", "food-price"))
    ap.add_argument("--quick", action="store_true",
                    help="fewer sensitivity points")
    args = ap.parse_args(argv)

    os.makedirs(args.output_dir, exist_ok=True)
    shifts = [-0.10, 0.0, 0.10] if args.quick else [-0.20, -0.10, 0.0, 0.10, 0.20]
    seed = BASELINE_PARAMS["seed"]

    rows = []
    for s in shifts:
        log = _run_with_apt_shift(s, seed)
        summ = _summary(log)
        summ["apt_shift"] = s
        rows.append(summ)

    out = {
        "note": ("Sensitivity of baseline summary statistics to a shift in the "
                 "fixed baseline aptitude distribution. This is a "
                 "model-parameter sensitivity exercise, not an empirical claim "
                 "and not an estimate of endogenous or cumulative TFP."),
        "label": "fixed aptitude sensitivity (not cumulative TFP)",
        "baseline_params": BASELINE_PARAMS,
        "shifts": shifts,
        "rows": rows,
    }
    path = os.path.join(args.output_dir, "tfp_sensitivity.json")
    with open(path, "w") as f:
        json.dump(out, f, indent=2)
    print(f"wrote {path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
