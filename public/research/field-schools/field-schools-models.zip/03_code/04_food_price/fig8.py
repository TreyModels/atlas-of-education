"""Thin wrapper: build fig8_dilemma.png via the repaired CLI.

Kept for backward compatibility. The canonical entry point is
``run_foodprice.py`` at the repository root. This wrapper delegates to it.
"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, "..", ".."))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from run_foodprice import main  # noqa: E402

if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
