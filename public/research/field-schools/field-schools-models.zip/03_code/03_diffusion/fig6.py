"""Thin portable wrapper: fig6 paths -> run_diffusion.build_fig6."""
import sys
from pathlib import Path

_ROOT = Path(__file__).resolve().parents[2]
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

from run_diffusion import ORIGINAL, QUICK, _ensure_dir, build_fig6, DEFAULT_OUTPUT_DIR  # noqa: E402


def main(quick: bool = False, output_dir: str = str(DEFAULT_OUTPUT_DIR)) -> None:
    out = _ensure_dir(Path(output_dir).resolve())
    _ensure_dir(out / "figures")
    cfg = (QUICK if quick else ORIGINAL)["fig6"]
    build_fig6(cfg, out, None)
    print(f"[fig6] wrote {out / 'figures' / 'fig6_paths.png'}")


if __name__ == "__main__":
    main()
