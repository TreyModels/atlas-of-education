"""Thin portable wrapper: figs2 (all plots) -> run_diffusion pipeline."""
import sys
from pathlib import Path

_ROOT = Path(__file__).resolve().parents[2]
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

from run_diffusion import (  # noqa: E402
    ORIGINAL,
    QUICK,
    _ensure_dir,
    build_fig4,
    build_fig5,
    build_fig6,
    DEFAULT_OUTPUT_DIR,
)


def main(quick: bool = False, output_dir: str = str(DEFAULT_OUTPUT_DIR)) -> None:
    out = _ensure_dir(Path(output_dir).resolve())
    _ensure_dir(out / "figures")
    cfg = QUICK if quick else ORIGINAL
    build_fig4(cfg["fig4"], out, None)
    build_fig5(cfg["fig5"], out, None)
    build_fig6(cfg["fig6"], out, None)
    print(f"[figs2] wrote figures under {out / 'figures'}")


if __name__ == "__main__":
    main()
