"""A simple knowledge-diffusion model.

One unit of knowledge enters a village. Does it spread?

Farmers sit on a lattice. A practice is either held or not. It transmits on
contact. Whether a farmer who receives it keeps it depends on whether it pays:

    gross_i = m_i * p * (1 - s_i) * dY

    m_i  share of the reference price actually received (market access)
    s_i  landlord's output share (tenancy)
    dY   yield gain of the practice

The point: adoption is not a slope, it is a cliff. What matters is whether the
set of farmers for whom the practice pays forms a connected mass big enough to
carry the knowledge, not whether it pays on average.

Reliability channel (explicit assumption)
-----------------------------------------
`risk` in [0, 1] is the assumed reliability of the incremental yield benefit:
the probability that the gross benefit is actually realised. It is NOT an
estimated risk-aversion parameter and it is NOT a claim about Kenya.

Per hectare:

    gross            = m_i * p * (1 - s_i) * dY
    perceived_cost   = c * (1 + ambiguity)   if ambiguity > 0 else c
    margin           = gross - c
    margin_perc      = gross - perceived_cost
    expected_margin  = risk * gross - perceived_cost

Eligibility uses `expected_margin > 0` (and affordability). With `risk == 1`
and `ambiguity == 0`, `expected_margin == margin`, reproducing the original
full-benefit eligibility rule exactly. `margin` remains the actual
full-benefit profit; `margin_perc` is the perceived margin under ambiguity;
`expected_margin` is the risk-weighted expected net benefit used for
eligibility.

Transmission is a finite-horizon, adoption-mediated process: a nonadopter
becomes eligible to adopt only through contact with an adopter, and adoption
is the only channel by which the practice spreads. There is no separate
"knowledge" state distinct from "use". A quiet stochastic round is not
absorption; the process continues until the horizon (`steps`) is reached or
no eligible nonadopter has any adopted neighbour.
"""
import numpy as np
from collections import deque


class Village:
    def __init__(self, side=40, tenant_share=0.50, wedge=0.13, price=340.0,
                 dy=0.30, cost=70.0, turnover=0.50, rewiring=0.0, seed=0,
                 ambiguity=0.0, liquidity_med=120.0, liquidity_sig=1.1,
                 lease_share=0.25, frac_lease=0.25, risk=1.0):
        # ---- basic validation
        if not (isinstance(side, (int, np.integer)) and side >= 1):
            raise ValueError("side must be a positive integer")
        if not (0.0 <= float(risk) <= 1.0):
            raise ValueError("risk must be in [0, 1]")
        if not (0.0 <= float(tenant_share) <= 1.0):
            raise ValueError("tenant_share must be in [0, 1]")
        if not (0.0 <= float(frac_lease) <= 1.0):
            raise ValueError("frac_lease must be in [0, 1]")
        if not (0.0 <= float(rewiring) <= 1.0):
            raise ValueError("rewiring must be in [0, 1]")

        self.rng = np.random.default_rng(seed)
        self.side = int(side)
        self.n = self.side * self.side
        n = self.n

        # ---- who is who
        # tenure: owners, leaseholders at an illustrative proportional output
        # share, and residual share tenants
        u = self.rng.random(n)
        self.tenant = u < tenant_share
        self.share = np.zeros(n)
        self.share[(u >= tenant_share) & (u < tenant_share + frac_lease)] = lease_share
        self.share[u < tenant_share] = turnover
        # market access: a spread from well connected to remote
        self.access = 1.0 - wedge * self.rng.random(n)

        # ---- does the practice pay?
        self.p = price
        self.dy = dy
        self.c = cost
        self.ambiguity = ambiguity
        self.risk = float(risk)
        # Initialise affordability to all-True so the first `recompute()`
        # (which calls `_refresh_eligibility`) does not touch a missing
        # attribute. The real affordability mask is set below from liquidity.
        self.afford = np.ones(n, dtype=bool)
        self.recompute()

        # liquidity: the cash cost has to be found before the season starts
        self.liquid = self.rng.lognormal(np.log(liquidity_med), liquidity_sig, n)
        self.afford = self.liquid >= cost
        self._refresh_eligibility()

        # ---- contact network
        self.edges = self._lattice_edges()
        if rewiring > 0:
            self._rewire(rewiring)

    # ------------------------------------------------------------------ net
    def _lattice_edges(self):
        s = self.side
        e = []
        for r in range(s):
            for c in range(s):
                i = r * s + c
                if c + 1 < s:
                    e.append((i, i + 1))
                if r + 1 < s:
                    e.append((i, i + s))
        return e

    def _rewire(self, omega):
        """Rewire a fraction `omega` of edges to a uniformly random node.

        Policy: self-loops are forbidden (a rewired endpoint equal to the
        other endpoint is redrawn once; if the redraw still collides the
        edge is kept as the original lattice edge). Parallel edges are
        permitted; the graph remains a simple undirected multigraph on the
        same node set. The graph type is not changed.
        """
        new = []
        for (a, b) in self.edges:
            if self.rng.random() < omega:
                cand = int(self.rng.integers(0, self.n))
                if cand == a:
                    cand = int(self.rng.integers(0, self.n))
                if cand == a:
                    new.append((a, b))
                    continue
                b = cand
            new.append((a, b))
        self.edges = new
        if hasattr(self, "_adj"):
            del self._adj
        if hasattr(self, "_ea"):
            del self._ea

    def neighbours(self):
        if not hasattr(self, "_adj"):
            adj = [[] for _ in range(self.n)]
            for a, b in self.edges:
                adj[a].append(b)
                adj[b].append(a)
            self._adj = adj
        return self._adj

    # ------------------------------------------------------------------ econ
    def recompute(self, price=None):
        """Recompute margins and eligibility.

        Per hectare:
            gross           = access * p * (1 - share) * dy
            perceived_cost  = c * (1 + ambiguity) if ambiguity > 0 else c
            margin          = gross - c
            margin_perc     = gross - perceived_cost
            expected_margin = risk * gross - perceived_cost

        Eligibility is `expected_margin > 0` and affordability. Calling with a
        new `price` refreshes all of these; no stale caches are kept.
        """
        if price is not None:
            self.p = price
        self.gross = self.access * self.p * (1 - self.share) * self.dy
        if self.ambiguity > 0:
            self.perceived_cost = self.c * (1.0 + self.ambiguity)
        else:
            self.perceived_cost = self.c
        self.margin = self.gross - self.c
        self.margin_perc = self.gross - self.perceived_cost
        self.expected_margin = self.risk * self.gross - self.perceived_cost
        self._refresh_eligibility()
        return self.margin

    def _refresh_eligibility(self):
        # Safe during construction: `afford` may not yet be set on the very
        # first call from `recompute()`. Treat missing affordability as
        # all-True so eligibility is well-defined; the real mask is applied
        # immediately afterwards in `__init__`.
        afford = getattr(self, "afford", None)
        if afford is None:
            afford = np.ones(self.n, dtype=bool)
        self.eligible = (self.expected_margin > 0) & afford

    # --------------------------------------------------------- percolation
    def giant_component(self, mask):
        """Largest connected set of `mask` nodes in the full graph."""
        seen = np.zeros(self.n, dtype=bool)
        best = []
        for start in np.where(mask)[0]:
            if seen[start]:
                continue
            comp = []
            q = deque([start])
            seen[start] = True
            while q:
                v = q.popleft()
                comp.append(v)
                for w in self.neighbours()[v]:
                    if mask[w] and not seen[w]:
                        seen[w] = True
                        q.append(w)
            if len(comp) > len(best):
                best = comp
        return np.array(best, dtype=int)

    # ------------------------------------------------------------- dynamics
    def _edge_arrays(self):
        if not hasattr(self, "_ea"):
            a = np.array([e[0] for e in self.edges], dtype=int)
            b = np.array([e[1] for e in self.edges], dtype=int)
            self._ea = (np.concatenate([a, b]), np.concatenate([b, a]))
        return self._ea

    def _validate_tau(self, tau):
        tau = float(tau)
        if not (0.0 <= tau <= 1.0):
            raise ValueError("tau must be in [0, 1]")
        return tau

    def diffuse_fast(self, seeds, tau=0.55, steps=80):
        """Vectorised finite-horizon adoption-mediated diffusion.

        Each round, every eligible nonadopter with k adopted neighbours
        adopts with probability 1 - (1 - tau)**k. A quiet stochastic round
        is not absorption: the loop continues until the horizon `steps` is
        reached or no eligible nonadopter has any adopted neighbour. The
        returned history has one entry per round actually run (including
        the initial seed count).
        """
        tau = self._validate_tau(tau)
        steps = int(steps)
        if steps < 0:
            raise ValueError("steps must be non-negative")
        src, dst = self._edge_arrays()
        adopt = np.zeros(self.n, dtype=bool)
        seeds = np.asarray(seeds, dtype=int)
        adopt[seeds[self.eligible[seeds]]] = True
        hist = [int(adopt.sum())]
        if not adopt.any():
            return adopt, hist
        if tau == 0.0:
            # No transmission possible: stop after the seed round.
            return adopt, hist
        for _ in range(steps):
            k = np.bincount(dst[adopt[src]], minlength=self.n).astype(float)
            # eligible nonadopters with at least one adopted neighbour
            reachable = (~adopt) & self.eligible & (k > 0)
            if not reachable.any():
                break
            p_inf = 1.0 - (1.0 - tau) ** k
            new = reachable & (self.rng.random(self.n) < p_inf)
            adopt |= new
            hist.append(int(adopt.sum()))
        return adopt, hist

    def diffuse(self, seeds, tau=0.55, steps=60, verbose=False):
        """Reference (loop) finite-horizon adoption-mediated diffusion.

        Same semantics as `diffuse_fast`: a quiet stochastic round is not
        absorption; the loop continues until the horizon `steps` is reached
        or no eligible nonadopter has any adopted neighbour. History has one
        entry per round actually run (including the initial seed count).

        A round in which no eligible nonadopter happens to adopt (a quiet
        round) is not absorption: the process continues as long as at least
        one eligible nonadopter has an adopted neighbour. Only when no such
        node exists does the loop stop.
        """
        tau = self._validate_tau(tau)
        steps = int(steps)
        if steps < 0:
            raise ValueError("steps must be non-negative")
        adopt = np.zeros(self.n, dtype=bool)
        seeds = np.asarray(seeds, dtype=int)
        adopt[seeds[self.eligible[seeds]]] = True
        if adopt.sum() == 0:
            return adopt, [0]
        hist = [int(adopt.sum())]
        if tau == 0.0:
            # No transmission possible: stop after the seed round.
            return adopt, hist
        adj = self.neighbours()
        for _ in range(steps):
            # Determine existence of an eligible nonadopter with an adopted
            # neighbour *before* drawing any randomness. This separates the
            # structural stopping condition from the stochastic outcome of
            # the round, so a quiet round is not mistaken for absorption.
            candidates = []
            for i in np.where(self.eligible & ~adopt)[0]:
                for j in adj[i]:
                    if adopt[j]:
                        candidates.append(i)
                        break
            if not candidates:
                # No eligible nonadopter has any adopted neighbour: absorb.
                break
            new = []
            for i in candidates:
                if self.rng.random() < tau:
                    new.append(i)
            if new:
                adopt[new] = True
            hist.append(int(adopt.sum()))
        return adopt, hist


def run_once(**kw):
    v = Village(**kw)
    elig = np.where(v.eligible)[0]
    seeds = np.array([int(elig[len(elig) // 2])]) if len(elig) else np.array([v.n // 2])
    adopt, hist = v.diffuse_fast(seeds)
    gc = v.giant_component(v.eligible)
    return v, adopt, hist, gc
