"""Thin portable wrapper: final.py -> site comparison table."""
import sys
from pathlib import Path

_ROOT = Path(__file__).resolve().parents[2]
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

from run_diffusion import _ensure_dir, build_site_comparison, DEFAULT_OUTPUT_DIR  # noqa: E402


def main(output_dir: str = str(DEFAULT_OUTPUT_DIR)) -> None:
    out = _ensure_dir(Path(output_dir).resolve())
    build_site_comparison(out, None)
    print(f"[final] wrote {out / 'site_comparison.txt'}")


if __name__ == "__main__":
    main()
