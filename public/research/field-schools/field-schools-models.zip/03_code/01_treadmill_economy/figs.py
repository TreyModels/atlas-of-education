import sys, numpy as np
sys.path.insert(0, "/var/minis/workspace/cm")
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from config2 import Config, price_path
from model2 import run, Model

plt.rcParams.update({"font.size": 9, "axes.spines.top": False,
                     "axes.spines.right": False, "figure.dpi": 150})
OUT = "/var/minis/workspace/cm/"

arms = [("no extension", dict(ext_on=False), "#999999", "--"),
        ("FFS, unpriced", dict(ext_on=True), "#c0392b", "-"),
        ("FFS, priced", dict(ext_on=True, price_tag=True), "#1f4e79", "-")]

res = {}
for site in ("PH", "KE"):
    for lbl, kw, _, _ in arms:
        res[(site, lbl)] = run(Config(site=site, seed=11, **kw))

fig, axes = plt.subplots(1, 3, figsize=(9.4, 2.8))
for ax, (site, title) in zip(axes[:2], [("PH", "Philippines, irrigated lowland"),
                                        ("KE", "Kenya, rainfed")]):
    for lbl, _, col, ls in arms:
        m = res[(site, lbl)]; h = m.log
        yrs = np.array(h["year"]); x = np.array(h["x_mean"])
        yy = np.arange(2004, 2017)
        v = [x[yrs == y].mean() for y in yy]
        ax.plot(yy, v, ls, color=col, lw=1.8, label=lbl)
    ax.set_title(title, fontsize=9)
    ax.set_ylabel("mean intensity $x$" if site == "PH" else "")
    ax.set_ylim(0, 0.8)
    ax.tick_params(labelsize=8)
axes[0].legend(frameon=False, fontsize=7.5, loc="upper left")
ax = axes[2]
yy = np.arange(2004, 2017)
for site, ls in [("PH", "-"), ("KE", ":")]:
    m = res[(site, "FFS, priced")]; h = m.log
    yrs = np.array(h["year"])
    p = [np.mean([h["profit_irr"][j] for j in np.where(yrs == y)[0]]) for y in yy]
    ax.plot(yy, p, ls, color="#1f4e79", lw=1.8, label=f"{site} irrigated")
    pr = [np.mean([h["profit_rf"][j] for j in np.where(yrs == y)[0]]) for y in yy]
    ax.plot(yy, pr, ls, color="#c0392b", lw=1.8, label=f"{site} rainfed")
ax.axhline(0, color="k", lw=0.6)
ax.set_title("Profit per hectare, priced arm", fontsize=9)
ax.legend(frameon=False, fontsize=7, loc="upper left")
ax.tick_params(labelsize=8)
plt.tight_layout()
plt.savefig(OUT + "fig1_intensity.png", bbox_inches="tight")
plt.close()

fig, axes = plt.subplots(1, 2, figsize=(7.0, 2.8))
for ax, site in zip(axes, ("PH", "KE")):
    labels, ival, rval = [], [], []
    for lbl, _, _, _ in arms:
        m = res[(site, lbl)]; h = m.log
        yrs = np.array(h["year"]); late = yrs >= 2012
        labels.append(lbl.replace("FFS, ", ""))
        ival.append(np.mean(np.array(h["profit_irr"])[late]))
        rval.append(np.mean(np.array(h["profit_rf"])[late]))
    idx = np.arange(len(labels)); w = 0.36
    ax.bar(idx - w / 2, ival, w, color="#1f4e79", label="irrigated")
    ax.bar(idx + w / 2, rval, w, color="#c0392b", label="rainfed")
    ax.set_xticks(idx); ax.set_xticklabels(labels, fontsize=7.5, rotation=12)
    ax.set_title(site, fontsize=9)
    ax.axhline(0, color="k", lw=0.6)
axes[0].set_ylabel("mean profit, US$/ha/season")
axes[0].legend(frameon=False, fontsize=7)
plt.tight_layout()
plt.savefig(OUT + "fig2_profit.png", bbox_inches="tight")
plt.close()

fig, ax = plt.subplots(figsize=(4.6, 2.9))
for site, col in [("PH", "#1f4e79"), ("KE", "#c0392b")]:
    c = Config(site=site, ext_on=False, seed=11)
    m = Model(c); pp = price_path(c)
    yy = np.arange(2004, 2017)
    v = []
    for y in yy:
        p = pp[y]; w = c.S["w0"] * (1 + c.w_trend) ** (y - c.y0)
        px = c.S["px0"] * (1 + c.px_trend) ** (y - c.y0)
        v.append(m.value_of_tag(p, w, px).mean() * 2 * 100)
    ax.plot(yy, v, color=col, lw=1.8, label=site)
ax.axhline(15000, color="k", ls="--", lw=1)
ax.text(2004.2, 16200, "cost of one advisor", fontsize=7)
ax.set_ylabel("annual value of a price tag\n(US$, village of 100)")
ax.legend(frameon=False, fontsize=8)
ax.tick_params(labelsize=8)
plt.tight_layout()
plt.savefig(OUT + "fig3_wtp.png", bbox_inches="tight")
plt.close()
print("figures written")
