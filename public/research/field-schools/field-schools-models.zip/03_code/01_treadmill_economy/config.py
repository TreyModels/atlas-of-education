"""Configuration and historical series for the Crisis Machine ABM."""
import numpy as np
from dataclasses import dataclass, field, asdict

YEARS = list(range(2004, 2017))

# Real world rice price, indexed to 2004 = 1.00.
# Shape follows the FAO rice price index deflated at ~2%/yr: 2008 spike,
# 2011-12 second peak, long decline thereafter. See memo section 6.
P_RICE = {
    2004: 1.00, 2005: 1.04, 2006: 1.09, 2007: 1.17, 2008: 1.84,
    2009: 1.55, 2010: 1.44, 2011: 1.64, 2012: 1.57, 2013: 1.45,
    2014: 1.35, 2015: 1.17, 2016: 1.11,
}

# OECD DAC agriculture ODA, normalised to 2010 = 1.0.
# From thesis 1.6: 326m (2004) -> 92m (2007) -> 305m (2008) -> 545m (2010) -> halved 2012.
BUDGET = {
    2004: 0.60, 2005: 0.35, 2006: 0.20, 2007: 0.17, 2008: 0.56,
    2009: 0.75, 2010: 1.00, 2011: 0.95, 2012: 0.48, 2013: 0.35,
    2014: 0.32, 2015: 0.30, 2016: 0.30,
}


@dataclass
class Config:
    # ---- bookkeeping
    seed: int = 1
    n: int = 1200
    n_villages: int = 12
    seasons: int = 2                # wet and dry
    y0: int = 2004
    y1: int = 2016

    # ---- production
    sigma: float = 1.9              # CES capital-labour, Boppart et al.
    trad_share: float = 0.42        # yield at x=0 as fraction of potential
    A_mean: tuple = (8.0, 4.5, 2.8)  # irrigated, rainfed, upland potential t/ha
    A_sd: tuple = (0.9, 0.7, 0.5)
    m_alpha: float = 5.0            # management multiplier ~ Beta
    m_beta: float = 4.0
    ext_m_gain: float = 0.18
    m_ceiling: tuple = (0.74, 0.66, 0.62)        # extension raises m by at most this

    # ---- costs (US$/ha, 2004 prices)
    lab0: float = 75.0              # person-days per ha at x=0
    lab_mu: float = 0.35            # labour displaced per unit intensity
    kappa: float = 50.0             # management cost at x=1
    ext_kappa_gain: float = 0.45    # extension cuts kappa by at most this
    px0: float = 480.0              # cash input cost at x=1
    w0: float = 3.5                 # rural daily wage
    px_trend: float = -0.020        # input price trend (Boppart's capital TFP)
    w_trend: float = 0.030          # wage growth (structural transformation)

    # ---- prices
    p0: float = 380.0               # US$/t, 2004
    p_trend: float = -0.022         # real rice price trend
    use_hist_price: bool = True
    price_endog: float = 0.0        # 0 = exogenous, 1 = closed economy

    # ---- risk
    sigma_y: tuple = (0.13, 0.22, 0.28)
    lam: float = 1.2                # yield variance rises with x when rainfed

    # ---- behaviour
    q_base: float = 0.035           # safety-first threshold on P(pi < pi_min)
    q_wealth_scale: float = 0.11
    pi_min: float = 140.0           # subsistence requirement, US$/ha/season
    learn_own: float = 0.45
    learn_nb: float = 0.10
    learn_ext: float = 0.35

    # ---- wealth and land
    wealth_med: float = 220.0
    wealth_sig: float = 1.15
    land_mean: float = 1.30
    land_sig: float = 0.75

    # ---- extension
    ext_on: bool = True
    ffs_at_peak: int = 26           # FFS run per year when budget = 1.0
    ffs_class: int = 25
    targeting: str = "measured"
    target_noise: float = 0.55     # "measured" | "profit" | "random"
    curriculum: float = 1.0         # 1 = PalayCheck (legible), 0 = Palayamanan
    fidelity_hops: float = 3.0
    ext_decay: float = 0.12

    # ---- credit
    credit_share: float = 0.60
    credit_access: float = 0.55
    land_value: float = 250.0
    r_credit: float = 0.24
    savings: float = 0.10         # annual depreciation of extension gains

    # ---- exit
    exit_threshold: float = 0.62    # exit if farm income < this x wage income
    exit_prob: float = 0.35         # behavioural inertia
    urban_link: float = 0.30

    def d(self, **kw):
        c = asdict(self)
        c.update(kw)
        return Config(**c)


def price_path(cfg):
    """Real paddy price by year (US$/t)."""
    out = {}
    for y in YEARS:
        base = cfg.p0 * (1 + cfg.p_trend) ** (y - cfg.y0)
        if cfg.use_hist_price:
            out[y] = base * P_RICE[y]
        else:
            out[y] = base
    return out


def budget_path(cfg):
    return {y: (BUDGET[y] if cfg.ext_on else 0.0) for y in YEARS}
