"""Experiment harness: site x extension x price tag, plus market entry."""
import sys, json
import numpy as np
sys.path.insert(0, "/var/minis/workspace/cm")
from config2 import Config
from model2 import run

YEARS = list(range(2004, 2017))


def summarise(m, cfg):
    h = m.log
    yrs = np.array(h["year"])
    w = np.array(h["x_mean"])
    out = {"site": cfg.site, "ext": cfg.ext_on, "tag": cfg.price_tag,
           "adv": cfg.advisor_on}
    # late-period means, 2012-2016
    late = (yrs >= 2012)
    early = (yrs <= 2007)
    out["x_late"] = float(w[late].mean())
    out["x_early"] = float(w[early].mean())
    out["adopt_late"] = float(np.mean(np.array(h["adopt"])[late]))
    out["yield_late"] = float(np.mean(np.array(h["yield"])[late]))
    out["profit_irr"] = float(np.mean(np.array(h["profit_irr"])[late]))
    out["profit_rf"] = float(np.mean(np.array(h["profit_rf"])[late]))
    out["exits"] = int(np.sum(h["exits"]))
    out["active"] = int(h["active"][-1])
    out["reach"] = int(h["reach"][-1])
    out["advisors"] = int(np.max(h["advisors"]))
    out["gini"] = float(np.mean(np.array(h["gini"])[late]))
    # price response: output growth 2007->2008
    q = np.array(h["output"])
    out["dq_0807"] = float(q[8:10].mean() / q[6:8].mean() - 1)
    return out


def main():
    rows = []
    for site in ("PH", "KE"):
        for ext in (False, True):
            for tag in ((False, True) if ext else (False,)):
                cfg = Config(site=site, ext_on=ext, price_tag=tag, seed=7)
                rows.append(summarise(run(cfg), cfg))
        # market entry
        for tag in (False,):
            cfg = Config(site=site, ext_on=True, price_tag=tag,
                         advisor_on=True, seed=7)
            rows.append(summarise(run(cfg), cfg))
    print(f"{'site':4s} {'ext':5s} {'tag':5s} {'adv':4s} {'x_early':>7s} {'x_late':>6s} "
          f"{'adopt':>6s} {'yield':>6s} {'pi_irr':>7s} {'pi_rf':>7s} {'exits':>5s} {'adv':>4s} {'dQ0708':>7s}")
    for r in rows:
        print(f"{r['site']:4s} {str(r['ext']):5s} {str(r['tag']):5s} {str(r['adv']):4s} "
              f"{r['x_early']:7.2f} {r['x_late']:6.2f} {r['adopt_late']:6.2f} {r['yield_late']:6.2f} "
              f"{r['profit_irr']:7.0f} {r['profit_rf']:7.0f} {r['exits']:5d} {r['advisors']:4d} "
              f"{100*r['dq_0807']:6.1f}%")
    json.dump(rows, open("/var/minis/workspace/cm/results_grid.json", "w"), indent=1)


if __name__ == "__main__":
    main()
