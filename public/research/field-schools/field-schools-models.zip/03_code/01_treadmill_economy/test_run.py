import sys, numpy as np
sys.path.insert(0, "/var/minis/workspace/cm")
from config import Config
from model import run

cfg = Config()
m = run(cfg)
h = m.log
yrs = np.array(h["year"])
print(f"{'yr':>5} {'p':>6} {'yield':>6} {'y_irr':>6} {'y_rf':>6} {'x':>5} {'x_irr':>6} {'x_rf':>6} {'pro_irr':>8} {'pro_rf':>7} {'act':>5} {'ex':>4}")
for y in range(cfg.y0, cfg.y1 + 1):
    i = np.where(yrs == y)[0]
    def a(k): return np.nanmean([h[k][j] for j in i])
    print(f"{y:>5} {a('p'):6.0f} {a('yield'):6.2f} {a('yield_irr'):6.2f} {a('yield_rf'):6.2f} "
          f"{a('x_mean'):5.2f} {a('x_irr'):6.2f} {a('x_rf'):6.2f} {a('profit_irr'):8.0f} {a('profit_rf'):7.0f} "
          f"{int(a('active')):5d} {int(sum(h['exits'][j] for j in i)):4d}")
print("\nadoption (x>0.25):")
for y in range(cfg.y0, cfg.y1 + 1, 2):
    i = np.where(yrs == y)[0]
    print(y, round(np.mean([h['adopt'][j] for j in i]),3), round(np.mean([h['adopt_irr'][j] for j in i]),3), round(np.mean([h['adopt_rf'][j] for j in i]),3))
print("\ntotal exits:", int(sum(h["exits"])), "reach:", int(h["reach"][-1]))
print("mean profit/ha 2004:", round(np.nanmean(h["profit_ha"][0]),1), " 2016:", round(np.nanmean(h["profit_ha"][-1]),1))
