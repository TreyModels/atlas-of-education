"""The Crisis Machine ABM: farm layer plus a stylised extension machine."""
import numpy as np

from config import Config, YEARS, price_path, budget_path

XG = np.linspace(0.0, 1.0, 11)


from math import erf, sqrt


def phi_cdf(z):
    """Standard normal CDF without scipy."""
    z = np.clip(np.asarray(z, dtype=float), -8.0, 8.0)
    v = np.vectorize(erf)(z / sqrt(2.0))
    return 0.5 * (1.0 + v)


class Model:
    def __init__(self, cfg: Config):
        self.cfg = cfg
        rng = np.random.default_rng(cfg.seed)
        self.rng = rng
        n = cfg.n

        # ---- villages and systems
        self.village = rng.integers(0, cfg.n_villages, n)
        # irrigation probability declines with village index: early villages are
        # in the irrigated lowland, later ones upland.
        virr = 0.62 * np.exp(-2.1 * np.arange(cfg.n_villages) / cfg.n_villages)
        self.sys = np.zeros(n, dtype=int)
        for v in range(cfg.n_villages):
            idx = self.village == v
            u = rng.random(idx.sum())
            self.sys[idx] = np.where(u < virr[v], 0, np.where(u < virr[v] + 0.68, 1, 2))
        self.irr = (self.sys == 0).astype(float)

        # ---- land, wealth, potential, management
        self.L = np.clip(rng.lognormal(np.log(cfg.land_mean), cfg.land_sig, n), 0.2, 8.0)
        self.wealth = rng.lognormal(np.log(cfg.wealth_med), cfg.wealth_sig, n)
        A = np.array([cfg.A_mean[s] for s in self.sys])
        A *= np.exp(rng.normal(0, 0.12, n))
        self.A = A
        self.m = rng.beta(cfg.m_alpha, cfg.m_beta, n)
        self.m = np.clip(self.m, 0.15, 1.0)

        self.rho = (cfg.sigma - 1.0) / cfg.sigma
        self.delta = 1.0 - cfg.trad_share ** self.rho
        self.kappa = np.full(n, cfg.kappa)
        self.ext_dose = np.zeros(n)          # cumulative extension exposure

        # ---- beliefs
        self.scale_true = self.A * self.m
        self.scale_hat = self.scale_true * np.exp(rng.normal(0, 0.18, n))
        self.conf = np.full(n, 0.3)

        # ---- state
        self.x = np.zeros(n)
        self.active = np.ones(n, dtype=bool)
        self.age_in_farm = np.zeros(n)
        self.bad_years = np.zeros(n)
        self.has_credit = rng.random(n) < cfg.credit_access
        self.credit_line = cfg.credit_share * self.L * cfg.land_value * self.has_credit
        self.urban_link = rng.random(n) < cfg.urban_link
        self.q = np.clip(cfg.q_base + cfg.q_wealth_scale * np.exp(-self.wealth / 380.0), 0.03, 0.30)

        # ---- extension state
        self.trained = np.zeros(n, dtype=bool)
        self.reach_cum = 0

        # ---- outputs
        self.log = {k: [] for k in
                    ["year", "season", "p", "w", "px", "yield", "yield_irr",
                     "yield_rf", "x_mean", "adopt", "adopt_irr", "adopt_rf",
                     "profit_ha", "income", "exits", "active", "reach",
                     "measured", "gini", "x_irr", "x_rf", "profit_irr", "profit_rf", "output"]}

    # ---------------------------------------------------------------- biology
    def g(self, x):
        d, r = self.delta, self.rho
        return ((1.0 - d) + d * np.power(np.clip(x, 1e-9, 1.0), r)) ** (1.0 / r)

    def sigma_y(self, x):
        x = np.asarray(x, dtype=float)
        base = np.array([self.cfg.sigma_y[s] for s in self.sys])
        irr = self.irr
        if x.ndim == 2:
            base = base[:, None]
            irr = irr[:, None]
        return np.clip(
            base * (1.0 + self.cfg.lam * (1.0 - irr) * (x - 0.35)), 0.05, 0.85)

    # ---------------------------------------------------------------- economics
    def cost_per_ha(self, x, w, px):
        lab = w * self.cfg.lab0 * np.maximum(1.0 - self.cfg.lab_mu * x, 0.05)
        cash = px * x + self.kappa * x ** 2
        return lab + cash, cash

    def choose(self, p, w, px):
        """Safety-first choice over the intensity grid."""
        G = len(XG)
        scale = self.scale_hat[:, None]                    # (N,1)
        xg = XG[None, :]                                   # (1,G)
        mu_y = scale * self.g(xg)                          # (N,G)
        lab = w * self.cfg.lab0 * np.maximum(1 - self.cfg.lab_mu * xg, 0.05)
        cash = px * xg + self.kappa[:, None] * xg ** 2
        wealth_ha = (self.wealth / self.L)[:, None]
        credit_ha = (self.credit_line / self.L)[:, None]
        borrow = np.maximum(cash - wealth_ha, 0.0)
        interest = borrow * self.cfg.r_credit * 0.5
        c = lab + cash + interest

        e_pi = p * mu_y - c
        sy = np.array([self.cfg.sigma_y[s] for s in self.sys])[:, None]
        sd_y = self.sigma_y(xg) * mu_y
        sd_pi = np.maximum(p * sd_y, 1e-6)
        z = (self.cfg.pi_min - e_pi) / sd_pi
        p_fail = phi_cdf(z)

        feasible = (p_fail <= self.q[:, None]) & (cash <= wealth_ha + credit_ha + 1e-9)
        # always allow x=0 (subsistence is always possible)
        feasible[:, 0] = True
        e_pi_masked = np.where(feasible, e_pi, -1e9)
        choice = np.argmax(e_pi_masked, axis=1)
        return XG[choice], e_pi_masked[np.arange(len(choice)), choice], cash[np.arange(len(choice)), choice]

    # ---------------------------------------------------------------- one season
    def step(self, year, season, p, w, px):
        cfg = self.cfg
        idx = self.active
        if idx.sum() == 0:
            return

        x_new, e_pi, cash = self.choose(p, w, px)
        x_new = np.where(idx, x_new, 0.0)
        # adjustment friction: farmers move a third of the way each season
        adj = np.where(x_new < self.x, 0.12, 0.42)
        self.x = np.where(idx, (1 - adj) * self.x + adj * x_new, 0.0)

        sy = self.sigma_y(self.x)
        eps = self.rng.normal(0, 1, cfg.n) * sy - 0.5 * sy ** 2
        y_true = self.scale_true * self.g(self.x) * np.exp(eps)
        y_obs = y_true * np.exp(self.rng.normal(0, 0.06, cfg.n))
        p_eff = p * np.exp(self.rng.normal(0, 0.03, cfg.n))
        c, cash_i = self.cost_per_ha(self.x, w, px)
        profit = p_eff * y_obs - c
        profit = np.where(idx, profit, 0.0)

        # ---- learning: invert the observed yield for the implied scale
        implied = y_obs / np.maximum(self.g(self.x), 0.2)
        for v in range(cfg.n_villages):
            vi = (self.village == v) & idx
            if vi.sum() > 2:
                nb = np.median(implied[vi])
                self.scale_hat[vi] += cfg.learn_nb * (nb - self.scale_hat[vi])
        self.scale_hat += cfg.learn_own * (implied - self.scale_hat)
        self.conf = np.clip(self.conf + 0.05, 0, 1)
        self.scale_hat = np.clip(self.scale_hat, 0.2, 14.0)

        # ---- accumulation
        self.wealth = np.where(idx, self.wealth + cfg.savings * profit * self.L, self.wealth)
        self.wealth = np.maximum(self.wealth, 5.0)

        self._record(year, season, p, w, px, y_obs, profit, idx)

    # ---------------------------------------------------------------- extension
    def run_extension(self, year):
        cfg = self.cfg
        if not cfg.ext_on:
            return
        b = budget_path(cfg)[year]
        n_ffs = int(round(cfg.ffs_at_peak * b))
        if n_ffs <= 0:
            return
        n_treat = min(n_ffs * cfg.ffs_class, int(self.active.sum()))
        if n_treat <= 0:
            return

        cand = np.where(self.active)[0]
        if cfg.targeting == "measured":
            # rank by expected measured yield gain: highest A, irrigated first
            score = self.A
        elif cfg.targeting == "profit":
            # rank by expected profit gain at the margin, which is where the
            # modern package actually pays
            score = self.A * self.m * self.irr + 0.005 * self.rng.random(cfg.n)
        else:
            score = self.rng.random(cfg.n)
        score = score + cfg.target_noise * self.rng.random(cfg.n)
        order = cand[np.argsort(-score[cand])]
        pick = order[:n_treat]

        gain = cfg.ext_m_gain * cfg.curriculum
        ceiling = np.array([cfg.m_ceiling[s] for s in self.sys[pick]])
        self.m[pick] = self.m[pick] + gain * (ceiling - self.m[pick])
        self.kappa[pick] *= (1.0 - cfg.ext_kappa_gain * cfg.curriculum)
        A_demo = np.array([cfg.A_mean[s] for s in self.sys[pick]])
        self.scale_hat[pick] += cfg.learn_ext * (A_demo - self.scale_hat[pick])
        new = ~self.trained[pick]
        self.trained[pick] = True
        self.ext_dose[pick] += 1.0
        self.reach_cum += int(new.sum())
        self.scale_true = self.A * self.m

    def decay_extension(self):
        cfg = self.cfg
        self.m *= (1.0 - cfg.ext_decay * 0.35)
        self.kappa = np.minimum(self.kappa * (1.0 + 0.03), cfg.kappa)

    # ---------------------------------------------------------------- exit
    def exit_round(self, year, w):
        cfg = self.cfg
        h = self.log
        n = len(self.active)
        yrs = [i for i, y in enumerate(h["year"]) if y == year]
        if not yrs:
            return
        prof = np.array([h["profit_ha"][i] for i in yrs]).mean(axis=0)
        income_ha = prof.mean() if len(yrs) else 0.0
        per_ha = prof
        thresh = cfg.exit_threshold * w * 60.0
        self.bad_years = np.where(per_ha < thresh, self.bad_years + 1, 0)
        cand = self.active & (self.bad_years >= 2) & self.urban_link
        draw = self.rng.random(n) < cfg.exit_prob
        leavers = cand & draw
        if leavers.sum() == 0:
            return
        # land consolidation: land goes to the most profitable active farmer
        # in the same village
        for v in range(cfg.n_villages):
            vi = (self.village == v)
            lv = leavers & vi
            if lv.sum() == 0:
                continue
            free = self.L[lv].sum()
            rec = vi & self.active & ~leavers
            if rec.sum() == 0:
                continue
            best = np.argsort(-prof * vi)[: max(1, int(0.25 * rec.sum()))]
            best = best[rec[best]]
            if len(best) == 0:
                continue
            share = free / len(best)
            self.L[best] += share
            self.wealth[best] += 0.5 * share * 260.0     # pay something for the land
        self.active[leavers] = False
        self.L[leavers] = 0.0
        self.log["exits"][-1] = int(leavers.sum() + (self.log["exits"][-1] or 0))

    # ---------------------------------------------------------------- record
    def _record(self, year, season, p, w, px, y_true, profit, idx):
        h = self.log
        L = np.maximum(self.L, 1e-9)
        inc = profit * self.L
        h["year"].append(year); h["season"].append(season)
        h["p"].append(p); h["w"].append(w); h["px"].append(px)
        h["yield"].append(float(np.average(y_true[idx], weights=L[idx])) if idx.sum() else 0.0)
        for s, key in [(0, "yield_irr"), (1, "yield_rf")]:
            si = idx & (self.sys == s)
            h[key].append(float(np.average(y_true[si], weights=L[si])) if si.sum() else 0.0)
        h["x_mean"].append(float(np.average(self.x[idx], weights=L[idx])) if idx.sum() else 0.0)
        for s, key in [(0, "x_irr"), (1, "x_rf")]:
            si = idx & (self.sys == s)
            h[key].append(float(np.average(self.x[si], weights=L[si])) if si.sum() else 0.0)
        h["adopt"].append(float(np.average((self.x[idx] > 0.25).astype(float), weights=L[idx])) if idx.sum() else 0)
        for s, key in [(0, "adopt_irr"), (1, "adopt_rf")]:
            si = idx & (self.sys == s)
            h[key].append(float(np.average((self.x[si] > 0.25).astype(float), weights=L[si])) if si.sum() else 0)
        h["profit_ha"].append(np.where(idx, profit, np.nan))
        for s, key in [(0, "profit_irr"), (1, "profit_rf")]:
            si = idx & (self.sys == s)
            h[key].append(float(np.average(profit[si], weights=L[si])) if si.sum() else 0.0)
        tot = inc[idx]
        h["income"].append(float(tot.sum()))
        h["active"].append(int(idx.sum()))
        h["reach"].append(self.reach_cum)
        h["exits"].append(0)
        h["gini"].append(_gini(tot))
        # what the machine reports: demo-plot yield at full management
        demo = self.cfg.A_mean[0] * (1.005 ** (year - self.cfg.y0))
        h["measured"].append(demo * self.reach_cum / 1000.0)
        h["output"].append(float((y_true[idx] * L[idx]).sum()))


def _gini(v):
    if len(v) < 2:
        return 0.0
    v = np.sort(np.maximum(v, 0))
    n = len(v)
    idx = np.arange(1, n + 1)
    return float((2 * (idx * v).sum()) / (n * v.sum()) - (n + 1) / n)


def run(cfg: Config):
    m = Model(cfg)
    pp = price_path(cfg)
    for year in range(cfg.y0, cfg.y1 + 1):
        p_y = pp[year]
        w = cfg.w0 * (1 + cfg.w_trend) ** (year - cfg.y0)
        px = cfg.px0 * (1 + cfg.px_trend) ** (year - cfg.y0)
        m.run_extension(year)
        for s in range(cfg.seasons):
            # harvest-season price wobble
            p_s = p_y * (1.0 + 0.06 * (-1) ** s)
            m.step(year, s, p_s, w, px)
        m.exit_round(year, w)
        m.decay_extension()
    return m
