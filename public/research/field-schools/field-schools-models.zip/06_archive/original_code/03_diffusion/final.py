import sys, numpy as np
sys.path.insert(0,'.')
from diffusion import Village
SITES={
 "PH": dict(tenant_share=0.15,frac_lease=0.25,lease_share=0.25,price=340,dy=0.30,cost=70,wedge=0.13,liquidity_med=120),
 "KE": dict(tenant_share=0.0,frac_lease=0.05,lease_share=0.25,price=300,dy=0.40,cost=46,wedge=0.08,liquidity_med=60),
}
print(f"{'site':4s} {'rewire':>6s} {'elig':>5s} {'afford':>6s} {'giant':>6s} {'adopt':>6s} {'spread_p':>8s}")
for site,kw in SITES.items():
    for rw in (0.0,0.05,0.2):
        els,ads,gis=[],[],[]
        for sd in range(12):
            v=Village(seed=sd,rewiring=rw,**kw)
            e=np.where(v.eligible)[0]
            if len(e)==0: els.append(0);continue
            r=np.random.default_rng(sd*31+7)
            s=int(e[r.integers(0,len(e))])
            ad,_=v.diffuse_fast([s])
            els.append(v.eligible.mean()); ads.append(ad.mean()); gis.append(len(v.giant_component(v.eligible))/v.n)
        print(f"{site:4s} {rw:6.2f} {np.mean(els):5.2f} {0:6.0f} {np.mean(gis):6.2f} {np.mean(ads):6.2f} {np.mean([a>0.10 for a in ads]):8.2f}")
