import sys, numpy as np
sys.path.insert(0, "/var/minis/workspace/cm")
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from diffusion import Village

plt.rcParams.update({"font.size": 9, "axes.spines.top": False,
                     "axes.spines.right": False, "figure.dpi": 150})
OUT = "/var/minis/workspace/cm/"


def trial(ts, wedge, amb=0.0, price=300.0, seed=0, tau=0.55):
    v = Village(tenant_share=ts, wedge=wedge, ambiguity=amb, price=price, seed=seed)
    elig = np.where(v.eligible)[0]
    if len(elig) == 0:
        return 0.0, 0.0, []
    s = int(elig[v.rng.integers(0, len(elig))])
    ad, hist = v.diffuse_fast([s], tau=tau)
    return ad.mean(), len(v.giant_component(v.eligible)) / v.n, hist


# ---- Fig A: the cliff
tss = np.arange(0.0, 0.75, 0.025)
mean, lo, hi, giant = [], [], [], []
for ts in tss:
    vals, gs = [], []
    for sd in range(8):
        a, g, _ = trial(ts, 0.15, seed=sd)
        vals.append(a); gs.append(g)
    mean.append(np.mean(vals)); lo.append(np.percentile(vals, 10))
    hi.append(np.percentile(vals, 90)); giant.append(np.mean(gs))

fig, ax = plt.subplots(figsize=(5.4, 3.2))
ax.fill_between(tss, lo, hi, color="#1f4e79", alpha=0.15, lw=0)
ax.plot(tss, mean, color="#1f4e79", lw=2, label="knowledge adopted")
ax.plot(tss, giant, color="#c0392b", lw=1.4, ls="--", label="connected eligible set")
ax.axvline(0.41, color="k", lw=0.8, ls=":")
ax.text(0.415, 0.05, "site percolation\nthreshold", fontsize=7)
ax.set_xlabel("share of farmers who are share tenants")
ax.set_ylabel("share of village")
ax.set_ylim(0, 1.02)
ax.legend(frameon=False, fontsize=8, loc="lower left")
plt.tight_layout(); plt.savefig(OUT + "fig4_cliff.png", bbox_inches="tight"); plt.close()

# ---- Fig B: phase diagram
tsg = np.linspace(0.0, 0.7, 22)
wg = np.linspace(0.0, 0.45, 22)
Z = np.zeros((len(wg), len(tsg)))
for i, w in enumerate(wg):
    for j, t in enumerate(tsg):
        vals = [trial(t, w, seed=s)[0] for s in range(3)]
        Z[i, j] = np.mean(vals)

fig, ax = plt.subplots(figsize=(5.0, 3.6))
im = ax.imshow(Z, origin="lower", aspect="auto", cmap="magma",
               extent=[tsg[0], tsg[-1], wg[0], wg[-1]], vmin=0, vmax=1)
cs = ax.contour(tsg, wg, Z, levels=[0.1, 0.5], colors="w", linewidths=0.8)
ax.clabel(cs, fmt="%.1f", fontsize=7)
ax.set_xlabel("share tenancy")
ax.set_ylabel("market wedge (share of price lost to middlemen)")
ax.set_title("final adoption", fontsize=9)
plt.colorbar(im, ax=ax, fraction=0.045)
plt.tight_layout(); plt.savefig(OUT + "fig5_phase.png", bbox_inches="tight"); plt.close()

# ---- Fig C: paths, percolate vs die, and price reversal
fig, axes = plt.subplots(1, 2, figsize=(8.0, 3.0))
ax = axes[0]
for sd in range(8):
    a, g, hist = trial(0.40, 0.15, seed=sd)
    ax.plot(hist, lw=1.2, color="#1f4e79" if hist[-1] > 100 else "#c0392b",
            alpha=0.85)
ax.set_xlabel("contact rounds")
ax.set_ylabel("adopters")
ax.set_title("same village, same practice, eight seeds", fontsize=9)

ax = axes[1]
years = np.arange(2004, 2025)
p_path = 320 * (1 - 0.024) ** (years - 2004)
adopt_p = []
for y, p in zip(years, p_path):
    v = Village(tenant_share=0.30, wedge=0.15, price=float(p), seed=3)
    e = np.where(v.eligible)[0]
    if len(e) == 0:
        adopt_p.append(0.0); continue
    ad, _ = v.diffuse_fast([int(e[len(e) // 2])])
    adopt_p.append(ad.mean())
ax.plot(years, p_path / 320, color="#c0392b", lw=1.6, label="real price (index)")
ax.plot(years, adopt_p, color="#1f4e79", lw=1.8, label="adoption")
ax.set_ylim(0, 1.05)
ax.set_title("the treadmill as a cliff", fontsize=9)
ax.legend(frameon=False, fontsize=7.5, loc="lower left")
plt.tight_layout(); plt.savefig(OUT + "fig6_paths.png", bbox_inches="tight"); plt.close()
print("done")
