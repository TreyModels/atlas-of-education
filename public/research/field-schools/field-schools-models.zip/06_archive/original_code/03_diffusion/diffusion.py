"""A simple knowledge-diffusion model.

One unit of knowledge enters a village. Does it spread?

Farmers sit on a lattice. A practice is either held or not. It transmits on
contact. Whether a farmer who receives it keeps it depends on whether it pays:

    dpi_i = m_i * p * (1 - s_i) * dY - c

    m_i  share of the reference price actually received (market access)
    s_i  landlord's output share (tenancy)
    dY   yield gain of the practice
    c    cash cost per hectare

The point: adoption is not a slope, it is a cliff. What matters is whether the
set of farmers for whom the practice pays forms a connected mass big enough to
carry the knowledge, not whether it pays on average.
"""
import numpy as np
from collections import deque


class Village:
    def __init__(self, side=40, tenant_share=0.50, wedge=0.13, price=340.0,
                 dy=0.30, cost=70.0, turnover=0.50, rewiring=0.0, seed=0,
                 ambiguity=0.0, liquidity_med=120.0, liquidity_sig=1.1,
                 lease_share=0.25, frac_lease=0.25, risk=1.0):
        self.rng = np.random.default_rng(seed)
        self.side = side
        self.n = side * side
        n = self.n

        # ---- who is who
        # tenure: owners, leaseholders at the statutory rent, residual share tenants
        u = self.rng.random(n)
        self.tenant = u < tenant_share
        self.share = np.zeros(n)
        self.share[(u >= tenant_share) & (u < tenant_share + frac_lease)] = lease_share
        self.share[u < tenant_share] = turnover
        # market access: a spread from well connected to remote
        self.access = 1.0 - wedge * self.rng.random(n)

        # ---- does the practice pay?
        self.p = price
        self.dy = dy
        self.c = cost
        self.recompute()

        # ---- perception: without a price tag the farmer prices the package
        # at the pessimistic end of what it might cost
        self.ambiguity = ambiguity
        if ambiguity > 0:
            c_perc = cost * (1.0 + ambiguity)
            self.margin_perc = self.access * price * (1 - self.share) * dy - c_perc
        else:
            self.margin_perc = self.margin.copy()
        # liquidity: the cash cost has to be found before the season starts
        self.liquid = self.rng.lognormal(np.log(liquidity_med), liquidity_sig, n)
        self.afford = self.liquid >= cost
        self.risk = risk
        self.eligible = (self.margin_perc * risk > 0) & self.afford

        # ---- contact network
        self.edges = self._lattice_edges()
        if rewiring > 0:
            self._rewire(rewiring)

    # ------------------------------------------------------------------ net
    def _lattice_edges(self):
        s = self.side
        e = []
        for r in range(s):
            for c in range(s):
                i = r * s + c
                if c + 1 < s:
                    e.append((i, i + 1))
                if r + 1 < s:
                    e.append((i, i + s))
        return e

    def _rewire(self, omega):
        s = self.side
        new = []
        for (a, b) in self.edges:
            if self.rng.random() < omega:
                b = int(self.rng.integers(0, self.n))
                if b == a:
                    new.append((a, b))
                    continue
            new.append((a, b))
        self.edges = new

    def neighbours(self):
        if not hasattr(self, "_adj"):
            adj = [[] for _ in range(self.n)]
            for a, b in self.edges:
                adj[a].append(b)
                adj[b].append(a)
            self._adj = adj
        return self._adj

    # ------------------------------------------------------------------ econ
    def recompute(self, price=None):
        if price is not None:
            self.p = price
        self.margin = self.access * self.p * (1 - self.share) * self.dy - self.c
        return self.margin

    # --------------------------------------------------------- percolation
    def giant_component(self, mask):
        """Largest connected set of `mask` nodes in the full graph."""
        seen = np.zeros(self.n, dtype=bool)
        best = []
        for start in np.where(mask)[0]:
            if seen[start]:
                continue
            comp = []
            q = deque([start])
            seen[start] = True
            while q:
                v = q.popleft()
                comp.append(v)
                for w in self.neighbours()[v]:
                    if mask[w] and not seen[w]:
                        seen[w] = True
                        q.append(w)
            if len(comp) > len(best):
                best = comp
        return np.array(best, dtype=int)

    # ------------------------------------------------------------- dynamics
    def _edge_arrays(self):
        if not hasattr(self, "_ea"):
            a = np.array([e[0] for e in self.edges], dtype=int)
            b = np.array([e[1] for e in self.edges], dtype=int)
            self._ea = (np.concatenate([a, b]), np.concatenate([b, a]))
        return self._ea

    def diffuse_fast(self, seeds, tau=0.55, steps=80):
        src, dst = self._edge_arrays()
        adopt = np.zeros(self.n, dtype=bool)
        adopt[np.asarray(seeds)[self.eligible[np.asarray(seeds)]]] = True
        hist = [int(adopt.sum())]
        if not adopt.any():
            return adopt, hist
        for _ in range(steps):
            k = np.bincount(dst[adopt[src]], minlength=self.n).astype(float)
            p_inf = 1.0 - (1.0 - tau) ** k
            new = (~adopt) & self.eligible & (self.rng.random(self.n) < p_inf)
            if not new.any():
                break
            adopt |= new
            hist.append(int(adopt.sum()))
        return adopt, hist

    def diffuse(self, seeds, tau=0.55, steps=60, verbose=False):
        adopt = np.zeros(self.n, dtype=bool)
        seeds = np.asarray(seeds)
        adopt[seeds[self.eligible[seeds]]] = True
        if adopt.sum() == 0:
            return adopt, [0]
        hist = [int(adopt.sum())]
        adj = self.neighbours()
        for _ in range(steps):
            new = []
            for i in np.where(self.eligible & ~adopt)[0]:
                for j in adj[i]:
                    if adopt[j] and self.rng.random() < tau:
                        new.append(i)
                        break
            if not new:
                break
            adopt[new] = True
            hist.append(int(adopt.sum()))
        return adopt, hist


def run_once(**kw):
    v = Village(**kw)
    elig = np.where(v.eligible)[0]
    seeds = np.array([int(elig[len(elig) // 2])]) if len(elig) else np.array([v.n // 2])
    adopt, hist = v.diffuse_fast(seeds)
    gc = v.giant_component(v.eligible)
    return v, adopt, hist, gc
