import sys, numpy as np
sys.path.insert(0,'.')
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from diffusion import Village
plt.rcParams.update({"font.size":9,"axes.spines.top":False,"axes.spines.right":False,"figure.dpi":150})
def trial(ts,w,seed):
    v=Village(tenant_share=ts,wedge=w,seed=seed)
    e=np.where(v.eligible)[0]
    if len(e)==0: return 0.0,0.0
    s=int(e[v.rng.integers(0,len(e))])
    ad,_=v.diffuse_fast([s]); return ad.mean(), len(v.giant_component(v.eligible))/v.n
tss=np.arange(0.0,0.72,0.02); mean=[];lo=[];hi=[];giant=[]
for ts in tss:
    vals,gs=[],[]
    for sd in range(30):
        a,g=trial(ts,0.15,sd); vals.append(a); gs.append(g)
    mean.append(np.mean(vals)); lo.append(np.percentile(vals,10)); hi.append(np.percentile(vals,90)); giant.append(np.mean(gs))
    print(round(ts,2), round(np.mean(vals),3), end="  ", flush=True)
fig,ax=plt.subplots(figsize=(5.4,3.2))
ax.fill_between(tss,lo,hi,color="#1f4e79",alpha=0.15,lw=0)
ax.plot(tss,mean,color="#1f4e79",lw=2,label="knowledge adopted (mean, 80% band)")
ax.plot(tss,giant,color="#c0392b",lw=1.4,ls="--",label="size of connected eligible set")
ax.axvline(0.41,color="k",lw=0.8,ls=":")
ax.text(0.42,0.86,"site percolation\nthreshold",fontsize=7)
ax.set_xlabel("share of farmers who are share tenants"); ax.set_ylabel("share of village")
ax.set_ylim(0,1.02); ax.legend(frameon=False,fontsize=7.5,loc="lower left")
plt.tight_layout(); plt.savefig("fig4_cliff.png",bbox_inches="tight"); plt.close()
print("\nok")
