import sys, numpy as np
sys.path.insert(0,'.')
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from diffusion import Village
plt.rcParams.update({"font.size":9,"axes.spines.top":False,"axes.spines.right":False,"figure.dpi":150})

def trial(ts,w,price,seed):
    v=Village(tenant_share=ts,wedge=w,price=price,seed=seed)
    e=np.where(v.eligible)[0]
    if len(e)==0: return 0.0
    r=np.random.default_rng(seed*977+13)
    s=int(e[r.integers(0,len(e))])
    ad,_=v.diffuse_fast([s]); return ad.mean()

fig,axes=plt.subplots(1,2,figsize=(8.2,3.0))
ax=axes[0]
tss=np.arange(0.05,0.65,0.05); p=[]
for ts in tss:
    vals=[trial(ts,0.15,300.0,sd) for sd in range(24)]
    p.append(np.mean([v>0.10 for v in vals]))
ax.plot(tss,p,"o-",color="#1f4e79",lw=1.8,ms=4)
ax.set_xlabel("share tenancy"); ax.set_ylabel("probability the knowledge spreads")
ax.set_ylim(0,1.05); ax.set_title("the same programme, differently lucky",fontsize=9)

ax=axes[1]
years=np.arange(2004,2036); pp=320*(1-0.024)**(years-2004)
ad=[trial(0.30,0.15,float(x),5) for x in pp]
ax.plot(years,pp/320,color="#c0392b",lw=1.6,label="real price (index)")
ax.plot(years,ad,color="#1f4e79",lw=1.8,label="adoption")
ax.axvline(2029,color="k",lw=0.7,ls=":")
ax.set_ylim(0,1.05); ax.set_xlabel("")
ax.set_title("the treadmill as a cliff",fontsize=9)
ax.legend(frameon=False,fontsize=7.5,loc="lower left")
plt.tight_layout(); plt.savefig("fig6_paths.png",bbox_inches="tight"); plt.close()
print("ok")
