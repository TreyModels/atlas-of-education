import sys, numpy as np
sys.path.insert(0,'.')
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from diffusion import Village
plt.rcParams.update({"font.size":9,"axes.spines.top":False,"axes.spines.right":False,"figure.dpi":150})
ss=np.arange(0.0,0.62,0.02); mean=[];lo=[];hi=[]
for sv in ss:
    vals=[]
    for sd in range(20):
        v=Village(tenant_share=1.0,turnover=float(sv),frac_lease=0.0,
                  price=340,dy=0.30,cost=70,wedge=0.13,seed=sd)
        e=np.where(v.eligible)[0]
        if len(e)==0: vals.append(0.0); continue
        r=np.random.default_rng(sd*53+11); s0=int(e[r.integers(0,len(e))])
        ad,_=v.diffuse_fast([s0]); vals.append(ad.mean())
    mean.append(np.mean(vals)); lo.append(np.percentile(vals,10)); hi.append(np.percentile(vals,90))
fig,ax=plt.subplots(figsize=(5.6,3.3))
ax.fill_between(ss,lo,hi,color="#1f4e79",alpha=0.16,lw=0)
ax.plot(ss,mean,color="#1f4e79",lw=2)
for x,lab,c in [(0.0,"owner",'#2e7d32'),(0.25,"PD 27 leasehold\n(statutory rent)",'#e67e22'),(0.50,"share tenancy",'#c0392b')]:
    ax.axvline(x,color=c,lw=1.2,ls="--")
    ax.text(x+0.012,0.93,lab,fontsize=7,color=c,va="top")
ax.set_xlabel("landlord's share of the harvest"); ax.set_ylabel("share of village adopting")
ax.set_ylim(0,1.0)
plt.tight_layout(); plt.savefig("fig7_tenure.png",bbox_inches="tight"); plt.close()
print("ok", [round(m,2) for m in mean[::5]])
