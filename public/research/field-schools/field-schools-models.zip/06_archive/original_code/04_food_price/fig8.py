import sys, numpy as np
sys.path.insert(0,'.')
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from foodprice import Polity, planner
plt.rcParams.update({"font.size":9,"axes.spines.top":False,"axes.spines.right":False,"figure.dpi":150})

e=Polity(seed=3).run(); h=e.log
p=planner(seed=3); hp=p.log
yr=np.array(h['year']); w=np.array(h['world']); pd_=np.array(h['pd']); be=np.array(h['breakeven'])
pc=np.array(h['pc']); q=np.array(h['Q']); imp=np.array(h['imports']); farm=np.array(h['farmers'])

fig,ax=plt.subplots(1,3,figsize=(10.4,3.0))
a=ax[0]
a.fill_between(yr,pd_,w,color="#c0392b",alpha=0.18,lw=0,label="transfer out of farming")
a.plot(yr,w,color="#c0392b",lw=1.8,label="world price")
a.plot(yr,pd_,color="#1f4e79",lw=2,label="farmgate price")
a.plot(yr,be,"k--",lw=1.1,label="break-even")
a.set_title("what the farmer gets vs what the market pays",fontsize=9)
a.legend(frameon=False,fontsize=6.8,loc="upper left"); a.tick_params(labelsize=8)

a=ax[1]
a.plot(yr,farm/farm[0],color="#1f4e79",lw=1.8,label="farmers remaining")
a.plot(yr,imp/np.array(h["D"]),color="#c0392b",lw=1.8,label="import share of consumption")
a.set_title("the sector shrinks, the import bill grows",fontsize=9)
a.legend(frameon=False,fontsize=7); a.tick_params(labelsize=8)

a=ax[2]
dlw=np.diff(np.log(w)); dlp=np.diff(np.log(pd_))
up=dlw>0
a.scatter(dlw[up],dlp[up],s=26,color="#c0392b",label="world price rising")
a.scatter(dlw[~up],dlp[~up],s=26,color="#1f4e79",label="world price falling")
for m,c in [(up,"#c0392b"),(~up,"#1f4e79")]:
    if m.sum()>2:
        b=np.polyfit(dlw[m],dlp[m],1)
        xs=np.linspace(dlw[m].min(),dlw[m].max(),10)
        a.plot(xs,np.polyval(b,xs),color=c,lw=1.3,ls="--")
        a.text(0.04, 0.05 if c=="#1f4e79" else 0.10,
               ("falling" if c=="#1f4e79" else "rising")+f"  {b[0]:.2f}",
               color=c,fontsize=7.5,transform=a.transAxes)
lim=[min(dlw.min(),dlp.min())-.02,max(dlw.max(),dlp.max())+.02]
a.plot(lim,lim,"k:",lw=0.8)
a.set_xlabel("change in world price (log)"); a.set_ylabel("change in farmgate price (log)")
a.set_title("pass-through is asymmetric",fontsize=9); a.tick_params(labelsize=8)
a.legend(frameon=False,fontsize=7,loc="upper left")
plt.tight_layout(); plt.savefig("fig8_dilemma.png",bbox_inches="tight"); plt.close()

# pass-through regression
import numpy.linalg as la
X=np.column_stack([np.ones(len(dlw)),dlw,up.astype(float)*dlw])
beta=la.lstsq(X,dlp,rcond=None)[0]
print("pass-through: falling %.2f  rising %.2f"%(beta[1],beta[1]+beta[2]))
print("tax rate 2004-24: mean %.2f  max %.2f (%d)  min %.2f"%(np.mean(h['tax']),max(h['tax']),yr[int(np.argmax(h['tax']))],min(h['tax'])))
print("farmers %d -> %d ; imports %.0f -> %.0f"%(farm[0],farm[-1],imp[0],imp[-1]))
print("planner pd vs political pd 2008: %.0f vs %.0f"%(hp['pd'][4],h['pd'][4]))
print("planner farmers end %d vs %d"%(hp['farmers'][-1],farm[-1]))
