"""The food price dilemma.

A polity wants cheap food. Farmers want a price above their cost. The state
resolves this every year, and the resolution has a long-run consequence nobody
votes on: the sector it is taxing is the sector that would have made food cheap
later, without a subsidy.

The instrument is the farmgate price. The consumer price is the farmgate price
plus a marketing margin. If the country has to import, the treasury pays the
difference between the world price and what it charges consumers. That fiscal
link is what makes the dilemma bite: suppressing the farmgate price is free
until you run out of your own harvest, and then it is very expensive.
"""
import numpy as np

YEARS = list(range(2004, 2025))

PW = {2004: 1.00, 2005: 1.04, 2006: 1.09, 2007: 1.17, 2008: 1.84,
      2009: 1.55, 2010: 1.44, 2011: 1.64, 2012: 1.57, 2013: 1.45,
      2014: 1.35, 2015: 1.17, 2016: 1.11, 2017: 1.12, 2018: 1.10,
      2019: 1.09, 2020: 1.12, 2021: 1.35, 2022: 1.62, 2023: 1.45,
      2024: 1.38}


class Polity:
    def __init__(self, n=800, urban0=0.48, gamma=1.6, budget_share=0.020,
                 margin=40.0, cost=850.0, theta=0.45, seed=0,
                 subst=0.30, p_world=340.0, pop_growth=0.016,
                 exit_line=0.02, planner_mode=False):
        self.rng = np.random.default_rng(seed)
        self.n = n
        self.urban = urban0
        self.gamma = 1.0 if planner_mode else gamma
        self.budget_share = 0.0 if planner_mode else budget_share
        self.m = margin
        self.c = cost
        self.theta = theta
        self.subst = subst
        self.p_w = p_world
        self.pop_growth = pop_growth
        self.exit_line = exit_line

        self.land = np.clip(self.rng.lognormal(np.log(1.3), 0.65, n), 0.2, 8.0)
        self.apt = np.clip(self.rng.lognormal(np.log(3.6), 0.26, n), 1.4, 8.0)
        self.active = np.ones(n, dtype=bool)
        self.k = np.full(n, 0.7)
        self.below = np.zeros(n)

        self.log = {k: [] for k in
                    ["year", "world", "pd", "pc", "breakeven", "tax", "Q", "D",
                     "imports", "deficit", "farmers", "urban", "profit_ha", "k"]}

    # ------------------------------------------------------------------ farm
    def invest(self, pd):
        a, c, th = self.apt, self.c, self.theta
        kstar = (th * pd * a / c) ** (1.0 / (1.0 - th))
        self.k = np.where(self.active, np.clip(kstar, 0.05, 1.2), 0.0)

    def produce(self, pd):
        y = self.apt * self.k ** self.theta
        return y, pd * y - self.c * self.k

    def demand(self, pc):
        # inelastic, with a slow income drift
        return self.D0 * (pc / self.p_w) ** (-self.subst) * self.income

    # ------------------------------------------------------------- politics
    def choose_price(self, world, budget):
        """Grid the farmgate price; maximise political support subject to deficit."""
        grid = np.linspace(0.45, 1.25, 81) * world
        best, best_v = grid[0], -1e18
        w_u = self.urban ** self.gamma
        w_r = max(1.0 - self.urban, 1e-3)
        for pd in grid:
            self.invest(pd)
            y, _ = self.produce(pd)
            Q = float((y * self.land * self.active).sum())
            pc = pd + self.m
            D = self.demand(pc)
            M = max(D - Q, 0.0)
            deficit = M * max(world - pd, 0.0)
            if deficit > budget:
                continue
            v = w_u * (-(pc / world) * D) + w_r * np.log(max(pd, 1.0))
            if v > best_v:
                best_v, best = v, pd
        return best

    # ------------------------------------------------------------------ run
    def run(self):
        # self-sufficient at the baseline intensity
        self.invest(self.p_w)
        self.D0 = float((self.apt * self.k ** self.theta * self.land).sum())
        self.income = 1.0
        pop = 1.0
        gdp0 = self.p_w * self.D0
        for year in YEARS:
            world = self.p_w * PW[year]
            gdp = gdp0 * pop * (1.0 + 0.020 * (year - 2004))
            budget = self.budget_share * gdp

            pd = self.choose_price(world, budget)
            pc = pd + self.m

            self.invest(pd)
            y, profit = self.produce(pd)
            Q = float((y * self.land * self.active).sum())
            D = self.demand(pc)
            M = max(D - Q, 0.0)
            deficit = M * max(world - pd, 0.0)

            # exit is an opportunity-cost decision, not a bankruptcy one
            wage = 3.5 * (1.025 ** (year - 2004))
            farm_income = profit * self.land
            outside = 0.45 * wage * 250.0
            below = farm_income < outside
            self.below = np.where(below & self.active, self.below + 1, 0)
            self.active = self.active & ~(self.below >= 3)

            farm_share = self.active.sum() / self.n
            target = 1.0 - 0.52 * farm_share
            self.urban = float(np.clip(0.7 * self.urban + 0.3 * target, 0.30, 0.90))
            pop *= (1 + self.pop_growth)
            self.income *= 1.0 + 0.022

            self.log["year"].append(year); self.log["world"].append(world)
            self.log["pd"].append(pd); self.log["pc"].append(pc)
            self.log["breakeven"].append(self.c / np.median(self.apt))
            self.log["tax"].append(1.0 - pd / world)
            self.log["Q"].append(Q); self.log["D"].append(D)
            self.log["imports"].append(M)
            self.log["deficit"].append(deficit)
            self.log["farmers"].append(int(self.active.sum()))
            self.log["urban"].append(self.urban)
            self.log["profit_ha"].append(
                float(np.average(profit[self.active], weights=self.land[self.active]))
                if self.active.any() else 0.0)
            self.log["k"].append(float(self.k[self.active].mean()) if self.active.any() else 0.0)
        return self


def planner(**kw):
    return Polity(planner_mode=True, gamma=1.0, budget_share=0.0, **kw).run()
