import sys, numpy as np
sys.path.insert(0,'.')
from foodprice import Polity, planner
e=Polity(seed=3).run(); h=e.log
print(f"{'yr':>5} {'world':>6} {'pd':>6} {'pc':>6} {'b-e':>6} {'tax%':>6} {'Q':>7} {'D':>7} {'imp':>6} {'def':>8} {'farm':>5} {'urb':>5} {'pi/ha':>7}")
for i,y in enumerate(h['year']):
    print(f"{y:>5} {h['world'][i]:6.0f} {h['pd'][i]:6.0f} {h['pc'][i]:6.0f} {h['breakeven'][i]:6.0f} "
          f"{100*h['tax'][i]:6.1f} {h['Q'][i]:7.0f} {h['D'][i]:7.0f} {h['imports'][i]:6.0f} "
          f"{h['deficit'][i]:8.0f} {h['farmers'][i]:5d} {h['urban'][i]:5.2f} {h['profit_ha'][i]:7.0f}")
