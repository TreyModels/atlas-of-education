"""Portable CLI for the food-price dilemma model.

Usage:
    python run_foodprice.py [--output-dir DIR] [--quick] [--seed N]

Produces, under --output-dir (default 07_results/food-price):
    fig8_dilemma.png
    baseline_annual.csv
    counterfactual_annual.csv
    assumed_input_price.csv
    ols_coefficients.csv
    metadata.json

Honest labels:
  * The world-price path is a *supplied input assumption*, not independently
    verified observed data.
  * ``breakeven`` is an operating break-even (per-hectare operating cost /
    median aptitude). It excludes land, capital financing, family labour and
    the wage bill, so it is not a full-cost break-even.
  * The rising/falling regression in fig8 is *descriptive* on the simulated
    endogenous path. It is not an empirically estimated causal pass-through.
    Standard errors are reported for the individual OLS terms only; the
    combined rising/falling pass-through is reported as a point estimate
    without a standard error (its covariance is not propagated here).
  * The political counterfactual is a *political* counterfactual (gamma=1,
    budget_share=0, i.e. ZERO subsidy allowance). It is not a welfare planner,
    not an unlimited-budget planner, and its output is not a welfare optimum.
"""
import argparse
import hashlib
import json
import os
import platform
import sys
import time

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
FOODPRICE_DIR = os.path.join(HERE, "03_code", "04_food_price")
if FOODPRICE_DIR not in sys.path:
    sys.path.insert(0, FOODPRICE_DIR)

from foodprice import (  # noqa: E402
    Polity, political_counterfactual, BASELINE_PARAMS, PW, YEARS,
)

CORE_PATH = os.path.join(FOODPRICE_DIR, "foodprice.py")
RUNNER_PATH = os.path.abspath(__file__)


def _sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def _write_csv(path, header, rows):
    with open(path, "w") as f:
        f.write(",".join(header) + "\n")
        for r in rows:
            f.write(",".join(str(x) for x in r) + "\n")


def _annual_rows(log):
    keys = ["year", "world", "pd", "pc", "breakeven",
            "tax", "Q", "D", "imports", "import_share", "deficit",
            "farmers_producing", "farmers_end", "urban", "profit_ha", "k"]
    rows = []
    for i in range(len(log["year"])):
        rows.append([log[k][i] for k in keys])
    return keys, rows


def _ols(dlw, dlp, up):
    """Same regression as the old fig8: dlp ~ 1 + dlw + up*dlw.

    Returns (beta, se) where se are the OLS standard errors of the individual
    coefficients. The combined rising/falling pass-through is NOT given a
    standard error here because the covariance between beta[1] and beta[2]
    is not propagated.
    """
    X = np.column_stack([np.ones(len(dlw)), dlw, up.astype(float) * dlw])
    beta, *_ = np.linalg.lstsq(X, dlp, rcond=None)
    resid = dlp - X @ beta
    dof = max(len(dlw) - X.shape[1], 1)
    sigma2 = float(resid @ resid) / dof
    try:
        cov = sigma2 * np.linalg.inv(X.T @ X)
        se = np.sqrt(np.diag(cov))
    except np.linalg.LinAlgError:
        se = np.full(X.shape[1], np.nan)
    return beta, se


def _make_fig8(path, h, hp, beta):
    """Render fig8.

    The right panel uses the SAME common-intercept OLS interaction fit
    (``dlp ~ 1 + dlw + up*dlw``) that is written to ``ols_coefficients.csv``.
    No separate per-subgroup ``np.polyfit`` is used, so the plotted lines and
    the on-figure annotations match the exported coefficients exactly.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams.update({"font.size": 9, "axes.spines.top": False,
                         "axes.spines.right": False, "figure.dpi": 150})

    yr = np.array(h["year"])
    w = np.array(h["world"])
    pd_ = np.array(h["pd"])
    be = np.array(h["breakeven"])
    imp_share = np.array(h["import_share"])
    farm_end = np.array(h["farmers_end"])

    fig, ax = plt.subplots(1, 3, figsize=(10.4, 3.0))

    a = ax[0]
    a.fill_between(yr, pd_, w, color="#c0392b", alpha=0.18, lw=0,
                   label="model price wedge (world - farmgate)")
    a.plot(yr, w, color="#c0392b", lw=1.8,
           label="supplied world-price input (not verified observed data)")
    a.plot(yr, pd_, color="#1f4e79", lw=2, label="farmgate price")
    a.plot(yr, be, "k--", lw=1.1,
           label="operating break-even (excl. full costs/wage)")
    a.set_title("farmgate vs supplied world-price input", fontsize=9)
    a.legend(frameon=False, fontsize=6.2, loc="upper left")
    a.tick_params(labelsize=8)

    a = ax[1]
    a.plot(yr, farm_end / farm_end[0], color="#1f4e79", lw=1.8,
           label="farmers remaining (end-period)")
    a.plot(yr, imp_share, color="#c0392b", lw=1.8,
           label="import share of consumption")
    a.set_title("simulated sector and import share", fontsize=9)
    a.legend(frameon=False, fontsize=7)
    a.tick_params(labelsize=8)

    a = ax[2]
    dlw = np.diff(np.log(w))
    dlp = np.diff(np.log(pd_))
    up = dlw > 0
    a.scatter(dlw[up], dlp[up], s=26, color="#c0392b", label="world price rising")
    a.scatter(dlw[~up], dlp[~up], s=26, color="#1f4e79", label="world price falling")

    # Common-intercept OLS interaction fit (identical to ols_coefficients.csv):
    #   dlp = beta[0] + beta[1]*dlw + beta[2]*up*dlw
    # falling slope = beta[1]; rising slope = beta[1] + beta[2].
    b0, b1, b2 = float(beta[0]), float(beta[1]), float(beta[2])
    falling_slope = b1
    rising_slope = b1 + b2

    if up.any():
        xs_up = np.linspace(dlw[up].min(), dlw[up].max(), 10)
        a.plot(xs_up, b0 + rising_slope * xs_up, color="#c0392b", lw=1.3, ls="--")
    if (~up).any():
        xs_dn = np.linspace(dlw[~up].min(), dlw[~up].max(), 10)
        a.plot(xs_dn, b0 + falling_slope * xs_dn, color="#1f4e79", lw=1.3, ls="--")

    # Annotations placed in clear corners so they do not overlap the scatter.
    a.text(0.04, 0.94,
           f"rising  {rising_slope:.2f}",
           color="#c0392b", fontsize=7.5, transform=a.transAxes,
           va="top", ha="left")
    a.text(0.04, 0.86,
           f"falling  {falling_slope:.2f}",
           color="#1f4e79", fontsize=7.5, transform=a.transAxes,
           va="top", ha="left")

    lim = [min(dlw.min(), dlp.min()) - .02, max(dlw.max(), dlp.max()) + .02]
    a.plot(lim, lim, "k:", lw=0.8)
    a.set_xlabel("change in supplied world-price input (log)")
    a.set_ylabel("change in farmgate price (log)")
    a.set_title("descriptive pass-through on simulated path", fontsize=9)
    a.tick_params(labelsize=8)
    a.legend(frameon=False, fontsize=7, loc="lower right")

    plt.tight_layout()
    plt.savefig(path, bbox_inches="tight")
    plt.close(fig)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--output-dir", default=os.path.join(HERE, "07_results", "food-price"))
    ap.add_argument("--quick", action="store_true",
                    help="accepted for dispatcher compatibility; no effect on output")
    ap.add_argument("--seed", type=int, default=3,
                    help="RNG seed (default 3, matching the original fig8 run)")
    args = ap.parse_args(argv)

    os.makedirs(args.output_dir, exist_ok=True)
    t0 = time.time()

    seed = int(args.seed)
    baseline = Polity(seed=seed).run()
    counterfactual = political_counterfactual(seed=seed)
    h = baseline.log
    hp = counterfactual.log

    # --- annual CSVs
    keys, rows = _annual_rows(h)
    baseline_csv = os.path.join(args.output_dir, "baseline_annual.csv")
    _write_csv(baseline_csv, keys, rows)

    keys_c, rows_c = _annual_rows(hp)
    counterfactual_csv = os.path.join(args.output_dir, "counterfactual_annual.csv")
    _write_csv(counterfactual_csv, keys_c, rows_c)

    # --- assumed input price (status: undocumented)
    assumed_csv = os.path.join(args.output_dir, "assumed_input_price.csv")
    _write_csv(assumed_csv,
               ["year", "world_price_input", "status"],
               [[y, BASELINE_PARAMS["p_world"] * PW[y], "undocumented"]
                for y in YEARS])

    # --- OLS coefficients (same regression as old fig8)
    w = np.array(h["world"])
    pd_ = np.array(h["pd"])
    dlw = np.diff(np.log(w))
    dlp = np.diff(np.log(pd_))
    up = dlw > 0
    beta, se = _ols(dlw, dlp, up)
    ols_csv = os.path.join(args.output_dir, "ols_coefficients.csv")
    with open(ols_csv, "w") as f:
        f.write("term,estimate,std_error,note\n")
        f.write(f"intercept,{beta[0]},{se[0]},OLS descriptive\n")
        f.write(f"dlw,{beta[1]},{se[1]},OLS descriptive\n")
        f.write(f"up_x_dlw,{beta[2]},{se[2]},OLS descriptive\n")
        f.write(f"falling_passthrough,{beta[1]},{se[1]},OLS descriptive; point estimate\n")
        f.write(f"rising_passthrough,{beta[1] + beta[2]},,"
                "OLS descriptive; point estimate only, combined SE not "
                "propagated (covariance omitted)\n")

    # --- figure (uses the SAME OLS beta as the CSV above)
    fig_path = os.path.join(args.output_dir, "fig8_dilemma.png")
    _make_fig8(fig_path, h, hp, beta)

    # --- metadata
    runtime = time.time() - t0
    artifacts = {}
    for name in ["fig8_dilemma.png", "baseline_annual.csv",
                 "counterfactual_annual.csv", "assumed_input_price.csv",
                 "ols_coefficients.csv"]:
        p = os.path.join(args.output_dir, name)
        artifacts[name] = {"path": p, "sha256": _sha256(p),
                           "bytes": os.path.getsize(p)}
    metadata = {
        "note": ("Repaired food-price run. World-price path is a supplied "
                 "input assumption, not independently verified observed data. "
                 "breakeven excludes full costs and wage. "
                 "Rising/falling regression is descriptive on the simulated "
                 "endogenous path, not an empirically estimated causal "
                 "pass-through; combined rising/falling SE is not propagated. "
                 "Political counterfactual is gamma=1, budget_share=0 (ZERO "
                 "subsidy allowance); it is not a welfare planner and not an "
                 "unlimited-budget planner."),
        "baseline_params": {**BASELINE_PARAMS, "seed": seed},
        "seed": seed,
        "seed_source": "CLI --seed (default 3, matching original fig8 run)",
        "years": YEARS,
        "counterfactual": {
            "name": "political_counterfactual",
            "gamma": 1.0,
            "budget_share": 0.0,
            "label": "ZERO subsidy allowance; not welfare, not unlimited budget",
        },
        "source_sha256": {
            "core": {"path": CORE_PATH, "sha256": _sha256(CORE_PATH)},
            "runner": {"path": RUNNER_PATH, "sha256": _sha256(RUNNER_PATH)},
        },
        "runtime_seconds": runtime,
        "python": sys.version,
        "platform": platform.platform(),
        "numpy": np.__version__,
        "artifacts": artifacts,
    }
    meta_path = os.path.join(args.output_dir, "metadata.json")
    with open(meta_path, "w") as f:
        json.dump(metadata, f, indent=2)

    print(f"wrote {args.output_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
