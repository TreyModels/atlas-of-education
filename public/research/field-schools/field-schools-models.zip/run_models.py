"""Root dispatcher for model runs.

Usage:
    python run_models.py diffusion|food-price|all [--quick] [--output-dir DIR]

Imports no model modules at top level and never executes historical 01/02
scripts. Each target is invoked via an explicit function call or a
subprocess using ``sys.executable`` with paths relative to ``__file__``.

Output layout
-------------
* ``diffusion``   -> ``<output-dir>/diffusion`` (or ``07_results/diffusion``)
* ``food-price``  -> ``<output-dir>/food-price`` (or ``07_results/food-price``)
* ``all``         -> both children under ``<output-dir>`` (or ``07_results``)

When ``--output-dir`` is supplied, each target writes to a distinct child
directory so the two runs never collide. A missing runner is a hard error.
"""
import argparse
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT_ROOT = os.path.join(HERE, "07_results")


def _child_dir(root, name):
    return os.path.join(root, name)


def _run_food_price(quick, output_dir, seed=None):
    from run_foodprice import main as fp_main
    argv = []
    if output_dir:
        argv += ["--output-dir", output_dir]
    if quick:
        argv.append("--quick")
    if seed is not None:
        argv += ["--seed", str(seed)]
    return fp_main(argv)


def _run_diffusion(quick, output_dir):
    script = os.path.join(HERE, "run_diffusion.py")
    if not os.path.exists(script):
        raise FileNotFoundError(
            f"diffusion runner not found at {script}; cannot run diffusion")
    argv = [sys.executable, script]
    if output_dir:
        argv += ["--output-dir", output_dir]
    if quick:
        argv.append("--quick")
    return subprocess.call(argv)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("target", choices=["diffusion", "food-price", "all"])
    ap.add_argument("--quick", action="store_true")
    ap.add_argument("--output-dir", default=None,
                    help="root output directory; each target writes to a "
                         "distinct child (diffusion/, food-price/)")
    ap.add_argument("--seed", type=int, default=None,
                    help="seed for the food-price run (default: runner default 3)")
    args = ap.parse_args(argv)

    root = args.output_dir if args.output_dir else DEFAULT_ROOT
    rc = 0
    if args.target in ("food-price", "all"):
        fp_dir = _child_dir(root, "food-price")
        rc = _run_food_price(args.quick, fp_dir, args.seed) or rc
    if args.target in ("diffusion", "all"):
        diff_dir = _child_dir(root, "diffusion")
        rc = _run_diffusion(args.quick, diff_dir) or rc
    return rc


if __name__ == "__main__":
    raise SystemExit(main())
