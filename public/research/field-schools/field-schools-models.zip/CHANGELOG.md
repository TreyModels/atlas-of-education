# Changelog

## Unreleased — repaired research package

### Documentation
- Added `README.md` describing the two current models, their scope, and their
  caveats. It replaces the optimistic handover archived at
  `06_archive/README_original.md`.
- Added `VALIDATION.md` recording that validation is pending.
- Added this `CHANGELOG.md`.

### Model A — diffusion (`03_code/03_diffusion`)
- Documented the process as a finite-horizon, adoption-mediated binary
  process with no separate knowledge/use state; a quiet stochastic round is
  not absorption.
- Documented `risk` as an assumed probability that the gross yield benefit is
  realised before deducting cost; `risk = 1` is the default baseline and is
  not a claim about Kenya.
- Clarified that the illustrative proportional output share is not a
  calibrated statutory PD 27 rent.

### Model B — food price (`03_code/04_food_price`)
- Documented the political price objective with fixed aptitude and annually
  re-optimised input intensity and irreversible exit; not accumulation and
  not TFP.
- Documented `political_counterfactual` (gamma=1, budget_share=0) as a zero
  subsidy allowance, not a welfare planner; `planner()` deprecated.
- Documented the operating break-even as excluding the opportunity wage, with
  `farmers_end` recorded separately.
- Documented `PW` as an undocumented supplied index, not verified.

### Preserved
- `01_treadmill_economy` and `02_price_tag` untouched and superseded.
- Eight supplied figures preserved in `04_figures`.
- Original code preserved in `06_archive/original_code`.
- `SOURCE_MANIFEST.json` original hashes retained.

