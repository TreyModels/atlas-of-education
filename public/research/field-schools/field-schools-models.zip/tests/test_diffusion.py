"""Unit tests for the diffusion core.

Run with:  python -m unittest tests/test_diffusion.py
Only unittest + numpy are used. `sys.path` is set relative to this file so
that `diffusion` resolves to 03_code/03_diffusion/diffusion.py.
"""
import os
import sys
import unittest
from pathlib import Path

import numpy as np

_ROOT = Path(__file__).resolve().parents[1] / "03_code" / "03_diffusion"
_ROOT_STR = str(_ROOT)
if _ROOT_STR not in sys.path:
    sys.path.insert(0, _ROOT_STR)

from diffusion import Village, run_once  # noqa: E402


class _FixedRNG:
    """Deterministic RNG stub: returns a scripted sequence of uniforms.

    `random(n)` returns the next n values from the script (cycling if
    exhausted); `integers(lo, hi)` returns lo (used only by rewiring).
    """
    def __init__(self, script):
        self.script = list(script)
        self.i = 0

    def random(self, n=None):
        if n is None:
            v = self.script[self.i % len(self.script)]
            self.i += 1
            return v
        out = np.empty(n, dtype=float)
        for k in range(n):
            out[k] = self.script[self.i % len(self.script)]
            self.i += 1
        return out

    def integers(self, lo, hi):
        return lo


def _make_village(side=4, **kw):
    return Village(side=side, **kw)


def _chain(v, edges):
    v.edges = list(edges)
    if hasattr(v, "_adj"):
        del v._adj
    if hasattr(v, "_ea"):
        del v._ea


class TestQuietRoundNotAbsorption(unittest.TestCase):
    def test_fast_quiet_then_success(self):
        # 1-D chain 0-1-2-3; only node 0 seeded.
        v = _make_village(side=4)
        v.eligible[:] = True
        _chain(v, [(0, 1), (1, 2), (2, 3)])
        # Round 1: node 1 fails (u=0.9 > tau). Round 2: node 1 succeeds.
        # `diffuse_fast` draws `self.n` uniforms per round; script the first
        # round as all 0.9 (fail) and the second round as all 0.0 (succeed).
        n = v.n
        script = [0.9] * n + [0.0] * n
        v.rng = _FixedRNG(script)
        adopt, hist = v.diffuse_fast([0], tau=0.5, steps=5)
        self.assertTrue(adopt[1])
        self.assertGreaterEqual(len(hist), 3)

    def test_slow_quiet_then_success(self):
        v = _make_village(side=4)
        v.eligible[:] = True
        _chain(v, [(0, 1), (1, 2), (2, 3)])
        # `diffuse` draws one uniform per (eligible nonadopter, adopted
        # neighbour) attempt. Round 1: node 1 fails (0.9 > tau). Round 2:
        # node 1 succeeds (0.0 < tau).
        v.rng = _FixedRNG([0.9, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0])
        adopt, hist = v.diffuse([0], tau=0.5, steps=5)
        self.assertTrue(adopt[1])
        self.assertGreaterEqual(len(hist), 3)


class TestTauExtremes(unittest.TestCase):
    def test_tau1_reaches_connected_eligible_component(self):
        v = _make_village(side=6)
        v.eligible[:] = True
        adopt, hist = v.diffuse_fast([0], tau=1.0, steps=100)
        gc = v.giant_component(v.eligible)
        self.assertEqual(int(adopt.sum()), len(gc))
        adopt2, _ = v.diffuse([0], tau=1.0, steps=100)
        self.assertEqual(int(adopt2.sum()), len(gc))

    def test_tau0_stops_after_seed(self):
        v = _make_village(side=5)
        v.eligible[:] = True
        adopt, hist = v.diffuse_fast([0], tau=0.0, steps=10)
        self.assertEqual(int(adopt.sum()), 1)
        self.assertEqual(hist, [1])
        adopt2, hist2 = v.diffuse([0], tau=0.0, steps=10)
        self.assertEqual(int(adopt2.sum()), 1)
        self.assertEqual(hist2, [1])

    def test_horizon_limits_spread(self):
        v = _make_village(side=6)
        v.eligible[:] = True
        adopt, hist = v.diffuse_fast([0], tau=1.0, steps=1)
        # one round only: seed plus its immediate neighbours
        self.assertLessEqual(int(adopt.sum()), 5)
        self.assertEqual(len(hist), 2)

    def test_disconnected_eligible_component_unreached(self):
        v = _make_village(side=4)
        v.eligible[:] = True
        _chain(v, [(0, 1), (2, 3)])
        adopt, _ = v.diffuse_fast([0], tau=1.0, steps=10)
        self.assertTrue(adopt[0] and adopt[1])
        self.assertFalse(adopt[2] or adopt[3])


class TestRisk(unittest.TestCase):
    def test_risk1_baseline_algebra(self):
        v = _make_village(side=5, risk=1.0)
        gross = v.access * v.p * (1 - v.share) * v.dy
        np.testing.assert_allclose(v.gross, gross)
        np.testing.assert_allclose(v.margin, gross - v.c)
        np.testing.assert_allclose(v.margin_perc, gross - v.c)
        np.testing.assert_allclose(v.expected_margin, gross - v.c)
        np.testing.assert_allclose(v.expected_margin, v.margin)

    def test_lower_reliability_changes_eligibility(self):
        v = _make_village(side=6, risk=1.0)
        base = v.eligible.copy()
        self.assertTrue(base.any())
        v.risk = 0.0
        v.recompute()
        self.assertFalse(v.eligible.any())
        # restore
        v.risk = 1.0
        v.recompute()
        np.testing.assert_array_equal(v.eligible, base)

    def test_risk_enters_expected_margin_linearly(self):
        v = _make_village(side=5, risk=1.0)
        gross = v.gross.copy()
        v.risk = 0.5
        v.recompute()
        np.testing.assert_allclose(v.expected_margin, 0.5 * gross - v.c)
        # margin (actual full-benefit profit) is unaffected by risk
        np.testing.assert_allclose(v.margin, gross - v.c)

    def test_risk0p5_known_answer_positive_and_flips_eligibility(self):
        # Known-answer check: risk=0.5 is a strictly positive risk parameter
        # (not a claim about positive expected profit). Under the default
        # economics (gross <= 102, cost = 70) 0.5*gross - cost < 0 for all
        # nodes, so we do NOT assert any positive expected margin here.
        # Instead we construct a deterministic owner node whose gross is
        # large enough that risk=1 is eligible but risk=0.5 is not, and
        # verify the linear algebra on that node.
        v = _make_village(side=6, risk=1.0)
        # Deterministic owner: access=1, price=100, dy=1, share=0.
        # gross = 1 * 100 * (1 - 0) * 1 = 100.
        # risk=1:   expected_margin = 100 - 70 = 30 > 0  -> eligible
        # risk=0.5: expected_margin = 50  - 70 = -20 < 0 -> ineligible
        v.access[:] = 1.0
        v.share[:] = 0.0
        v.p = 100.0
        v.dy = 1.0
        v.afford[:] = True
        v.risk = 1.0
        v.recompute()
        self.assertTrue(np.all(v.eligible))
        np.testing.assert_allclose(v.gross, 100.0)
        np.testing.assert_allclose(v.expected_margin, 30.0)
        v.risk = 0.5
        v.recompute()
        self.assertFalse(np.any(v.eligible))
        np.testing.assert_allclose(v.expected_margin, -20.0)
        # Algebra preserved: expected_margin = 0.5 * gross - perceived_cost
        np.testing.assert_allclose(
            v.expected_margin, 0.5 * v.gross - v.perceived_cost
        )

    def test_invalid_risk_rejected(self):
        with self.assertRaises(ValueError):
            Village(side=4, risk=1.5)
        with self.assertRaises(ValueError):
            Village(side=4, risk=-0.1)


class TestRecompute(unittest.TestCase):
    def test_price0_clears_eligibility(self):
        v = _make_village(side=5)
        self.assertTrue(v.eligible.any())
        v.recompute(price=0.0)
        self.assertFalse(v.eligible.any())
        self.assertTrue(np.all(v.margin < 0))

    def test_price_change_refreshes_margins(self):
        v = _make_village(side=5)
        old_gross = v.gross.copy()
        old_margin = v.margin.copy()
        v.recompute(price=v.p * 2.0)
        self.assertFalse(np.allclose(v.gross, old_gross))
        self.assertFalse(np.allclose(v.margin, old_margin))
        np.testing.assert_allclose(v.gross, v.access * v.p * (1 - v.share) * v.dy)
        np.testing.assert_allclose(v.margin, v.gross - v.c)
        np.testing.assert_allclose(v.expected_margin, v.risk * v.gross - v.perceived_cost)


class TestRewiring(unittest.TestCase):
    def test_no_selfloops(self):
        v = _make_village(side=8, rewiring=0.5, seed=123)
        for a, b in v.edges:
            self.assertNotEqual(a, b)

    def test_rewiring_preserves_node_set(self):
        v = _make_village(side=6, rewiring=0.3, seed=7)
        for a, b in v.edges:
            self.assertTrue(0 <= a < v.n)
            self.assertTrue(0 <= b < v.n)


class TestReplay(unittest.TestCase):
    def test_fixed_seed_replay(self):
        v1 = _make_village(side=6, seed=42)
        v2 = _make_village(side=6, seed=42)
        np.testing.assert_array_equal(v1.eligible, v2.eligible)
        a1, h1 = v1.diffuse_fast([0], tau=0.6, steps=20)
        a2, h2 = v2.diffuse_fast([0], tau=0.6, steps=20)
        np.testing.assert_array_equal(a1, a2)
        self.assertEqual(h1, h2)

    def test_run_once_smoke(self):
        v, adopt, hist, gc = run_once(side=6, seed=1)
        self.assertGreaterEqual(len(hist), 1)
        self.assertTrue(hist[0] >= 0)


if __name__ == "__main__":
    unittest.main()
