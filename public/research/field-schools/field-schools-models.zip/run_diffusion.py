#!/usr/bin/env python3
"""Portable CLI for the knowledge-diffusion experiments.

Usage
-----
    python run_diffusion.py --quick
    python run_diffusion.py --output-dir 07_results/diffusion --seed-count 30

The script regenerates the four current figures (fig4 cliff, fig5 phase,
fig6 paths, fig7 tenure) using the *revised* Village API (unchanged public
arguments), writes per-run CSVs, aggregate/quantile tables, and a metadata
JSON describing source hashes, actual arguments, seeds, figure-to-table
mapping, runtime, and the illustrative status of the outputs.

Design notes
------------
* ``--quick`` runs a clearly smaller diagnostic grid; the default runs the
  original study grids and seed strategies where possible.
* Figures are written under ``<output-dir>/figures`` and never overwrite
  ``04_figures`` or ``06_archive``.
* Importing this module does not execute any experiment; only ``main()``
  (or the ``__main__`` guard) runs the pipeline.
* The p10-p90 band is the central 80% of the *simulation* range, not a
  confidence interval and not parameter uncertainty.
* The tenancy value 0.41 is a *scenario-specific* reference for the default
  grid; it is not a universal percolation threshold. Liquidity, leaseholding
  and finite horizons matter.
* The fig6 price-path panel uses independent static villages per price,
  not longitudinal switching.
* The fig7 tenure panel's 25% marker is an ILLUSTRATIVE proportional gross
  output share, not a statutory rent. RA 3844's 25% cap concerns net normal
  harvest after deductions; PD 27 ownership/amortization does not justify the
  current marginal gross share; no rent-law mechanism is implemented here.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import platform
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

# ---------------------------------------------------------------------------
# Matplotlib / cache configuration must happen before pyplot import.
# ---------------------------------------------------------------------------
os.environ.setdefault("MPLCONFIGDIR", os.path.join(os.getcwd(), ".mplcache"))
os.environ.setdefault("XDG_CACHE_HOME", os.path.join(os.getcwd(), ".cache"))
import matplotlib  # noqa: E402

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402

# ---------------------------------------------------------------------------
# Locate the diffusion module without machine-absolute sys.path entries.
# ---------------------------------------------------------------------------
_HERE = Path(__file__).resolve().parent
_DIFFUSION_DIR = _HERE / "03_code" / "03_diffusion"
if str(_DIFFUSION_DIR) not in sys.path:
    sys.path.insert(0, str(_DIFFUSION_DIR))

from diffusion import Village  # noqa: E402

plt.rcParams.update(
    {
        "font.size": 9,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "figure.dpi": 150,
    }
)

# ---------------------------------------------------------------------------
# Study settings (explicit; original vs revised behaviour documented in
# metadata and in the NOTES block of the accompanying report).
# ---------------------------------------------------------------------------
DEFAULT_OUTPUT_DIR = Path("07_results") / "diffusion"

# Original study grids (used unless --quick).
ORIGINAL = {
    "fig4": {
        "tenant_share": np.arange(0.0, 0.72, 0.02),
        "wedge": 0.15,
        "seeds": 30,
    },
    "fig5": {
        "tenant_share": np.linspace(0.0, 0.7, 22),
        "wedge": np.linspace(0.0, 0.45, 22),
        "seeds": 3,
    },
    "fig6": {
        "left_tenant_share": np.arange(0.05, 0.65, 0.05),
        "left_wedge": 0.15,
        "left_price": 300.0,
        "left_seeds": 24,
        "right_years": np.arange(2004, 2036),
        "right_price0": 320.0,
        "right_decline": 0.024,
        "right_tenant_share": 0.30,
        "right_wedge": 0.15,
        "right_seed": 5,
    },
    "fig7": {
        "share": np.arange(0.0, 0.62, 0.02),
        "seeds": 20,
        "tenant_share": 1.0,
        "frac_lease": 0.0,
        "price": 340.0,
        "dy": 0.30,
        "cost": 70.0,
        "wedge": 0.13,
    },
}

# Quick diagnostic grids (clearly smaller; not for publication).
QUICK = {
    "fig4": {
        "tenant_share": np.arange(0.0, 0.72, 0.10),
        "wedge": 0.15,
        "seeds": 4,
    },
    "fig5": {
        "tenant_share": np.linspace(0.0, 0.7, 6),
        "wedge": np.linspace(0.0, 0.45, 6),
        "seeds": 2,
    },
    "fig6": {
        "left_tenant_share": np.arange(0.05, 0.65, 0.15),
        "left_wedge": 0.15,
        "left_price": 300.0,
        "left_seeds": 4,
        "right_years": np.arange(2004, 2036, 4),
        "right_price0": 320.0,
        "right_decline": 0.024,
        "right_tenant_share": 0.30,
        "right_wedge": 0.15,
        "right_seed": 5,
    },
    "fig7": {
        "share": np.arange(0.0, 0.62, 0.10),
        "seeds": 4,
        "tenant_share": 1.0,
        "frac_lease": 0.0,
        "price": 340.0,
        "dy": 0.30,
        "cost": 70.0,
        "wedge": 0.13,
    },
}

# Site comparison settings (used by final.py wrapper and t3.py wrapper).
SITES: Dict[str, Dict[str, Any]] = {
    "PH": dict(
        tenant_share=0.15,
        frac_lease=0.25,
        lease_share=0.25,
        price=340,
        dy=0.30,
        cost=70,
        wedge=0.13,
        liquidity_med=120,
    ),
    "KE": dict(
        tenant_share=0.0,
        frac_lease=0.05,
        lease_share=0.25,
        price=300,
        dy=0.40,
        cost=46,
        wedge=0.08,
        liquidity_med=60,
    ),
}
SITE_REWIRING = (0.0, 0.05, 0.2)
SITE_SEEDS = 12


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def _source_hashes() -> Dict[str, str]:
    out: Dict[str, str] = {}
    for p in (_HERE / "run_diffusion.py", _DIFFUSION_DIR / "diffusion.py"):
        if p.exists():
            out[str(p.relative_to(_HERE))] = _sha256(p)
    return out


def _ensure_dir(p: Path) -> Path:
    p.mkdir(parents=True, exist_ok=True)
    return p


def _write_csv(path: Path, header: Sequence[str], rows: Iterable[Sequence[Any]]) -> None:
    import csv

    with open(path, "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(header)
        for r in rows:
            w.writerow(r)


def _seed_for(base: int, idx: int) -> int:
    """Deterministic seed strategy: base + idx (matches original loops)."""
    return int(base + idx)


def _trial_adoption(
    *,
    tenant_share: float,
    wedge: float,
    seed: int,
    price: float = 340.0,
    dy: float = 0.30,
    cost: float = 70.0,
    turnover: float = 0.50,
    frac_lease: float = 0.25,
    lease_share: float = 0.25,
    ambiguity: float = 0.0,
    tau: float = 0.55,
) -> Tuple[float, float, List[int]]:
    """Run one village and return (adoption_share, giant_share, history)."""
    v = Village(
        tenant_share=tenant_share,
        wedge=wedge,
        price=price,
        dy=dy,
        cost=cost,
        turnover=turnover,
        frac_lease=frac_lease,
        lease_share=lease_share,
        ambiguity=ambiguity,
        seed=seed,
    )
    elig = np.where(v.eligible)[0]
    if len(elig) == 0:
        return 0.0, 0.0, []
    s = int(elig[v.rng.integers(0, len(elig))])
    ad, hist = v.diffuse_fast([s], tau=tau)
    giant = len(v.giant_component(v.eligible)) / v.n
    return float(ad.mean()), float(giant), list(hist)


# ---------------------------------------------------------------------------
# Figure builders
# ---------------------------------------------------------------------------
def build_fig4(cfg: Dict[str, Any], out_dir: Path, seed_count: Optional[int]) -> Dict[str, Any]:
    tss = np.asarray(cfg["tenant_share"], dtype=float)
    wedge = float(cfg["wedge"])
    n_seeds = int(seed_count) if seed_count is not None else int(cfg["seeds"])

    rows: List[Tuple[Any, ...]] = []
    mean, lo, hi, giant = [], [], [], []
    for ts in tss:
        vals, gs = [], []
        for sd in range(n_seeds):
            a, g, _ = _trial_adoption(tenant_share=float(ts), wedge=wedge, seed=sd)
            vals.append(a)
            gs.append(g)
            rows.append((float(ts), wedge, sd, a, g))
        mean.append(float(np.mean(vals)))
        lo.append(float(np.percentile(vals, 10)))
        hi.append(float(np.percentile(vals, 90)))
        giant.append(float(np.mean(gs)))

    _write_csv(
        out_dir / "fig4_runs.csv",
        ["tenant_share", "wedge", "seed", "adoption", "giant_share"],
        rows,
    )
    _write_csv(
        out_dir / "fig4_aggregate.csv",
        ["tenant_share", "wedge", "mean_adoption", "p10", "p90", "mean_giant"],
        zip(tss, [wedge] * len(tss), mean, lo, hi, giant),
    )

    fig, ax = plt.subplots(figsize=(5.4, 3.2))
    ax.fill_between(tss, lo, hi, color="#1f4e79", alpha=0.15, lw=0,
                    label="central 80% of simulation range (p10-p90)")
    ax.plot(tss, mean, color="#1f4e79", lw=2, label="knowledge adopted (mean)")
    ax.plot(tss, giant, color="#c0392b", lw=1.4, ls="--",
            label="size of connected eligible set")
    ax.axvline(0.41, color="k", lw=0.8, ls=":")
    ax.text(0.42, 0.86, "0.41: scenario-specific\nreference, not universal",
            fontsize=7)
    ax.set_xlabel("share of farmers who are share tenants")
    ax.set_ylabel("share of village")
    ax.set_ylim(0, 1.02)
    ax.legend(frameon=False, fontsize=7.5, loc="lower left")
    plt.tight_layout()
    fig.savefig(out_dir / "figures" / "fig4_cliff.png", bbox_inches="tight")
    plt.close(fig)

    return {
        "figure": "fig4_cliff.png",
        "tables": ["fig4_runs.csv", "fig4_aggregate.csv"],
        "grid": {"tenant_share": tss.tolist(), "wedge": wedge, "seeds": n_seeds},
    }


def build_fig5(cfg: Dict[str, Any], out_dir: Path, seed_count: Optional[int]) -> Dict[str, Any]:
    tsg = np.asarray(cfg["tenant_share"], dtype=float)
    wg = np.asarray(cfg["wedge"], dtype=float)
    n_seeds = int(seed_count) if seed_count is not None else int(cfg["seeds"])

    Z = np.zeros((len(wg), len(tsg)))
    rows: List[Tuple[Any, ...]] = []
    for i, w in enumerate(wg):
        for j, t in enumerate(tsg):
            vals = []
            for sd in range(n_seeds):
                a, _, _ = _trial_adoption(tenant_share=float(t), wedge=float(w), seed=sd)
                vals.append(a)
                rows.append((float(t), float(w), sd, a))
            Z[i, j] = float(np.mean(vals))

    _write_csv(
        out_dir / "fig5_runs.csv",
        ["tenant_share", "wedge", "seed", "adoption"],
        rows,
    )
    _write_csv(
        out_dir / "fig5_grid.csv",
        ["tenant_share", "wedge", "mean_adoption"],
        [(float(t), float(w), float(Z[i, j]))
         for i, w in enumerate(wg) for j, t in enumerate(tsg)],
    )

    fig, ax = plt.subplots(figsize=(5.0, 3.6))
    im = ax.imshow(
        Z, origin="lower", aspect="auto", cmap="magma",
        extent=[tsg[0], tsg[-1], wg[0], wg[-1]], vmin=0, vmax=1,
    )
    cs = ax.contour(tsg, wg, Z, levels=[0.1, 0.5], colors="w", linewidths=0.8)
    ax.clabel(cs, fmt="%.1f", fontsize=7)
    ax.set_xlabel("share tenancy")
    ax.set_ylabel("market wedge (share of price lost to middlemen)")
    ax.set_title("final adoption (illustrative)", fontsize=9)
    fig.colorbar(im, ax=ax, fraction=0.045)
    plt.tight_layout()
    fig.savefig(out_dir / "figures" / "fig5_phase.png", bbox_inches="tight")
    plt.close(fig)

    return {
        "figure": "fig5_phase.png",
        "tables": ["fig5_runs.csv", "fig5_grid.csv"],
        "grid": {"tenant_share": tsg.tolist(), "wedge": wg.tolist(), "seeds": n_seeds},
    }


def build_fig6(cfg: Dict[str, Any], out_dir: Path, seed_count: Optional[int]) -> Dict[str, Any]:
    left_ts = np.asarray(cfg["left_tenant_share"], dtype=float)
    left_wedge = float(cfg["left_wedge"])
    left_price = float(cfg["left_price"])
    left_seeds = int(seed_count) if seed_count is not None else int(cfg["left_seeds"])

    years = np.asarray(cfg["right_years"], dtype=int)
    price0 = float(cfg["right_price0"])
    decline = float(cfg["right_decline"])
    right_ts = float(cfg["right_tenant_share"])
    right_wedge = float(cfg["right_wedge"])
    right_seed = int(cfg["right_seed"])

    # Left panel: probability the knowledge spreads.
    left_rows: List[Tuple[Any, ...]] = []
    p_spread: List[float] = []
    for ts in left_ts:
        vals = []
        for sd in range(left_seeds):
            a, _, _ = _trial_adoption(
                tenant_share=float(ts), wedge=left_wedge,
                price=left_price, seed=sd,
            )
            vals.append(a)
            left_rows.append((float(ts), left_wedge, left_price, sd, a))
        p_spread.append(float(np.mean([v > 0.10 for v in vals])))

    _write_csv(
        out_dir / "fig6_left_runs.csv",
        ["tenant_share", "wedge", "price", "seed", "adoption"],
        left_rows,
    )
    _write_csv(
        out_dir / "fig6_left_aggregate.csv",
        ["tenant_share", "wedge", "price", "p_spread"],
        zip(left_ts, [left_wedge] * len(left_ts), [left_price] * len(left_ts), p_spread),
    )

    # Right panel: independent static villages per price (NOT longitudinal).
    prices = price0 * (1.0 - decline) ** (years - years[0])
    right_rows: List[Tuple[Any, ...]] = []
    adopt_p: List[float] = []
    for y, p in zip(years, prices):
        a, _, _ = _trial_adoption(
            tenant_share=right_ts, wedge=right_wedge,
            price=float(p), seed=right_seed,
        )
        adopt_p.append(a)
        right_rows.append((int(y), float(p), right_ts, right_wedge, right_seed, a))

    _write_csv(
        out_dir / "fig6_right_runs.csv",
        ["year", "price", "tenant_share", "wedge", "seed", "adoption"],
        right_rows,
    )
    _write_csv(
        out_dir / "fig6_right_aggregate.csv",
        ["year", "price_index", "adoption"],
        [(int(y), float(p / price0), float(a)) for y, p, a in zip(years, prices, adopt_p)],
    )

    fig, axes = plt.subplots(1, 2, figsize=(8.2, 3.0))
    ax = axes[0]
    ax.plot(left_ts, p_spread, "o-", color="#1f4e79", lw=1.8, ms=4)
    ax.set_xlabel("share tenancy")
    ax.set_ylabel("probability the knowledge spreads")
    ax.set_ylim(0, 1.05)
    ax.set_title("the same programme, differently lucky", fontsize=9)

    ax = axes[1]
    ax.plot(years, prices / price0, color="#c0392b", lw=1.6,
            label="real price (index)")
    ax.plot(years, adopt_p, color="#1f4e79", lw=1.8, label="adoption")
    ax.axvline(2029, color="k", lw=0.7, ls=":")
    ax.set_ylim(0, 1.05)
    ax.set_xlabel("")
    ax.set_title("the treadmill as a cliff (static villages per price)", fontsize=9)
    ax.legend(frameon=False, fontsize=7.5, loc="lower left")
    plt.tight_layout()
    fig.savefig(out_dir / "figures" / "fig6_paths.png", bbox_inches="tight")
    plt.close(fig)

    return {
        "figure": "fig6_paths.png",
        "tables": [
            "fig6_left_runs.csv",
            "fig6_left_aggregate.csv",
            "fig6_right_runs.csv",
            "fig6_right_aggregate.csv",
        ],
        "grid": {
            "left_tenant_share": left_ts.tolist(),
            "left_wedge": left_wedge,
            "left_price": left_price,
            "left_seeds": left_seeds,
            "right_years": years.tolist(),
            "right_price0": price0,
            "right_decline": decline,
            "right_tenant_share": right_ts,
            "right_wedge": right_wedge,
            "right_seed": right_seed,
        },
        "note": "right panel uses independent static villages per price, not longitudinal switching",
    }


def build_fig7(cfg: Dict[str, Any], out_dir: Path, seed_count: Optional[int]) -> Dict[str, Any]:
    ss = np.asarray(cfg["share"], dtype=float)
    n_seeds = int(seed_count) if seed_count is not None else int(cfg["seeds"])
    tenant_share = float(cfg["tenant_share"])
    frac_lease = float(cfg["frac_lease"])
    price = float(cfg["price"])
    dy = float(cfg["dy"])
    cost = float(cfg["cost"])
    wedge = float(cfg["wedge"])

    rows: List[Tuple[Any, ...]] = []
    mean, lo, hi = [], [], []
    for sv in ss:
        vals = []
        for sd in range(n_seeds):
            a, _, _ = _trial_adoption(
                tenant_share=tenant_share,
                wedge=wedge,
                price=price,
                dy=dy,
                cost=cost,
                turnover=float(sv),
                frac_lease=frac_lease,
                seed=sd,
            )
            vals.append(a)
            rows.append((float(sv), tenant_share, frac_lease, sd, a))
        mean.append(float(np.mean(vals)))
        lo.append(float(np.percentile(vals, 10)))
        hi.append(float(np.percentile(vals, 90)))

    _write_csv(
        out_dir / "fig7_runs.csv",
        ["turnover", "tenant_share", "frac_lease", "seed", "adoption"],
        rows,
    )
    _write_csv(
        out_dir / "fig7_aggregate.csv",
        ["turnover", "mean_adoption", "p10", "p90"],
        zip(ss, mean, lo, hi),
    )

    fig, ax = plt.subplots(figsize=(5.6, 3.3))
    ax.fill_between(ss, lo, hi, color="#1f4e79", alpha=0.16, lw=0,
                    label="central 80% of simulation range (p10-p90)")
    ax.plot(ss, mean, color="#1f4e79", lw=2, label="mean adoption")
    for x, lab, c in [
        (0.0, "owner", "#2e7d32"),
        (0.25, "illustrative 25%\nproportional gross\noutput share", "#e67e22"),
        (0.50, "share tenancy", "#c0392b"),
    ]:
        ax.axvline(x, color=c, lw=1.2, ls="--")
        ax.text(x + 0.012, 0.93, lab, fontsize=7, color=c, va="top")
    ax.set_xlabel("landlord's share of the harvest")
    ax.set_ylabel("share of village adopting")
    ax.set_ylim(0, 1.0)
    ax.legend(frameon=False, fontsize=7.5, loc="lower left")
    plt.tight_layout()
    fig.savefig(out_dir / "figures" / "fig7_tenure.png", bbox_inches="tight")
    plt.close(fig)

    return {
        "figure": "fig7_tenure.png",
        "tables": ["fig7_runs.csv", "fig7_aggregate.csv"],
        "grid": {
            "share": ss.tolist(),
            "seeds": n_seeds,
            "tenant_share": tenant_share,
            "frac_lease": frac_lease,
            "price": price,
            "dy": dy,
            "cost": cost,
            "wedge": wedge,
        },
        "note": ("The 25% marker is an ILLUSTRATIVE proportional gross output "
                 "share, not a statutory rent. RA 3844's 25% cap concerns net "
                 "normal harvest after deductions; PD 27 ownership/amortization "
                 "does not justify the current marginal gross share; no rent-law "
                 "mechanism is implemented here."),
    }


# ---------------------------------------------------------------------------
# Site comparison (used by final.py and t3.py wrappers)
# ---------------------------------------------------------------------------
def build_site_comparison(out_dir: Path, seed_count: Optional[int] = None) -> Dict[str, Any]:
    n_seeds = int(seed_count) if seed_count is not None else SITE_SEEDS
    rows: List[Tuple[Any, ...]] = []
    summary: List[Tuple[Any, ...]] = []
    for site, kw in SITES.items():
        for rw in SITE_REWIRING:
            els, ads, gis, affs = [], [], [], []
            for sd in range(n_seeds):
                v = Village(seed=sd, rewiring=rw, **kw)
                e = np.where(v.eligible)[0]
                aff = float(v.afford.mean())
                if len(e) == 0:
                    els.append(0.0)
                    ads.append(0.0)
                    gis.append(0.0)
                    affs.append(aff)
                    rows.append((site, rw, sd, 0.0, aff, 0.0, 0.0))
                    continue
                r = np.random.default_rng(sd * 31 + 7)
                s = int(e[r.integers(0, len(e))])
                ad, _ = v.diffuse_fast([s])
                el = float(v.eligible.mean())
                gi = float(len(v.giant_component(v.eligible)) / v.n)
                els.append(el)
                ads.append(float(ad.mean()))
                gis.append(gi)
                affs.append(aff)
                rows.append((site, rw, sd, el, aff, gi, float(ad.mean())))
            summary.append((
                site, rw,
                float(np.mean(els)),
                float(np.mean(affs)),
                float(np.mean(gis)),
                float(np.mean(ads)),
                float(np.mean([a > 0.10 for a in ads])),
            ))

    _write_csv(
        out_dir / "site_comparison_runs.csv",
        ["site", "rewiring", "seed", "eligible", "afford", "giant", "adoption"],
        rows,
    )
    _write_csv(
        out_dir / "site_comparison_summary.csv",
        ["site", "rewiring", "eligible", "afford", "giant", "adoption", "spread_p"],
        summary,
    )

    # Text table (matches original final.py output format).
    lines = [f"{'site':4s} {'rewire':>6s} {'elig':>5s} {'afford':>6s} "
             f"{'giant':>6s} {'adopt':>6s} {'spread_p':>8s}"]
    for site, rw, el, aff, gi, ad, sp in summary:
        lines.append(
            f"{site:4s} {rw:6.2f} {el:5.2f} {aff:6.2f} {gi:6.2f} {ad:6.2f} {sp:8.2f}"
        )
    text = "\n".join(lines) + "\n"
    (out_dir / "site_comparison.txt").write_text(text)

    return {
        "table": "site_comparison.txt",
        "tables": ["site_comparison_runs.csv", "site_comparison_summary.csv"],
        "sites": list(SITES.keys()),
        "rewiring": list(SITE_REWIRING),
        "seeds": n_seeds,
    }


# ---------------------------------------------------------------------------
# Metadata
# ---------------------------------------------------------------------------
def _metadata(
    *,
    quick: bool,
    output_dir: Path,
    seed_count: Optional[int],
    figure_map: Dict[str, Any],
    runtime_s: float,
    status: str,
) -> Dict[str, Any]:
    return {
        "status": status,
        "quick": bool(quick),
        "output_dir": str(output_dir),
        "seed_count_override": seed_count,
        "source_hashes": _source_hashes(),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "numpy": np.__version__,
        "matplotlib": matplotlib.__version__,
        "runtime_seconds": round(runtime_s, 3),
        "figures": figure_map,
        "notes": [
            "p10-p90 band is the central 80% of the SIMULATION range, "
            "not a confidence interval and not parameter uncertainty.",
            "Tenancy 0.41 is a scenario-specific reference for the default "
            "grid, not a universal percolation threshold; liquidity, "
            "leaseholding and finite horizons matter.",
            "The tenure cliff is a parameter-induced conditional result.",
            "fig6 right panel uses independent static villages per price, "
            "not longitudinal switching.",
            "fig7's 25% marker is an ILLUSTRATIVE proportional gross output "
            "share, not a statutory rent. RA 3844's 25% cap concerns net "
            "normal harvest after deductions; PD 27 ownership/amortization "
            "does not justify the current marginal gross share; no rent-law "
            "mechanism is implemented.",
            "Site comparison uses actual computed affordability, not hardcoded 0.",
            "Outputs are illustrative; no new empirical claim is made.",
        ],
        "original_vs_revised": {
            "original": [
                "fig4/fig6/fig7 scripts hardcoded sys.path.insert(0, '.')",
                "figs2.py hardcoded /var/minis/workspace/cm",
                "final.py printed hardcoded 0 for affordability",
                "fig4/figs2 labelled 0.41 as 'site percolation threshold'",
                "fig6 right panel implied longitudinal switching",
                "fig7 labelled 25% as 'PD 27 leasehold (statutory rent)'",
            ],
            "revised": [
                "root run_diffusion.py with portable paths and --quick/--output-dir",
                "affordability computed from Village.afford",
                "0.41 labelled as scenario-specific reference, not universal",
                "fig6 right panel explicitly static villages per price",
                "fig7 25% labelled as illustrative proportional gross output share",
                "p10-p90 labelled as central 80% of simulation range",
                "figures written under <output-dir>/figures, never overwriting 04_figures or 06_archive",
            ],
        },
    }


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = argparse.ArgumentParser(
        description="Regenerate knowledge-diffusion figures and tables."
    )
    parser.add_argument("--quick", action="store_true",
                        help="run a smaller diagnostic grid (not for publication)")
    parser.add_argument("--output-dir", default=str(DEFAULT_OUTPUT_DIR),
                        help="output directory (default: 07_results/diffusion)")
    parser.add_argument("--seed-count", type=int, default=None,
                        help="override the number of seeds per grid point")
    parser.add_argument("--skip-sites", action="store_true",
                        help="skip the site comparison table")
    args = parser.parse_args(argv)

    out_dir = Path(args.output_dir).resolve()
    _ensure_dir(out_dir)
    _ensure_dir(out_dir / "figures")

    cfg = QUICK if args.quick else ORIGINAL
    status = "illustrative_quick" if args.quick else "illustrative"
    t0 = time.time()

    figure_map: Dict[str, Any] = {}
    figure_map["fig4"] = build_fig4(cfg["fig4"], out_dir, args.seed_count)
    figure_map["fig5"] = build_fig5(cfg["fig5"], out_dir, args.seed_count)
    figure_map["fig6"] = build_fig6(cfg["fig6"], out_dir, args.seed_count)
    figure_map["fig7"] = build_fig7(cfg["fig7"], out_dir, args.seed_count)
    if not args.skip_sites:
        figure_map["site_comparison"] = build_site_comparison(out_dir, args.seed_count)

    runtime = time.time() - t0
    meta = _metadata(
        quick=args.quick,
        output_dir=out_dir,
        seed_count=args.seed_count,
        figure_map=figure_map,
        runtime_s=runtime,
        status=status,
    )
    meta_path = out_dir / "metadata.json"
    meta_path.write_text(json.dumps(meta, indent=2))

    print(
        f"[run_diffusion] status={status} quick={args.quick} "
        f"output_dir={out_dir} runtime={runtime:.1f}s metadata={meta_path.name}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
