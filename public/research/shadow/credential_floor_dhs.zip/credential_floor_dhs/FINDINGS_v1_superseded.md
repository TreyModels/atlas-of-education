# Credential floor vs the Cambodia DHS 2021–22

**Result: the relational-floor version is rejected for Cambodia; human capital and positional survive.**

The Atlas credential-floor model (`reference/credential-floor.md`) named one table that would decide between its three structures for Cambodia: where school leavers come from by household wealth. The structures predicted the share coming from the poorest 40% of households as:

| Structure | Median | 5–95% band |
| --- | ---: | ---: |
| Human capital | 64.6% | 45.1–98.5% |
| Positional | 82.7% | 48.7–100% |
| Relational floor | 98.1% | 65.6–100% |

The Cambodia DHS 2021–22 Final Report, Table 2.12, gives secondary attendance ratios by wealth quintile for children age 12–18. Net attendance runs from 25.5% (poorest fifth) to 58.7% (richest), and gross attendance from 29.0% to 66.9%. Among children of secondary age who are not in secondary school, **47–58% live in the poorest 40% of households**. The range covers both attendance measures and child-population weights from equal to twice as many children in the poorest fifth as in the richest.

- **Relational floor: rejected.** Even the highest observed value (58.3%) is below the model's 5th percentile (65.6%). Leavers are not concentrated among the poor anywhere near as much as the relational floor predicts.
- **Human capital: consistent**, at the low end of its band. The median prediction (64.6%) is about 6 points above the highest observed value.
- **Positional: consistent** only at the bottom edge of its band. Its median (82.7%) is 24 points too high.

Most leavers come from the poorer half of households, but a large share also come from middle- and upper-income ones: about 41% of secondary-age children in the richest fifth are not in secondary school.

## Limits

- **Not the same quantity.** "Not in secondary" includes over-age pupils still in primary and children who never entered; the model counts exits from lower secondary. A matched test needs the DHS microdata (`hv121`, `hv122`, `hv105`, `hv270`), which require registration with the DHS Program.
- **Ages 12–18, not 14–17.** The published table uses the official secondary age range.
- **Child weights by quintile are assumed** (a range is shown). The household-population table is split into equal fifths of people, not of children.
- **One survey round**, fielded September 2021 to February 2022, during COVID school disruption.
- The model's prediction ranges come from its stored accepted draws (`relfloor_countries.json`, `exit_low`), not a rerun.

Source: National Institute of Statistics, Ministry of Health and ICF (2023), *Cambodia Demographic and Health Survey 2021–22 Final Report*, Table 2.12. https://www.dhsprogram.com/pubs/pdf/FR377/FR377.pdf
