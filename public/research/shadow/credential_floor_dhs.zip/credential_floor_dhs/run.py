"""Credential-floor test against the Cambodia DHS 2021-22.

Question (from reference/credential-floor.md in the Atlas): what share of young people out of school
come from the poorest 40% of households? The three model structures predicted, for Cambodia
(median and 5-95% band across accepted draws, relfloor_countries.json, key exit_low):
    human capital  64.6%  [45.1, 98.5]
    positional     82.7%  [48.7, 100]
    relational     98.1%  [65.6, 100]

Observed: Cambodia DHS 2021-22 Final Report (FR377), Table 2.12, secondary school net and gross
attendance ratios by household wealth quintile, children age 12-18 (de facto household population).
https://www.dhsprogram.com/pubs/pdf/FR377/FR377.pdf

Not attending secondary = 100 - NAR (or 100 - GAR). This counts children of secondary age who are not
in secondary school, including over-age pupils still in primary, so it is a proxy for the model's
"exits", not the same quantity. Children are not spread equally across quintiles (poorer households
have more of them), so the share is computed under a range of child-population weights.
Deterministic; pandas only; no network.
"""
import os
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "results")
os.makedirs(OUT, exist_ok=True)

t = pd.read_csv(os.path.join(HERE, "dhs_table_2_12.csv")).set_index("quintile")
order = ["lowest", "second", "middle", "fourth", "highest"]
t = t.loc[order]

# child-population weights across quintiles (lowest -> highest); equal is the floor, the others
# give poorer households progressively more secondary-age children
weights = {
    "equal": [1.0, 1.0, 1.0, 1.0, 1.0],
    "mild skew (lowest 1.25x highest)": [1.25, 1.19, 1.12, 1.06, 1.00],
    "strong skew (lowest 1.5x highest)": [1.50, 1.37, 1.25, 1.12, 1.00],
    "very strong skew (lowest 2x highest)": [2.00, 1.75, 1.50, 1.25, 1.00],
}
models = {"human capital": (45.1, 64.6, 98.5), "positional": (48.7, 82.7, 100.0),
          "relational": (65.6, 98.1, 100.0)}

rows = []
for measure, col in [("not in secondary (100 - NAR)", "nar_secondary_total"),
                     ("not in secondary (100 - GAR)", "gar_secondary_total")]:
    out = 100 - t[col]
    for wname, w in weights.items():
        mass = out.values * pd.Series(w, index=order).values
        share = 100 * mass[:2].sum() / mass.sum()
        rows.append(dict(measure=measure, child_weights=wname, share_from_poorest_40pct=round(share, 1)))
res = pd.DataFrame(rows)
res.to_csv(os.path.join(OUT, "share_from_poorest_40.csv"), index=False)

lo, hi = res.share_from_poorest_40pct.min(), res.share_from_poorest_40pct.max()
print("Share of secondary-age children not in secondary school who live in the poorest 40% of households")
print(res.to_string(index=False))
print(f"\nObserved range across measures and weights: {lo:.1f}% to {hi:.1f}%")

verdict = []
for m, (p5, p50, p95) in models.items():
    if hi < p5:
        v = "REJECTED: every observed value is below the model's 5th percentile"
    elif lo > p95:
        v = "REJECTED: every observed value is above the model's 95th percentile"
    else:
        v = "CONSISTENT: observed range overlaps the model's 90% band"
    verdict.append(dict(model=m, p5=p5, median=p50, p95=p95, observed_low=lo, observed_high=hi,
                        median_minus_observed_high=round(p50 - hi, 1), verdict=v))
vd = pd.DataFrame(verdict)
vd.to_csv(os.path.join(OUT, "verdicts.csv"), index=False)
print("\n" + vd.to_string(index=False))
