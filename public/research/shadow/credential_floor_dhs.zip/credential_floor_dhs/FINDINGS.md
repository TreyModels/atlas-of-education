# Credential floor vs Cambodia: v2 (13 Nov 2026)

**v1 of this bundle (`FINDINGS_v1_superseded.md`) compared 2021 survey data against the model's 2035 prediction.** The model file it read (`relfloor_countries.json`, `exit_low`) stores the value in the final simulated year, 2035. v2 reruns the model and reads the 2021 value. It also tests the model's own margin, lower-secondary completion, instead of "not in secondary, ages 12–18".

Observed: UIS lower-secondary completion by wealth quintile (CR.2.Q1–Q5, from DHS 2021–22) is 29.0, 47.6, 54.2, 65.7 and 78.9%. Of the non-completers, **55–64% are in the poorest 40% of households**. The range runs from equal child weights per quintile up to twice as many children in the poorest fifth.

| Structure | Predicted share, 2021, median [5–95%] | Draws inside observed range | Verdict |
|---|---|---|---|
| Human capital | 71% [54, 89] | 22% | consistent |
| Positional | 78% [59, 92] | 12% | consistent, high |
| Relational floor | 85% [69, 97] | 1.5% | **rejected**: observed maximum (64%) is below its 5th percentile |

The verdict on the relational floor stands, now on a matched definition and the right year. A new caveat comes with it: **no structure reproduces the full quintile profile.** Zero of 24,000 draws per structure fit all five quintiles within 10 points in both 2014 and 2021. The model makes a cliff at the liquidity threshold, and the data rise smoothly.

Full note: `reference/credential-floor.md`. Results: `reference/relfloor_countries_v2.json`. Code: `engine/relfloor_countries.py` (repo). The DHS Table 2.12 check in `run.py` is kept as a robustness check on a different definition.

## Update v2.1 (14 Nov 2026): the rejection does not survive a graded liquidity constraint

The model behind the table above has a hard liquidity threshold. That threshold is why it misses the quintile profile. With a graded constraint (`--smooth-liq`, one extra parameter), all three structures fit the full 2014 and 2021 quintile profiles: 64, 91 and 44 accepted draws. They then predict 57%, 58% and 58% of non-completers from the poorest 40%, all inside the observed 55–64%. The relational-weight posterior equals its prior (KS p = 0.55). **Verdict: these data do not discriminate the relational floor.** The rejection above is an artefact of the hard threshold.
