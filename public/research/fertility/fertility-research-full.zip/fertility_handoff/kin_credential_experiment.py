import json, numpy as np
from scipy.optimize import least_squares
from scipy.special import expit, softmax
D=json.load(open('asia_panel_data.json')); C=['PHL','THA','KOR','JPN','HKG','CHN']; n=np.arange(9); tastes=np.linspace(.45,2.35,15)
S={c:{k:{int(y):v for y,v in D[k+'_'+c]['values'].items()} for k in ['tfr','gdp']} for c in C}
# GDP is a proxy for broad economic development, not observed formalization.
def dev(c,t): return np.clip((np.log(S[c]['gdp'][t-5])-np.log(800))/(np.log(45000)-np.log(800)),0,1)
def target(x,p,kind):
 a,b,old,fixed,base,extra,tau,rate=p
 # The payoff from a surviving child falls as other old-age support expands.
 # Education cost rises linearly or at a common credential-access threshold.
 pressure=x if kind=='smooth' else expit(12*(x-tau))
 costs=base+b*x+extra*pressure
 utility=tastes[:,None]*a*np.log1p(n)+old*(1-x)*(1-(.25)**n)-costs*n-(fixed*x)*(n>0)
 return np.mean(np.sum(softmax(utility/.13,axis=1)*n,axis=1))
def path(c,p,kind,end=2024):
 f=S[c]['tfr'][1970]; out={1970:f};r=p[-1]
 for t in range(1971,end+1):
  f+=(target(dev(c,t),p,kind)-f)*r;out[t]=f
 return out
lo=[.05,0,0,0,.03,0,.05,.01];hi=[4,4,4,4,4,4,.95,.8]; initial=[1,.5,.8,.4,.2,.6,.55,.14]
def residual(p,kind):
 paths={c:path(c,p,kind,2009) for c in C}
 return np.array([paths[c][t]-S[c]['tfr'][t] for c in C for t in range(1975,2010,5)])
fitted={}
for kind in ['smooth','threshold']:
 opt=least_squares(residual,initial,args=(kind,),bounds=(lo,hi),max_nfev=100,ftol=.001)
 p=opt.x;fitted[kind]=p;pred={c:path(c,p,kind) for c in C};train=np.mean([abs(pred[c][t]-S[c]['tfr'][t]) for c in C for t in range(1975,2010,5)]);test=np.mean([abs(pred[c][t]-S[c]['tfr'][t]) for c in C for t in range(2010,2025)])
 print(kind,'train MAE',round(train,3),'test MAE',round(test,3),'params',np.round(p,3),'2024', {c:round(pred[c][2024],2) for c in C},flush=True)
 print('1970/1990/2009/2024', {c:[round(pred[c][t],2) for t in [1970,1990,2009,2024]] for c in C},flush=True)
print('observed', {c:[round(S[c]['tfr'][t],2) for t in [1970,1990,2009,2024]] for c in C})
# Resample whole countries to retain their time-series structure.
rng=np.random.default_rng(42);results=[]
for i in range(20):
 sample=list(rng.choice(C,6)); scores=[]
 for kind in ['smooth','threshold']:
  def fun(p):
   ps={c:path(c,p,kind,2009) for c in set(sample)}
   return np.array([ps[c][t]-S[c]['tfr'][t] for c in sample for t in range(1975,2010,5)])
  q=least_squares(fun,fitted[kind],bounds=(lo,hi),max_nfev=30,ftol=.005).x
  ps={c:path(c,q,kind) for c in C}
  scores.append(np.mean([abs(ps[c][t]-S[c]['tfr'][t]) for c in C for t in range(2010,2025)]))
 results.append(scores)
a=np.array(results);print('bootstrap threshold wins',int(sum(a[:,1]<a[:,0])),'of',len(a),'difference 5/50/95',np.round(np.quantile(a[:,1]-a[:,0],[.05,.5,.95]),3))
