"""What was the post-2015 shock? Twelve experiments. If smartphones are involved, what are they a proxy for?

Data beyond our panel (sources in SHOCK_FINDINGS.md):
  Births and marriages - Korea (Statistics Korea), Japan (MHLW), Hong Kong (Immigration Dept), China
    marriages (Ministry of Civil Affairs). China births marked approximate.
  Smartphone ownership (Pew 2015-17; Google 2013): year adult ownership passed about 50%, interpolated and
    approximate: KOR 2011, HKG 2012, CHN 2014, JPN 2016, THA 2016 (estimate), PHL 2018.
  Korea age-specific fertility 2002/2012/2022 and Philippines 2013/2017/2022 (already in the package).

X1  COVID test: how much of each place's 2015-24 fall below its development path happened before 2020?
X2  Break dating: best single kink year (2005-2020) in each place's gap series.
X3  Phone timing: does the kink follow each place's own smartphone adoption, or the calendar?
X4  Is a six-place synchronized fall historically unusual? (all nine-year windows since 1975)
X5  Economic slowdown across places: growth 2015-24 minus 2005-14 vs the fall.
X6  Economic shocks within places: yearly gap change vs last year's growth, before and after 2015.
X7  Fewer marriages or fewer births per marriage? Korea, Japan, Hong Kong, China; 2015-19 and 2019-24.
X8  Korea within marriage: official statement on married women's fertility.
X9  Age signature: which ages fell most (Korea 2012->2022; Philippines 2017->2022)?
X10 China's policy echo: how much of China's fall is the 2016-17 two-child bump unwinding?
X11 Proxy mechanisms in a cohort model: courtship displacement, social comparison (costlier children),
    anxiety and pessimism, childfree norm diffusion. Their signatures under marriage-bound and
    non-marital regimes.
X12 Scorecard: each candidate deeper cause against the evidence from X1-X11.
"""
import bisect, contextlib, io, json, os, runpy
import numpy as np
from openpyxl import load_workbook

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "results")
LINES, RES = [], {}


def say(s=""):
    print(s, flush=True); LINES.append(s)


with contextlib.redirect_stdout(io.StringIO()):
    TD = runpy.run_path(os.path.join(HERE, "timing_depth_test.py"))
TFR, Y, PL, SURV, LGDP = TD["TFR"], list(TD["YEARS"]), TD["PLACES"], TD["paths"]["M2 survival"], TD["LGDP"]
GAP = {c: TFR[c] - SURV[c] for c in PL}
yi = Y.index

# ================================================================ X1
say("X1. COVID TEST: SHARE OF THE 2015-24 FALL BELOW THE DEVELOPMENT PATH THAT CAME BEFORE 2020")
x1 = {}
for c in PL:
    tot = GAP[c][yi(2024)] - GAP[c][yi(2015)]; pre = GAP[c][yi(2019)] - GAP[c][yi(2015)]
    x1[c] = dict(total=float(tot), pre2020=float(pre), share_pre=float(pre / tot) if tot < 0 else float("nan"))
    say(f"  {c}: total {tot:+.2f}; by 2019 {pre:+.2f} ({pre/tot:.0%} of the fall before COVID)")
RES["X1"] = x1

# ================================================================ X2
say("\nX2. BREAK DATING: BEST KINK YEAR IN THE GAP (fit 1995-2024: line, then a change of slope)")
x2 = {}
m = np.array([1995 <= y <= 2024 for y in Y]); yy = np.array(Y)[m]
for c in PL:
    g = GAP[c][m]; best = None
    for k in range(2005, 2021):
        X = np.c_[np.ones_like(yy), yy - 1995, np.maximum(yy - k, 0)]
        b, res, *_ = np.linalg.lstsq(X, g, rcond=None)
        sse = float(np.sum((g - X @ b) ** 2))
        if best is None or sse < best[0]:
            best = (sse, k, b)
    x2[c] = dict(kink=best[1], slope_before=float(best[2][1]), slope_after=float(best[2][1] + best[2][2]))
    say(f"  {c}: kink {best[1]}; gap slope {best[2][1]:+.3f}/yr before -> {best[2][1]+best[2][2]:+.3f}/yr after")
RES["X2"] = x2

# ================================================================ X3
say("\nX3. PHONE TIMING: KINK YEAR vs YEAR ADULT SMARTPHONE OWNERSHIP PASSED ~50% (approximate)")
PH50 = {"KOR": 2011, "HKG": 2012, "CHN": 2014, "JPN": 2016, "THA": 2016, "PHL": 2018}
k = np.array([x2[c]["kink"] for c in PL]); p = np.array([PH50[c] for c in PL])
r = float(np.corrcoef(k, p)[0, 1])
for c in PL:
    say(f"  {c}: phones ~{PH50[c]}, kink {x2[c]['kink']} (lag {x2[c]['kink']-PH50[c]:+d})")
say(f"  Correlation of kink with adoption year {r:+.2f}; spread of kink years {k.min()}-{k.max()} (SD {k.std():.1f}) "
    f"vs adoption {p.min()}-{p.max()} (SD {p.std():.1f})")
RES["X3"] = dict(phone50=PH50, corr=r)

# ================================================================ X4
say("\nX4. HOW UNUSUAL IS A SYNCHRONIZED FALL? (nine-year windows: places whose gap fell by more than 0.2)")
x4 = []
for s in range(1975, 2016):
    n = sum(GAP[c][yi(s + 9)] - GAP[c][yi(s)] < -0.2 for c in PL)
    x4.append((s, n))
allsix = [s for s, n in x4 if n == 6]; five = [s for s, n in x4 if n >= 5]
say(f"  Windows with all six falling: {allsix if allsix else 'none'}; with five or more: {five}")
say(f"  Mean places falling per window before 2005: {np.mean([n for s, n in x4 if s < 2005]):.1f}")
RES["X4"] = dict(windows=x4, all_six=allsix)

# ================================================================ X5, X6
say("\nX5. ECONOMIC SLOWDOWN ACROSS PLACES (GDP per capita growth, % a year)")
x5 = {}
for c in PL:
    g1 = (LGDP[c][yi(2014)] - LGDP[c][yi(2005)]) / 9 * 100; g2 = (LGDP[c][yi(2024)] - LGDP[c][yi(2015)]) / 9 * 100
    x5[c] = dict(g_before=float(g1), g_after=float(g2), slowdown=float(g2 - g1), fall=x1[c]["total"])
    say(f"  {c}: growth {g1:.1f}% -> {g2:.1f}% (change {g2-g1:+.1f}); gap fall {x1[c]['total']:+.2f}")
sl = np.array([x5[c]["slowdown"] for c in PL]); fa = np.array([x5[c]["fall"] for c in PL])
say(f"  Correlation (bigger slowdown <-> bigger fall would be positive): {np.corrcoef(sl, fa)[0,1]:+.2f}")
RES["X5"] = dict(rows=x5, corr=float(np.corrcoef(sl, fa)[0, 1]))

say("\nX6. ECONOMIC SHOCKS WITHIN PLACES: yearly gap change vs previous year's growth (place-demeaned)")
x6 = {}
for lab, a, b in (("1990-2014", 1990, 2014), ("2015-2024", 2015, 2024)):
    xs, ys = [], []
    for c in PL:
        gr = np.diff(LGDP[c]) * 100; dg = np.diff(GAP[c])
        idx = [i for i in range(1, len(Y) - 1) if a <= Y[i + 1] <= b]
        xv = np.array([gr[i - 1] for i in idx]); yv = np.array([dg[i] for i in idx])
        xs.append(xv - xv.mean()); ys.append(yv - yv.mean())
    xs, ys = np.concatenate(xs), np.concatenate(ys)
    slope = float(xs @ ys / (xs @ xs)); rr = float(np.corrcoef(xs, ys)[0, 1])
    x6[lab] = dict(slope=slope, corr=rr)
    say(f"  {lab}: +1 point of growth last year -> gap change {slope:+.3f} this year (r = {rr:+.2f})")
RES["X6"] = x6

# ================================================================ X7
say("\nX7. FEWER MARRIAGES OR FEWER BIRTHS PER MARRIAGE? (births vs previous year's marriages)")
BM = {
    "KOR": {"births": {2016: 406243, 2019: 302676, 2020: 272000, 2024: 238317},
            "marr": {2015: 302828, 2018: 257622, 2019: 239159, 2023: 193700}},
    "JPN": {"births": {2016: 977000, 2024: 686061}, "marr": {2015: 635000, 2023: 474741}},
    "HKG": {"births": {2018: 54330, 2019: 53168, 2020: 41955, 2024: 36767},
            "marr": {2017: 50903, 2018: 49697, 2019: 44520, 2023: 47518}},
    "CHN": {"births": {2016: 17.86e6, 2024: 9.54e6}, "marr": {2015: 12.25e6, 2023: 7.68e6}},   # approximate
}
x7 = {}
COMP = [("KOR", 2016, 2019), ("KOR", 2019, 2024), ("KOR", 2016, 2024), ("JPN", 2016, 2024),
        ("HKG", 2018, 2024), ("HKG", 2019, 2020), ("CHN", 2016, 2024)]
for c, y1, y2 in COMP:
    b, mm = BM[c]["births"], BM[c]["marr"]
    rb = b[y2] / b[y1]; rm = mm[y2 - 1] / mm[y1 - 1]; rbpm = rb / rm
    share_m = float(np.log(rm) / np.log(rb)) if rb < 1 else float("nan")
    x7[f"{c} {y1}-{y2}"] = dict(births=float(rb), marriages=float(rm), births_per_marriage=float(rbpm), share_from_marriages=share_m)
    say(f"  {c} {y1}->{y2}: births x{rb:.2f}; marriages a year earlier x{rm:.2f}; births per marriage x{rbpm:.2f}"
        + (f" -> {share_m:.0%} of the fall from fewer marriages" if rb < 1 else ""))
say("  (China births approximate; births per marriage mixes first births of new couples with later births.)")
RES["X7"] = x7

# ================================================================ X8
say("\nX8. KOREA WITHIN MARRIAGE: Statistics Korea (2025): fertility of married women in their late 20s and early 30s")
say("  peaked in 2015, declined, and has been rising since 2022. A within-marriage fall from 2015, before COVID.")
RES["X8"] = "married women's fertility peaked 2015, fell, rising since 2022 (Statistics Korea, via Kathmandu Post/ANN)"

# ================================================================ X9
say("\nX9. AGE SIGNATURE: % CHANGE IN BIRTHS PER WOMAN BY AGE")
wb = load_workbook(io.BytesIO(open(os.path.join(HERE, "stone_stat_jm4h0u"), "rb").read()), data_only=True)
rows = [r for r in wb["Fig_2_5"].iter_rows(values_only=True) if isinstance(r[0], str) and r[0][:2].isdigit()]
KOR = {yv: np.array([float(r[i]) for r in rows]) for i, yv in [(1, 2002), (2, 2012), (3, 2022)]}
PHL = {2017: np.array([47, 131, 135, 114, 75, 29, 2], float), 2022: np.array([25, 84, 105, 95, 58, 21, 2], float)}
G = ["15-19", "20-24", "25-29", "30-34", "35-39", "40-44", "45-49"]
kch = (KOR[2022] - KOR[2012]) / np.maximum(KOR[2012], 1e-9); pch = (PHL[2022] - PHL[2017]) / PHL[2017]
say("  Korea 2012->2022: " + ", ".join(f"{g} {v:+.0%}" for g, v in zip(G, kch) if KOR[2012][G.index(g)] > 1))
say("  Philippines 2017->2022: " + ", ".join(f"{g} {v:+.0%}" for g, v in zip(G, pch)))
RES["X9"] = dict(korea=dict(zip(G, map(float, kch))), philippines=dict(zip(G, map(float, pch))))

# ================================================================ X10
say("\nX10. CHINA'S POLICY ECHO (two-child policy from 2016)")
c = "CHN"
say(f"  TFR 2015 {TFR[c][yi(2015)]:.2f}, 2016 {TFR[c][yi(2016)]:.2f}, 2017 {TFR[c][yi(2017)]:.2f}, 2019 {TFR[c][yi(2019)]:.2f}, "
    f"2024 {TFR[c][yi(2024)]:.2f}")
bump = TFR[c][yi(2017)] - TFR[c][yi(2015)]; fall = TFR[c][yi(2024)] - TFR[c][yi(2015)]
say(f"  The 2016-17 bump (+{bump:.2f}) was second births brought forward; the fall below the 2015 level is {fall:+.2f}. "
    f"Even ignoring the bump, China fell {fall/TFR[c][yi(2015)]:.0%} from 2015.")
RES["X10"] = dict(bump=float(bump), fall_from_2015=float(fall))

# ================================================================ X11
say("\nX11. WHAT COULD PHONES BE A PROXY FOR? Signatures of four proxy mechanisms in a cohort model")


def cohort(gap=0.8, meet=0.20, cost=1.6, kin=0.3, nonmarital=0.0, intent=1.0, childfree=0.0, n=6000, seed=7):
    rng = np.random.default_rng(seed)
    zm = rng.normal(0, 1, n); zw = rng.normal(gap, 1, n)
    m_entry = 21 + 2 * (zm > 0.1); w_entry = 20 + 2 * (zw > 0.1) + (cost - 1)
    has_kin = rng.random(n) < kin; eff = cost * (1 - 0.5 * has_kin) / 0.7
    cf_ = rng.random(n) < childfree
    free = np.ones(n, bool); mar = np.zeros(n, bool); par = np.zeros(n, int); first_age = np.full(n, np.nan)
    for age in range(18, 46):
        elig = np.flatnonzero(free & (age >= m_entry)); o = np.argsort(zm[elig]); pz = list(zm[elig][o]); pid = list(elig[o])
        women = np.flatnonzero(~mar & (age >= w_entry) & (rng.random(n) < meet)); rng.shuffle(women)
        for w in women:
            lo = bisect.bisect_left(pz, zw[w] - 0.55)
            if lo < len(pz):
                kk = lo + int(rng.integers(len(pz) - lo)); mm_ = pid.pop(kk); pz.pop(kk); free[mm_] = False; mar[w] = True
        base = np.select([par == 0, par == 1, par == 2], [0.45, 0.22, 0.06], 0.01) * intent
        hz = base / np.where(par == 0, eff ** 0.5, eff) * (1.0 if age < 35 else max(0, (45 - age) / 10))
        u = rng.random(n)
        born = ~cf_ & ((mar & (u < hz)) | (~mar & (age >= 24) & (u < hz * nonmarital)))
        first_age[born & (par == 0)] = age
        par += born
    return dict(cf=par.mean(), em=mar.mean(), pm=par[mar].mean(), p1=(par >= 1).mean(),
                p2=(par >= 2).sum() / max((par >= 1).sum(), 1), age1=float(np.nanmean(first_age)))


PROX = {"Courtship displacement (meeting rate -40%)": dict(meet=0.12),
        "Social comparison / intensive parenting (child cost x1.4)": dict(cost=1.6 * 1.4),
        "Anxiety and pessimism (birth intent x0.8, meeting -15%)": dict(intent=0.8, meet=0.17),
        "Childfree norm spreads (15% opt out of children)": dict(childfree=0.15)}
x11 = {}
for regime, nm in (("marriage-bound", 0.0), ("non-marital common", 0.45)):
    b = cohort(nonmarital=nm)
    for lab, kw in PROX.items():
        r = cohort(nonmarital=nm, **kw)
        d_cf = r["cf"] - b["cf"]
        share_m = 0.5 * (b["em"] - r["em"]) * (b["pm"] + r["pm"]) / (-d_cf) if d_cf < 0 else float("nan")
        x11.setdefault(lab, {})[regime] = dict(change_pct=float(d_cf / b["cf"]), share_from_marriage=float(share_m),
                                               first=float(r["p1"] - b["p1"]), second=float(r["p2"] - b["p2"]),
                                               age_first=float(r["age1"] - b["age1"]))
for lab, d in x11.items():
    mb, nmr = d["marriage-bound"], d["non-marital common"]
    ratio = nmr["change_pct"] / mb["change_pct"] if mb["change_pct"] else float("nan")
    d["regime_ratio"] = float(ratio)
    say(f"  {lab}")
    say(f"     marriage-bound: {mb['change_pct']:+.0%} ({mb['share_from_marriage']:.0%} via fewer marriages; first births {mb['first']:+.2f}, "
        f"P(2nd|1st) {mb['second']:+.2f}, first-birth age {mb['age_first']:+.1f}y); non-marital regime: {nmr['change_pct']:+.0%} "
        f"(ratio {ratio:.2f})")
RES["X11"] = x11

# ================================================================ X12
say("\nX12. SCORECARD: CANDIDATE CAUSES AGAINST THE EVIDENCE (+ fits, - contradicts, ? silent)")
evidence = ["Under way before COVID (X1, X8)", "Hits non-marital regimes too (B3, X11)",
            "Births per marriage fall pre-COVID (X7)", "Second births hit hardest (Korea S3, X11)",
            "Tracks local phone adoption (X3)", "Tracks the economy (X5, X6)"]
cards = {
    "COVID":                                          ["-", "+", "-", "?", "n/a", "?"],
    "Economic precarity / pessimism":                 ["+", "+", "+", "+", "n/a", "partly"],
    "Courtship displacement (phone proxy)":           ["+", "-", "-", "-", "-", "?"],
    "Social comparison, intensive parenting (proxy)": ["+", "+", "+", "+", "-", "?"],
    "Anxiety and pessimism (proxy)":                  ["+", "+", "+", "+", "-", "partly"],
    "Childfree norm diffusion (proxy)":               ["+", "+", "+", "-", "-", "?"],
    "Microplastics / biology":                        ["+", "+", "+", "-", "n/a", "?"],
}
for k2, v in cards.items():
    say(f"  {k2:48s} " + " | ".join(v))
say("  Columns: " + " | ".join(evidence))
RES["X12"] = dict(evidence=evidence, cards=cards)

with open(os.path.join(OUT, "shock_suite.txt"), "w") as f:
    f.write("\n".join(LINES) + "\n")
json.dump(RES, open(os.path.join(OUT, "shock_suite.json"), "w"), indent=1, default=float)
