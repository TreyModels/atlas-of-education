# Creative experiments: X1, X1b, X2, X3

Script: `creative_suite.py`. Results: `results/creative_suite.txt` and `results/creative_suite.json`.
Every test leaves one country out. "Error" means mean absolute TFR error on the held-out country.

## X1: Does the level of women's lead in tertiary enrolment predict extra fertility depth?

No. Every held-out fit drives the squeeze strength k to about 0, and the lag profile is flat (0.363 at every lag).
Development + squeeze scores 0.388 against 0.403 for development alone, but that gain is only a uniform downward
shift. The ratio itself contributes nothing.

Scope check: if the Philippines is treated as marriage-bound, error rises to 1.21 (2009 predicted 2.02, observed
3.38). The squeeze only operates where births require marriage, which matches the earlier cross-country result.

## X1b: Does the *change* in women's relative position since the start predict depth?

Partly.

| Held out | Development only | + relative gain |
|---|---|---|
| Korea | 0.310 | **0.178** |
| Hong Kong | 0.244 | **0.147** |
| Thailand | 0.371 | **0.246** |
| China | 0.407 | **0.391** |
| Japan | **0.277** | 0.489 |
| Philippines | **0.809** | 0.954 |
| Mean | 0.403 | 0.401 |

- The term helps the four places where the paper expects it to: Korea, Hong Kong, Thailand and China.
- It hurts Japan. Japan's TFR fell before women's enrolment overtook men's, so in Japan the squeeze comes too late
  to be the first cause.
- **Lag: best at 0 years.** Lags of 5–20 years all score the same (0.363). The data give no support for the
  paper's 15–20 year lag. The effect, where there is one, is contemporaneous.

## X2: Policy levers in the assortative-mating model

Baseline: completed fertility 1.07, 68% ever married, mean age at birth 29.8.

| Lever | Δ completed fertility |
|---|---|
| Non-marital births socially accepted | **+0.37** |
| Cash ×2 | +0.22 |
| Status gap halved | +0.20 |
| Men's prospects +0.5 SD | +0.19 (ever married rises to 0.81) |
| Cross-border marriage valve | +0.14 |
| Looser mating norms | +0.11 |
| Cash +30% (realistic) | +0.08 |
| Credentials finished 2 years earlier | +0.05 (birth age falls to 28.3) |

When the bottleneck is matching, fixing the match beats paying for children. A realistic cash increase is the
weakest lever after earlier credentials. Earlier credentials move timing more than quantity.

## X3: Does a first-birth age above 29 lock TFR below 1.3?

The paper claims that once mean age at first birth passes 29, TFR will not recover above 1.3. Japan contradicts this.
Its mean age at first birth reached 30.7 in 2015 (MHLW), and its TFR rose from 1.26 in 2005 to 1.45 in 2015 while
first-birth age stayed above 29. Several Western European countries combine first-birth ages near 30–31 with TFRs
of 1.5–1.7. That point is from memory and should be checked against Eurostat before it is cited.

Late first births do not set a ceiling by themselves. What matters is whether late starters still go on to have
births (marriage access and second-birth progression). This fits the model: age is a symptom, and the mating
bottleneck is the cause.

## What this changes in the Networked Domus

1. Keep the mechanism: credential sorting plus women overtaking men, under marriage-bound childbearing.
2. Drop or soften the 15–20 year lag. The lag tests find none.
3. Present Japan as an earlier, different route: development and work culture first, with the squeeze added later.
4. Replace the "age 29 ratchet" with a conditional claim: late timing becomes permanent loss only when marriage
   access is also shrinking.
5. Policy section: lead with decoupling births from marriage and improving men's prospects, not cash.

Sources: MHLW Vital Statistics (https://www.mhlw.go.jp/english/database/db-hw/FY2021/dl/live_births02.pdf);
Japan Times on the 2005 low of 1.26 (https://japantimes.co.jp/community/2016/02/10/voices/japan-birth-rate-beginning-end-just-new-beginning);
Gender Equality Bureau on the 2015 TFR of 1.45 (https://www.gender.go.jp/english_contents/pr_act/pub/pamphlet/women-and-men17/pdf/1-1.pdf).
