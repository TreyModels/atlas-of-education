import json,numpy as np
from sklearn.linear_model import LinearRegression
D=json.load(open('asia_panel_data.json'));L=json.load(open('life_asia.json'));cs=['PHL','THA','KOR','JPN','HKG','CHN']
S={c:{'f':{int(k):v for k,v in D['tfr_'+c]['values'].items()},'g':{int(k):v for k,v in D['gdp_'+c]['values'].items()},'l':{int(k):v for k,v in L[c]['values'].items()}} for c in cs}
def x(c,t):
 s=S[c];return [np.log(s['g'][t-5]/s['g'][t-10])/5,(s['l'][t-5]-s['l'][t-10])/5]
rows=[(c,t,x(c,t),S[c]['f'][t]-S[c]['f'][t-1]) for c in cs for t in range(1970,2010) if all(z in S[c]['g'] and z in S[c]['l'] for z in [t-5,t-10])]
for mode in ['income','survival','both']:
 idx={'income':[0],'survival':[1],'both':[0,1]}[mode]
 m=LinearRegression(fit_intercept=False).fit([[r[2][j] for j in idx] for r in rows],[r[3] for r in rows]);pred={};back={}
 for c in cs:
  v=S[c]['f'][2009];p=[]
  for t in range(2010,2025):
   v+=float(m.predict([[x(c,t)[j] for j in idx]])[0]);p.append(v)
  pred[c]=p
  v=S[c]['f'][1970];p=[]
  for t in range(1971,2010):
   v+=float(m.predict([[x(c,t)[j] for j in idx]])[0]);p.append(v)
  back[c]=p
 err=np.mean([abs(pred[c][t-2010]-S[c]['f'][t]) for c in cs for t in range(2010,2025)])
 hist=np.mean([abs(back[c][t-1971]-S[c]['f'][t]) for c in cs for t in range(1971,2010)])
 print(mode,'coeff',np.round(m.coef_,3),'histMAE',round(hist,3),'holdoutMAE',round(err,3),'2024',dict(zip(cs,[round(pred[c][-1],2) for c in cs])))
print('actual',dict(zip(cs,[S[c]['f'][2024] for c in cs])))
