"""Age-specific forecast checks using published Philippine and Korean rates."""
import numpy as np
from itertools import combinations
from openpyxl import load_workbook

# DHS rates, births per 1,000 women. Survey rates represent preceding three years.
philippines = {
    2013: np.array([57, 148, 146, 127, 84, 37, 7], float),
    2017: np.array([47, 131, 135, 114, 75, 29, 2], float),
    2022: np.array([25, 84, 105, 95, 58, 21, 2], float),
}

def historical_forecast(series, first, second, final):
    previous = series[second] - series[first]
    predicted = np.maximum(0, series[second] + previous * (final-second)/(second-first))
    observed = series[final]
    residual = predicted-observed
    return predicted, residual

predicted, error = historical_forecast(philippines,2013,2017,2022)
print('PH 2022 prediction by age',np.round(predicted,1).tolist())
print('PH actual',philippines[2022].tolist(),'errors',np.round(error,1).tolist())
print('PH five-year accumulated excess, ages 15–24 / 25–29 / 30+',
      np.round([sum(error[:2])*.005,error[2]*.005,sum(error[3:])*.005],3).tolist())
for a,b in combinations(philippines,2):
    d=(philippines[a]-philippines[b])*.005
    print('PH change',a,b,'ages under 25 / 25–29 / 30+',np.round([sum(d[:2]),d[2],sum(d[3:])],3).tolist())

# Rounding-only sensitivity. This is not a survey confidence interval.
rng=np.random.default_rng(618)
draws=[]
for _ in range(10000):
    x={year:rate+rng.uniform(-.5,.5,len(rate)) for year,rate in philippines.items()}
    pred,_=historical_forecast(x,2013,2017,2022)
    excess=pred-x[2022]
    draws.append([sum(excess[:2])*.005,sum(excess)*.005])
print('PH forecast excess rounding-only 5/50/95',np.round(np.quantile(draws,[.05,.5,.95],axis=0),3).tolist())

with open('stone_stat_jm4h0u','rb') as source:
    w=load_workbook(source,read_only=True,data_only=True)
    rows=[r for r in w['Fig_2_5'].values if isinstance(r[0],str) and r[0][:2].isdigit()]
    korea={year:np.array([row[i] for row in rows],float) for i,year in enumerate([2002,2012,2022],1)}
predicted,error=historical_forecast(korea,2002,2012,2022)
print('KOR 2022 age forecast from 2002–12',np.round(predicted,1).tolist())
print('KOR actual',korea[2022].tolist(),'errors',np.round(error,1).tolist())
print('KOR age contribution forecast error under 30 / 30–34 / 35+',np.round([sum(error[:3])*.005,error[3]*.005,sum(error[4:])*.005],3).tolist())

# Contrast a hypothesized intervention affecting first births only and one
# affecting later births only. Published Korean progression ratios.
p0=np.array([.920,.711,.128,.095,.080,.071,.065])
p1=np.array([.866,.543,.111,.081,.065,.056,.049])
def births(p): return np.cumprod(p).sum()
for label,p in [('before',p0),('after',p1),('first held',np.r_[p0[0],p1[1:]]),('second held',np.r_[p1[0],p0[1],p1[2:]]),('higher held',np.r_[p1[:2],p0[2:]])]:
    print('KOR parity counterfactual',label,round(births(p),3))
