# Late marriage × the biological clock: six places

Script: `fecundity_countries.py`. It uses the Habbema-calibrated model from `fecundity_age_model.py`, without refitting it. Results: `results/fecundity_countries.txt` and `results/fecundity_countries.json`.

Assumptions:
- Every couple wants two children and starts trying a year after marrying.
- Marriage rates are held fixed, so only timing changes.
- The clock's cut is applied to the early TFR and compared with the observed fall over the same years.

| Place | Women's age at marriage | Children per married woman | Involuntarily childless | TFR (observed) | TFR from the clock alone | Share of fall explained |
|---|---|---|---|---|---|---|
| Hong Kong | 26.2 (1991) → 31.0 (2024), median | 1.81 → 1.65 | 8% → 14% | 1.28 → 0.84 | 1.17 | 26% |
| Korea | 25.3 (1995) → 31.6 (2024) | 1.83 → 1.61 | 8% → 15% | 1.63 → 0.75 | 1.44 | 21% |
| China | 23.3 (2000) → 28.0 (2020) | 1.85 → 1.77 | 7% → 10% | 1.63 → 1.24 | 1.56 | 18% |
| Japan | 26.3 (1995) → 29.6 (2019) | 1.81 → 1.71 | 8% → 12% | 1.42 → 1.36 | 1.35 | ≈ all of a small fall |
| Thailand | 23.5 (1990) → ~24.8 (2024), estimate | 1.85 → 1.83 | 7% → 8% | 2.06 → 1.20 | 2.05 | 2% |
| Philippines | 21.6 (1993) → 22.8 (2022), median first union | 1.86 → 1.85 | 7% → 7% | 4.10 → 1.93 | 4.08 | 1% |

- Each extra year of marriage delay cuts births per married couple by about 2 percentage points (correlation +0.93), and the cut accelerates past the early 30s.
- **The clock is an East Asian amplifier.** It explains about a fifth to a quarter of the fall in Hong Kong, Korea and China.
- **Japan:** its 1995–2019 fall was small and partly reversed (1.26 in 2005, then 1.45 in 2015). The clock alone is consistent with the whole net change.
- **It explains almost nothing in Thailand and the Philippines,** where unions still start in the early-to-mid 20s. Their falls have other causes: fewer births within unions and development.
- Thailand's recent marriage age is an estimate. The Philippine figure counts cohabitation, which is right there because many births happen in live-in unions.
- IVF is not modelled, so these are upper bounds.

## Sources

- Korea: Statistics Korea via Asia News Network: https://asianews.network/?p=224812
- Japan: MHLW via Nippon.com: https://nippon.com/en/japan-data/h00759
- Hong Kong: C&SD: https://www.info.gov.hk/gia/general/202601/15/P2026011500213.htm
- China, 2000 and 2020 censuses: https://search.napstic.cn/literature/periodical/010rkyj202406002
- Thailand 1990 SMAM: https://so03.tci-thaijo.org/index.php/jpss/article/download/84567/67308/204851
- Thailand mean age at childbearing: https://georank.org/birth-rate/thailand
- Philippines 1993 NDS: https://datacatalog.worldbank.org/search/dataset/0049496/philippines-national-demographic-survey-1993
- Philippines 2022 NDHS: https://psa.gov.ph/sites/default/files/phdsd/Women%20Empowerment%202024%20Fact%20Sheet%20on%20Women%20and%20Men.pdf
