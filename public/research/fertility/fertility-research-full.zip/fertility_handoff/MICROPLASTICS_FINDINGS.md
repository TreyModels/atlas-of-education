# "OK, maybe microplastics": testing a biological fecundity shock

Script: `microplastics_test.py` (a few seconds). Results: `results/microplastics_test.txt` and `results/microplastics_test.json`.

## B1. Can a fecundity shock produce Korea's pattern?

This uses the same simulation and the same five Korean facts as `MECHANISMS_FINDINGS.md`.

| Mechanism | Size needed | Share of fall from fewer marriages | Birth age | Score |
|---|---|---|---|---|
| Fecundity loss at all ages | 60% fewer conceptions | 0% | +1.0 years | 1/5 |
| Fecundity loss rising with age (25→40) | cannot reach 1.20 even at 99% | — | — | — |
| All-ages loss + hypergamy | half each | 52% | +0.6 | 3/5 |
| Age-rising loss + hypergamy | half each | 52% | −0.6 | 3/5 |

- **As the main cause, a biological shock fails.** It needs couples to conceive 60% less often. All of the fall then comes from married couples, and none from fewer marriages.
- **That is the opposite of Korea.** There the fall runs through marriage, and married women's fertility *rose* from 2005 to 2013.
- **The age-rising version is too weak.** Most births happen before the ages where it bites hardest.
- **Adding it to hypergamy makes things worse.** Those pairs score 3/5, while hypergamy paired with the credential floor scored 5/5.

## B2. Timing: smooth plastics exposure vs a 2015 step

- Plastics exposure is modelled as cumulative production, which grows roughly exponentially. The approximate figures used are about 2 Mt a year in 1950 and about 380 Mt a year in 2015.
- All the shapes fit the gaps below the development path about equally: plastics exposure, a step in 2015 or 2016, and a straight line.
- **Neither fit nor held-out error separates them.** Held-out error is 0.40 to 0.42 for every shape.
- The fitted plastics effect is small: −0.10 at today's exposure.
- The lag can't be tested. With exponential exposure, a lag only rescales the curve.

## B3. Does the post-2015 drop depend on how marriage-bound births are?

| Place | Births outside marriage | TFR change 2015–24 |
|---|---|---|
| Korea | 4% | −40% |
| China | 5% | −39% |
| Philippines | 58% | −33% |
| Hong Kong | 8% | −30% |
| Japan | 2% | −21% |
| Thailand | 20% | −17% |

- The correlation between the share of births outside marriage and the size of the fall is **+0.01**.
- The post-2015 drop hit places where births need marriage and places where they don't alike. A biological shock would do that. So would COVID, phones or an economic shock.
- A marriage-market squeeze would not, so **the marriage squeeze is not what drove the post-2015 drop.**

## Conclusions

1. **Microplastics cannot be the main cause of Korea's long decline.** The signature is wrong: the decline runs through marriage, not conception.
2. **They cannot be ruled out as a contributor to the universal post-2015 drop.** That drop ignores marriage regimes, as a biological shock would. But exposure rises smoothly, while the drop is a break. A smooth cause fits a sudden fall only with a threshold, which is not modelled here.
3. **Human evidence is thin.** A 2024 systematic review in *BJOG* found that the link between microplastics and human fertility or pregnancy outcomes is not known. A rapid review rated the evidence on birth outcomes "unclassifiable" and reproductive harm "suspected".
4. **The deciding data:** births per *married* woman since 2015.
   - A sharp fall within marriage leaves biology and cost as candidates.
   - A fall only in marriages does not.
   - Time-to-pregnancy and infertility-treatment trends would separate biology from cost.

## Sources

- BJOG systematic review (2024): https://pubmed.ncbi.nlm.nih.gov/38287142/
- Rapid systematic review summary: https://beyondplastics.org/reports/tag/reproduction
