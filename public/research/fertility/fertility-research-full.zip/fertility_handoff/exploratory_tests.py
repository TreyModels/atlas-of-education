import random, statistics
age14=[3.1,19.6,60.9,94.9,56.9,11.3,.6];age24=[.8,7.9,34.6,68.1,46.7,10.3,.9]
diffs=[5*(b-a)/1000 for a,b in zip(age14,age24)]
print('Hong Kong age changes',diffs,'total',sum(diffs),'25-34 share',(diffs[2]+diffs[3])/sum(diffs))
print('composition deterministic')
for professional,other in [(1.4,1.8),(1.,1.8),(2.,1.8)]:
 first=.08*professional+.92*other; last=.28*professional+.72*other
 print('professional',professional,'other',other,'before',first,'after',last,'change',last-first)
r=random.Random(42);changes=[]
for i in range(10000):
 professional=r.uniform(1,2);other=r.uniform(1.4,2.2)
 changes.append(.2*(professional-other))
changes.sort()
print('composition range uniform 10000',statistics.median(changes),changes[499],changes[9499],sum(x<0 for x in changes)/len(changes))

def births(year,mode):
 total=0
 for cohort in range(1960,2020):
  moved=cohort>=1985
  first=30 if moved and mode!='reference' else 25
  second=34 if moved and mode!='reference' else 29
  if cohort+first==year:total+=1000
  if cohort+second==year:total+=600 if moved and mode=='delay_and_fewer' else 800
 return total
for year in (2009,2014,2019,2024,2029):print('births',year,*[births(year,m) for m in ('reference','delay','delay_and_fewer')])
for mode in ('reference','delay','delay_and_fewer'):
 print('cohort 1985',mode, 'completed',1.6 if mode=='delay_and_fewer' else 1.8)
