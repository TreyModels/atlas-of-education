"""Kate's model, round 2: calibrate 'more choices' to survey data, find the missing marriage delay, and
measure the gap between what women intend and what they get.

Survey anchors (China):
  2017 National Fertility Survey (Zhuang, Jiang & Li 2021): ideal 1.96, intended 1.76; born 1990s 1.70;
    childless women 1.60.
  CGSS Liaoning urban 2013-17: ideal 1.71 overall, 1.81 for college-educated (so educated women do NOT want
    fewer children there).
R1  Replace the assumed 1.5 for educated women with survey-based intentions: everyone 1.76 (then) vs
    1.70 (now, 1990s-born), educated women the same as others. Opt-out of marriage kept at 0% and 10%.
R2  What closes the marriage-age gap (model +2.7 years vs China +4.7)? Add, one at a time:
      H  housing: men need H years of stable work (savings) before marrying (0 -> 2, 4)
      S  stricter partner standard: every woman needs a man with at least her education AND a job, and
         tertiary women also need him to have worked 2+ years
      Q  slower job queue for men (stable-job chance 0.35 -> 0.20 a year)
R3  Intention-achievement gap: with 1.70 intended, how many children does the 'now' world deliver, and
    which part of the gap is marriage, timing (clock) and residual?
Synthetic; China's one-child policy not modelled.
"""
import json, os
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "results")
LINES, RES = [], {}


def say(s=""):
    print(s, flush=True); LINES.append(s)


src = open(os.path.join(HERE, "fecundity_age_model.py")).read()
ns = {"__file__": os.path.join(HERE, "fecundity_age_model.py")}
exec(src.split('\nTARGETS = ')[0], ns)
sim_births = ns["simulate"]
P = tuple(json.load(open(os.path.join(OUT, "fecundity_age_model.json")))["A1"]["params"])
AGES = np.arange(16, 46)
TABLE = {k: np.array([sim_births(a + 1.0, k, P, n=3000, seed=11).mean() for a in AGES]) for k in (1, 2, 3)}


def births(age, sought):
    lo = np.clip(np.floor(sought), 1, 2).astype(int); w = sought - lo
    v1 = np.array([np.interp(a, AGES, TABLE[l]) for a, l in zip(age, lo)])
    v2 = np.array([np.interp(a, AGES, TABLE[l + 1]) for a, l in zip(age, lo)])
    return (1 - w) * v1 + w * v2


def cohort(edu_w=0.55, edu_m=0.50, est=3.0, partner=True, strict=False, housing=0, job_p=0.35, optout=0.0,
           sought_t=1.70, sought_o=1.70, n=6000, seed=5):
    rng = np.random.default_rng(seed)
    wt = rng.random(n) < edu_w; mt = rng.random(n) < edu_m
    w_seek = np.where(wt, 22 + est, 20.0) + rng.normal(0, 1.0, n)
    m_done = np.where(mt, 23 + est, 21.0) + rng.normal(0, 1.0, n)
    out = wt & (rng.random(n) < optout)
    m_job = np.zeros(n, bool); m_years = np.zeros(n); m_free = np.ones(n, bool)
    w_mar = np.full(n, np.nan)
    for age in range(18, 46):
        if partner:
            m_job |= (age >= m_done) & (rng.random(n) < job_p)
        else:
            m_job |= (age >= m_done)
        m_years += m_job
        ok = m_free & m_job & (m_years >= housing)
        elig = np.flatnonzero(ok)
        if strict:
            pool_t = list(elig[mt[elig] & (m_years[elig] >= 2)])
        else:
            pool_t = list(elig[mt[elig]])
        pool_n = list(elig[~mt[elig]])
        rng.shuffle(pool_t); rng.shuffle(pool_n)
        women = np.flatnonzero(np.isnan(w_mar) & ~out & (age >= w_seek) & (rng.random(n) < 0.30))
        rng.shuffle(women)
        for w in women:
            if partner and wt[w]:
                pools = [pool_t]
            else:
                tot = len(pool_t) + len(pool_n)
                pools = [pool_t, pool_n] if tot and rng.random() < len(pool_t) / tot else [pool_n, pool_t]
            for pool in pools:
                if pool:
                    m = pool.pop(); m_free[m] = False; w_mar[w] = age; break
    mar = ~np.isnan(w_mar)
    sought = np.where(wt, sought_t, sought_o)
    kids = np.zeros(n)
    kids[mar] = births(w_mar[mar], sought[mar])
    return dict(cf=float(kids.mean()), ever=float(mar.mean()), age=float(np.nanmean(w_mar)),
                per_married=float(kids[mar].mean()), single_wt=float(1 - mar[wt].mean()),
                single_mo=float(1 - (~m_free)[~mt].mean()))


THEN = dict(edu_w=0.10, edu_m=0.12, est=1.0, partner=False, sought_t=1.76, sought_o=1.76)
then = cohort(**THEN)
say("R1. 'MORE CHOICES' CALIBRATED TO SURVEYS (intended children 1.76 -> 1.70, educated women not lower)")
say(f"  Then: marriage age {then['age']:.1f}; ever married {then['ever']:.0%}; completed fertility {then['cf']:.2f}")
r1 = {}
for opt in (0.0, 0.10):
    r = cohort(optout=opt)
    r1[f"optout_{opt}"] = r
    say(f"  Now (career start, partner standard, intentions 1.70, opt-out {opt:.0%}): marriage age {r['age']:.1f}; "
        f"ever married {r['ever']:.0%}; CF {r['cf']:.2f} ({(r['cf']-then['cf'])/then['cf']:+.0%})")
say("  Compare the assumed version (educated women seek 1.5, 10% opt out) in kate_model.py: CF 1.43 (-22%).")
RES["R1"] = dict(then=then, **r1)

say("\nR2. WHAT CLOSES THE MARRIAGE-AGE GAP? (China +4.7 years, 23.3 -> 28.0; target CF fall about -24%)")
r2 = []
for label, kw in [("Kate's channels only", {}), ("+ housing: men need 2 years of savings", dict(housing=2)),
                  ("+ housing: 4 years", dict(housing=4)), ("+ stricter partner standard", dict(strict=True)),
                  ("+ slower job queue for men", dict(job_p=0.20)), ("+ housing 2y + slower queue", dict(housing=2, job_p=0.20)),
                  ("+ career start 5 years", dict(est=5.0)), ("+ housing 2y + career start 5y", dict(housing=2, est=5.0))]:
    r = cohort(optout=0.05, **kw)
    r2.append(dict(variant=label, **r))
    say(f"  {label:36s} marriage age {r['age']:.1f} ({r['age']-then['age']:+.1f}); ever married {r['ever']:.0%}; "
        f"CF {r['cf']:.2f} ({(r['cf']-then['cf'])/then['cf']:+.0%}); single at 45: tertiary women {r['single_wt']:.0%}, "
        f"non-tertiary men {r['single_mo']:.0%}")
RES["R2"] = r2

say("\nR3. INTENTION-ACHIEVEMENT GAP ('now' world with housing 2y, intentions 1.70)")
now = cohort(optout=0.05, housing=2)
everyone_married_early = cohort(edu_w=0.55, edu_m=0.50, est=1.0, partner=False, sought_t=1.70, sought_o=1.70)
said = 1.70
marriage_loss = (1 - now["ever"]) * now["per_married"]
clock_loss = now["ever"] * (everyone_married_early["per_married"] - now["per_married"])
bio_floor = said - everyone_married_early["per_married"]
say(f"  Intended {said:.2f}; achieved {now['cf']:.2f}; gap {said-now['cf']:.2f}")
say(f"    Biology even with early marriage (infertility, miscarriage): {bio_floor:.2f}")
say(f"    Later marriage (clock): {clock_loss:.2f}")
say(f"    Never marrying: {marriage_loss:.2f}")
say(f"  China's period TFR in our panel: 1.79 (2017), 1.24 (2020), 1.01 (2024). The model's {now['cf']:.2f} is completed "
        "fertility for women intending 1.70; period rates are also cut by postponement (tempo) and by any post-2015 fall in intentions.")
RES["R3"] = dict(intended=said, achieved=now["cf"], biology=bio_floor, clock=clock_loss, never_marry=marriage_loss)

with open(os.path.join(OUT, "kate_round2.txt"), "w") as f:
    f.write("\n".join(LINES) + "\n")
json.dump(RES, open(os.path.join(OUT, "kate_round2.json"), "w"), indent=1, default=float)
