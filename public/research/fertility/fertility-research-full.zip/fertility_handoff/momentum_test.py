"""Tipping-point test on the real series: is there self-reinforcing momentum, and is there pull-back toward
the development path?
  dTFR_t = rho * dTFR_{t-1} + kappa * (development_path_{t-1} - TFR_{t-1}) + c
A tipping process predicts high momentum (rho) and weak or no pull-back (kappa) where society is homogeneous
and peer-driven; a 'bending' process predicts low rho and positive kappa. Fit per place on 1985-2024, and
test out of sample: fit on 1985-2014, simulate 2015-2024 from 2014, with and without momentum.
"""
import contextlib, io, json, os, runpy
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__))
with contextlib.redirect_stdout(io.StringIO()):
    TD = runpy.run_path(os.path.join(HERE, "timing_depth_test.py"))
TFR, Y, PL, SURV = TD["TFR"], TD["YEARS"], TD["PLACES"], TD["paths"]["M2 survival"]
lines, res = [], {}
def say(s=""):
    print(s); lines.append(s)
def design(c, y0, y1):
    t = TFR[c]; d = np.diff(t); idx = [i for i in range(2, len(Y)) if y0 <= Y[i] <= y1]
    X = np.array([[d[i - 2], SURV[c][i - 1] - t[i - 1], 1.0] for i in idx]); yv = np.array([d[i - 1] for i in idx])
    return X, yv, idx
say("MOMENTUM AND PULL-BACK, 1985-2024 (per place)")
for c in PL:
    X, yv, _ = design(c, 1985, 2024)
    b, *_ = np.linalg.lstsq(X, yv, rcond=None)
    resid = yv - X @ b; s2 = resid @ resid / (len(yv) - 3); se = np.sqrt(np.diag(s2 * np.linalg.inv(X.T @ X)))
    res[c] = dict(rho=float(b[0]), rho_se=float(se[0]), kappa=float(b[1]), kappa_se=float(se[1]))
    say(f"  {c}: momentum rho {b[0]:+.2f} (se {se[0]:.2f}); pull-back to development path kappa {b[1]:+.3f} (se {se[1]:.3f})")
say("\nOUT OF SAMPLE: fit 1985-2014, simulate 2015-2024 from the 2014 values")
oos = {}
for c in PL:
    X, yv, _ = design(c, 1985, 2014)
    b_full, *_ = np.linalg.lstsq(X, yv, rcond=None)
    b_nom, *_ = np.linalg.lstsq(X[:, 1:], yv, rcond=None)
    i14 = list(Y).index(2014)
    def run(mom):
        t = list(TFR[c][: i14 + 1]); d_prev = t[-1] - t[-2]
        for i in range(i14 + 1, len(Y)):
            gap = SURV[c][i - 1] - t[-1]
            d = (b_full[0] * d_prev + b_full[1] * gap + b_full[2]) if mom else (b_nom[0] * gap + b_nom[1])
            t.append(t[-1] + d); d_prev = d
        return np.array(t[i14 + 1:])
    obs = TFR[c][i14 + 1:]
    e1, e0 = float(np.mean(np.abs(run(True) - obs))), float(np.mean(np.abs(run(False) - obs)))
    naive = float(np.mean(np.abs(TFR[c][i14] - obs)))
    oos[c] = dict(momentum=e1, no_momentum=e0, no_change=naive, pred2024_momentum=float(run(True)[-1]), obs2024=float(obs[-1]))
    say(f"  {c}: error with momentum {e1:.2f}, without {e0:.2f}, no-change {naive:.2f}; 2024 predicted {run(True)[-1]:.2f} vs {obs[-1]:.2f}")
say(f"  Mean: momentum {np.mean([v['momentum'] for v in oos.values()]):.2f}, without {np.mean([v['no_momentum'] for v in oos.values()]):.2f}, "
    f"no-change {np.mean([v['no_change'] for v in oos.values()]):.2f}")
res["oos"] = oos
open(os.path.join(HERE, "results", "momentum_test.txt"), "w").write("\n".join(lines) + "\n")
json.dump(res, open(os.path.join(HERE, "results", "momentum_test.json"), "w"), indent=1)
