"""Approximate de Silva and Tenreyro (2020), equations 5, 11, 13, 14.

Parameters are rounded as printed. 1985 policy weight is the midpoint,
an explicit interpolation assumption; later weights are held fixed.
The 2010 policy weight is calibrated with 2010 data by the authors.
"""
import numpy as np
from scipy.optimize import brentq

COUNTRIES = {
    # A4's values reproduce the starting points when interpreted as weights
    # on previous fertility, contrary to the naming convention in equation 5.
    'South Korea': (0.000, .005, .080, .150, 1-.831, 1-.000, 1.021, 102.601),
    'Thailand': (.048, .003, .233, .066, 1-.829, 1-1.000, .824, .041),
    'Philippines': (.047, .005, .455, .212, 1-1.000, 1-.253, .201, 128.393),
}
OBS = {'South Korea': [5.994, 1.660, 1.226],
       'Thailand': [6.325, 2.450, 1.562],
       'Philippines': [6.996, 4.664, 3.315]}

def simulate(p, mode='published'):
    t0, th, alpha, theta, phi0, phi2, z, H = p
    prior = 3.5
    out=[]
    for i in range(3):
        phi = [phi0, (phi0 + phi2)/2, phi2][i] if mode == 'published' else phi0
        norm = phi + (1-phi)*prior
        def h(n):
            return max(0, (theta*(1-t0*n)-th*n/(z*(1+H)))/(th*n*(1+theta)))
        def foc(n):
            hh=h(n)
            return alpha/n - (t0+th*hh)/(1-(t0+th*hh)*n) - .2*(n-norm)
        hi=(1/t0 if t0 else 100)*.999999
        # Some printed calibrations have two stationary points. Select the
        # higher, locally maximizing branch; a global optimum is not assured.
        grid=np.geomspace(1e-6,hi,300)
        brackets=[(a,b) for a,b in zip(grid[:-1],grid[1:]) if foc(a)>0 and foc(b)<0]
        if not brackets:
            raise ValueError('No locally maximizing interior solution')
        n=brentq(foc,*brackets[-1])
        hh=h(n)
        out.append(2*n)
        H=z*(1+H)*hh
        prior=n
    return np.array(out)

if __name__ == '__main__':
    for name,p in COUNTRIES.items():
        for mode in ['published','constant']:
            try:
                pred=simulate(p, mode)
                print(name, mode, 'model',np.round(pred,3), 'observed',OBS[name], 'errors',np.round(pred-np.array(OBS[name]),3))
            except ValueError as e: print(name,mode,e)
    rng=np.random.default_rng(17)
    for name,p in COUNTRIES.items():
        draws=[]
        for _ in range(3000):
            # Illustrates sensitivity to printed parameter rounding only.
            q=list(p)
            for j in (0,1,2,3,4,5,6,7):
                q[j]=max(0.00000001,q[j]+rng.uniform(-.0005,.0005))
            q[4]=min(1,q[4]);q[5]=min(1,q[5])
            try: draws.append(simulate(q)[1:])
            except (ValueError,ZeroDivisionError): pass
        if draws: print(name,'rounding sensitivity 1985/2010 5th, 50th, 95th',np.round(np.percentile(draws,[5,50,95],axis=0),3).tolist(),'n',len(draws))
        else: print(name,'no solutions among rounding draws')
