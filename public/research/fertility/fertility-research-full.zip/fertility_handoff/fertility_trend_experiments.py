import json
import numpy as np
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge

d=json.load(open('asia_panel_data.json')); life=json.load(open('life_asia.json')); cs=['PHL','THA','KOR','JPN','HKG','CHN']
series={}
for c in cs:
 series[c]={k:{int(y):v for y,v in obj['values'].items()} for k,obj in [('f',d['tfr_'+c]),('g',d['gdp_'+c]),('l',life[c])]}
def feats(c,t,prev,older,typ):
 z=series[c]; age=t-5
 x=[prev, (prev-older)/5]
 if typ in ('income','development','country'): x += [np.log(z['g'][age])]
 if typ in ('development','country'): x += [z['l'][age]]
 if typ=='country': x += [float(c==i) for i in cs[1:]]
 return x
def data(c,typ):
 z=series[c];return [(feats(c,t,z['f'][t-1],z['f'][t-6],typ),z['f'][t]-z['f'][t-1]) for t in range(1966,2010) if all(y in z['f'] for y in [t,t-1,t-6]) and t-5 in z['g'] and t-5 in z['l']]
def run(typ, traincs=cs):
 dd=sum((data(c,typ) for c in traincs),[]); m=make_pipeline(StandardScaler(),Ridge(alpha=10)).fit([x for x,y in dd],[y for x,y in dd]); out={}
 for c in cs:
  f=series[c]['f']; path={t:f[t] for t in range(2004,2010)}
  for t in range(2010,2025):
   v=m.predict([feats(c,t,path[t-1],path[t-6],typ)])[0];path[t]=max(0,path[t-1]+v)
  out[c]=[path[t] for t in range(2010,2025)]
 return out
actual={c:np.array([series[c]['f'][t] for t in range(2010,2025)]) for c in cs}
for model in ['momentum','income','development','country']:
 pred=run(model); err={c:np.mean(abs(np.array(pred[c])-actual[c])) for c in cs}; print(model,'mae',round(np.mean(list(err.values())),3),'country', {c:round(err[c],3) for c in cs},'2024',{c:round(pred[c][-1],2) for c in cs})
print('actual2024',{c:round(actual[c][-1],2) for c in cs})
for typ in ['momentum','development']:
 out=[]
 for c in cs:
  p=run(typ,[x for x in cs if x!=c])[c];out.append(np.mean(abs(np.array(p)-actual[c])))
 print('leave-one-out',typ,round(np.mean(out),3),dict(zip(cs,np.round(out,3))))

rng=np.random.default_rng(45); pred=[]
for i in range(400):
 sample=list(rng.choice(cs,size=6,replace=True));res=run('development',sample);pred.append([res[c][-1] for c in cs])
print('bootstrap 2024 intervals',dict(zip(cs,np.round(np.quantile(pred,[.05,.5,.95],axis=0).T,2).tolist())))
