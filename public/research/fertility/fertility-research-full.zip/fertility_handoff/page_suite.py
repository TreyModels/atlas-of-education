"""Page suite: experiments in the spirit of Scott Page's many-model thinking.

P1  Many models, one crowd. Eight leave-one-place-out models (calendar, income, survival, income+survival,
    lagged versions, matching, common shock). Diversity prediction theorem: crowd error = average model
    error - diversity of the models. Effective number of models from the correlation of their errors.
    Best sub-crowd chosen honestly: picked on five places, scored on the sixth.
P2  Tipping points (Granovetter threshold model). People adopt a "small family / no rush to marry" life
    script once enough peers have. How does the spread of thresholds (a homogeneous vs a diverse society)
    turn the same small shock into a cliff or a slope? Data check: speed of each place's fastest fall.
P3  Path dependence and recovery (hysteresis). Shock the threshold model, then remove the shock.
    Does fertility come back? Compare with a memoryless Markov version (Page: Markov processes forget
    their history; models with feedback do not).
P4  Robustness. Redraw the cohort model's parameters 400 times. How often do the U4 conclusions hold?
    (credential race hits both regimes; the matching squeeze is amplified where births need marriage.)

numpy/scipy only, fixed seeds. Six places = small sample; P2-P4 are mechanism experiments, not estimates.
"""
import contextlib
import io
import itertools
import json
import os
import runpy

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "results")
LINES, RES = [], {}


def say(s=""):
    print(s, flush=True)
    LINES.append(s)


with contextlib.redirect_stdout(io.StringIO()):
    U = runpy.run_path(os.path.join(HERE, "unified_suite.py"))      # reuses its functions (re-writes its own results)
TFR, YEARS, PLACES, WIN = U["TFR"], U["YEARS"], U["PLACES"], U["WIN"]
TDP = U["TD"]["paths"]

# ================================================================ P1 many models
say("P1. MANY MODELS, ONE CROWD (leave one place out, 1985-2024)")
models = {k: TDP[k] for k in TDP}
models["M6 matching"] = {}
models["M7 common shock"] = {}
for c in PLACES:
    tr = [x for x in PLACES if x != c]
    _, kb = U["fit_kb"](tr, U["LOGREL0"])
    models["M6 matching"][c] = U["SURV"][c] * U["match_factor"](c, kb[0], kb[1], U["LOGREL0"][c])
    (v1, q1), on1 = min([(U["fit_v1"](tr, on), on) for on in (2000, 2005, 2010, 2015)], key=lambda t: t[0][0])
    models["M7 common shock"][c] = U["pred_v1"](c, q1, on1)
names = list(models)
P = np.array([np.concatenate([models[m][c][WIN] for c in PLACES]) for m in names])   # models x (place-years)
Y = np.concatenate([TFR[c][WIN] for c in PLACES])
place_idx = np.concatenate([[i] * int(WIN.sum()) for i in range(len(PLACES))])

sq = ((P - Y) ** 2).mean(1)
crowd = P.mean(0)
crowd_sq = float(((crowd - Y) ** 2).mean())
diversity = float(((P - crowd) ** 2).mean())
say("  Mean squared error by model: " + ", ".join(f"{n.split(' ', 1)[1]} {v:.3f}" for n, v in zip(names, sq)))
say(f"  Diversity prediction theorem: crowd error {crowd_sq:.3f} = average error {sq.mean():.3f} - diversity {diversity:.3f}")
best_single = names[int(np.argmin(sq))]
say(f"  Best single model: {best_single} ({sq.min():.3f}); crowd of all eight: {crowd_sq:.3f}")
Ecorr = np.corrcoef(P - Y)
ev = np.clip(np.linalg.eigvalsh(Ecorr), 0, None)
n_eff = float(ev.sum() ** 2 / (ev ** 2).sum())
say(f"  Effective number of models (from error correlations): {n_eff:.2f} of {len(names)}")
say(f"  Mean error correlation between models: {Ecorr[np.triu_indices(len(names), 1)].mean():.2f}")

# honest sub-crowd: choose subset on five places, score on the sixth
subsets = [s for r in range(1, len(names) + 1) for s in itertools.combinations(range(len(names)), r)]
honest = []
for i, c in enumerate(PLACES):
    trm, tem = place_idx != i, place_idx == i
    best = min(subsets, key=lambda s: ((P[list(s)][:, trm].mean(0) - Y[trm]) ** 2).mean())
    e_sub = float(((P[list(best)][:, tem].mean(0) - Y[tem]) ** 2).mean())
    e_all = float(((crowd[tem] - Y[tem]) ** 2).mean())
    bs = int(np.argmin(((P[:, trm] - Y[trm]) ** 2).mean(1)))
    e_bs = float(((P[bs, tem] - Y[tem]) ** 2).mean())
    honest.append(dict(place=c, subset=[names[j] for j in best], err_subset=e_sub, err_all=e_all,
                       best_single=names[bs], err_best_single=e_bs))
    say(f"  {c}: picked on others -> best single ({names[bs].split(' ',1)[1]}) {e_bs:.3f} | "
        f"best sub-crowd ({len(best)} models) {e_sub:.3f} | all eight {e_all:.3f}")
mh = {k: float(np.mean([h[k] for h in honest])) for k in ("err_best_single", "err_subset", "err_all")}
say(f"  Mean held-out squared error: best single {mh['err_best_single']:.3f}, chosen sub-crowd {mh['err_subset']:.3f}, "
    f"all eight {mh['err_all']:.3f}")
RES["P1"] = dict(models=names, mse=sq.tolist(), crowd=crowd_sq, avg=float(sq.mean()), diversity=diversity,
                 n_eff=n_eff, honest=honest, honest_mean=mh)

# ================================================================ P2 tipping points
say("\nP2. TIPPING POINTS AND TRAPS: SAME SHOCK, DIFFERENT SOCIETIES (threshold model, mean-field)")
from scipy.stats import norm

MU = 0.5


def threshold_run(sigma, w, B, shock=0.05, shock_years=(30, 40), T=80, push=0.0, push_from=None):
    """Share adopting a 'small family / no rush to marry' script; thresholds ~ N(MU, sigma).
    Pressure = development (rises to plateau B by year 25, then flat) + temporary shock (years 30-39)
    + w * last year's adoption (peer feedback) - policy counter-push. w = 0 is memoryless."""
    a, out = 0.0, []
    for t in range(T):
        base = B * min(t / 25, 1.0)
        s = shock if shock_years[0] <= t < shock_years[1] else 0.0
        pp = push if (push_from is not None and t >= push_from) else 0.0
        a = float(norm.cdf((base + s - pp + w * a - MU) / sigma))
        out.append(a)
    return np.array(out)


def tfr_of(a):
    return 2.0 - 1.1 * a    # adopters average 0.9 children, others 2.0


BGRID = np.round(np.arange(0.0, 0.601, 0.005), 3)
p2 = []
for w in (0.0, 0.3, 0.6):
    for sigma in (0.05, 0.10, 0.20, 0.35):
        trapped, cliff = [], 0.0
        for B in BGRID:
            no = tfr_of(threshold_run(sigma, w, B, shock=0.0)); sh = tfr_of(threshold_run(sigma, w, B))
            if no[79] - sh[79] > 0.3:            # still >0.3 lower 40 years after the shock ended
                trapped.append(B)
            cliff = max(cliff, float(np.max(-np.diff(sh))))
        width = len(trapped) * 0.005
        p2.append(dict(feedback=w, sigma=sigma, trap_zone_width=width,
                       trap_zone=[min(trapped), max(trapped)] if trapped else None, fastest_fall=cliff))
        say(f"  feedback {w:.1f}, spread {sigma:.2f}: temporary shock causes a permanent drop for a "
            f"{width:.3f}-wide band of development levels"
            f"{'' if not trapped else f' ({min(trapped):.2f}-{max(trapped):.2f})'}; fastest yearly fall {cliff:.2f}")
say("  Data: fastest five-year fall in TFR, 1985-2024 (per year):")
fast = {}
for c in PLACES:
    t = TFR[c]; m = YEARS >= 1985; tt, yy = t[m], YEARS[m]
    drops = [(tt[i] - tt[i + 5]) / 5 for i in range(len(tt) - 5)]
    j = int(np.argmax(drops)); fast[c] = dict(rate=float(drops[j]), start=int(yy[j]))
    say(f"    {c}: {drops[j]:.3f}/yr from {yy[j]}")
RES["P2"] = dict(sim=p2, data_fastest=fast)

# ================================================================ P3 policy in a trap
say("\nP3. PATH DEPENDENCE: WHAT DOES IT TAKE TO UNDO A TIPPED SOCIETY?")
p3 = []
for w, sigma in ((0.3, 0.10), (0.6, 0.10), (0.6, 0.20)):
    tr = [q for q in p2 if q["feedback"] == w and q["sigma"] == sigma][0]["trap_zone"]
    if not tr:
        say(f"  feedback {w:.1f}, spread {sigma:.2f}: no trap zone"); continue
    B = round((tr[0] + tr[1]) / 2, 3)
    no = tfr_of(threshold_run(sigma, w, B, shock=0.0))

    def need(start, temporary=False):
        for push in np.arange(0.0, 0.61, 0.005):
            if temporary:   # push applied for 10 years only, then withdrawn
                a, out = 0.0, []
                for t in range(80):
                    base = B * min(t / 25, 1.0); s = 0.05 if 30 <= t < 40 else 0.0
                    pp = push if start <= t < start + 10 else 0.0
                    a = float(norm.cdf((base + s - pp + w * a - MU) / sigma)); out.append(a)
                sh = tfr_of(np.array(out))
            else:
                sh = tfr_of(threshold_run(sigma, w, B, push=push, push_from=start))
            if sh[79] >= no[79] - 0.05:
                return float(push)
        return None
    pb, pa, pt = need(28), need(45), need(45, temporary=True)
    p3.append(dict(feedback=w, sigma=sigma, B=B, tfr_before=no[79], tfr_trapped=float(tfr_of(threshold_run(sigma, w, B))[79]),
                   push_before=pb, push_after=pa, push_after_temporary=pt))
    say(f"  feedback {w:.1f}, spread {sigma:.2f} (development level {B}): TFR {no[79]:.2f} -> trapped at "
        f"{p3[-1]['tfr_trapped']:.2f}. Counter-push to prevent (start before shock) {pb:.3f}; to undo (start 5 yrs after, "
        f"permanent) {pa:.3f}; 10-year temporary push after {pt if pt is None else round(pt,3)} (shock was 0.05)")
RES["P3"] = dict(runs=p3)

# ================================================================ P4 robustness
say("\nP4. ROBUSTNESS: DO THE U4 CONCLUSIONS SURVIVE 400 RANDOM PARAMETER DRAWS?")
cohort = U["cohort"]
rng = np.random.default_rng(42)
draws = []
for i in range(400):
    gap = rng.uniform(0.4, 1.2); meet_cut = rng.uniform(0.2, 0.6); cost = rng.uniform(1.3, 2.4)
    kin_to = rng.uniform(0.1, 0.4); band = rng.uniform(0.3, 0.9); nmv = rng.uniform(0.3, 0.6)
    B90 = dict(gap=0.0, meet=0.25, cost=1.0, kin=0.6, band=band)
    res = {}
    for regime, nm in (("mb", 0.0), ("nm", nmv)):
        cf0 = cohort(**B90, nonmarital=nm, n=2500, seed=i)[0]
        for key, val in (("gap", gap), ("meet", 0.25 * (1 - meet_cut)), ("cost", cost), ("kin", kin_to)):
            on = dict(B90); on[key] = val
            res[(regime, key)] = cf0 - cohort(**on, nonmarital=nm, n=2500, seed=i)[0]
    draws.append(res)
amp_gap = np.mean([d[("mb", "gap")] > 1.5 * d[("nm", "gap")] for d in draws])
cost_univ = np.mean([abs(d[("mb", "cost")] - d[("nm", "cost")]) < 0.35 * max(d[("mb", "cost")], 1e-6) for d in draws])
gap_top_mb = np.mean([d[("mb", "gap")] >= max(d[("mb", k)] for k in ("meet", "kin")) for d in draws])
cost_top_nm = np.mean([d[("nm", "cost")] >= max(d[("nm", k)] for k in ("gap", "meet", "kin")) for d in draws])
med = {f"{r}_{k}": float(np.median([d[(r, k)] for d in draws])) for r in ("mb", "nm") for k in ("gap", "meet", "cost", "kin")}
say(f"  Matching squeeze at least 1.5x larger where births need marriage: {amp_gap:.0%} of draws")
say(f"  Credential race similar in both regimes (within 35%): {cost_univ:.0%} of draws")
say(f"  Matching squeeze beats coupling recession and kin loss in marriage-bound world: {gap_top_mb:.0%}")
say(f"  Credential race is the biggest channel where births outside marriage are common: {cost_top_nm:.0%}")
say("  Median single-channel effects (marriage-bound | non-marital common): " +
    ", ".join(f"{k} -{med['mb_'+k]:.2f} | -{med['nm_'+k]:.2f}" for k in ("gap", "cost", "meet", "kin")))
RES["P4"] = dict(amplified=float(amp_gap), cost_universal=float(cost_univ), gap_top_mb=float(gap_top_mb),
                 cost_top_nm=float(cost_top_nm), medians=med)

with open(os.path.join(OUT, "page_suite.txt"), "w") as f:
    f.write("\n".join(LINES) + "\n")
json.dump(RES, open(os.path.join(OUT, "page_suite.json"), "w"), indent=1, default=float)
