"""Modernity suite: experiments prompted by Fernandez-Villaverde's 'curve fell after 1985' chart.

F1  Which yardstick stays put? Fit the TFR curve separately on 1961-1985 and 1986-2024 against each candidate
    'modernity' yardstick: income (log GDP), life expectancy, infant mortality (log, places with data), and
    calendar year. A good yardstick gives the same curve in both eras. Score = mean absolute gap between the
    two era curves over the x range both eras cover.
F2  Does the curve really shift? Leave one place out: income only vs income + a curve that drifts with
    calendar time (the shift), vs life expectancy only, vs life expectancy + drift.
F3  Replacement at lower income over time? Year and income at which each place first went below 2.1 for good.
F4  Is the post-2015 drop a new shock or the old drift continuing? Extrapolate each place's 2000-2014 trend in
    its gap below the development path, and compare the 2024 prediction with what happened.

Six places; small sample. Infant mortality has no Hong Kong series and starts in 1969 for China.
"""
import contextlib, io, json, os, runpy
import numpy as np
from scipy.optimize import least_squares

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "results")
LINES, RES = [], {}


def say(s=""):
    print(s, flush=True); LINES.append(s)


with contextlib.redirect_stdout(io.StringIO()):
    TD = runpy.run_path(os.path.join(HERE, "timing_depth_test.py"))
TFR, Y, PL, LGDP, LE, SURV, curve = TD["TFR"], TD["YEARS"], TD["PLACES"], TD["LGDP"], TD["LE"], TD["paths"]["M2 survival"], TD["curve"]
P = json.load(open(os.path.join(HERE, "asia_panel_data.json")))
IMR = {}
for c in PL:
    v = P[f"mortality_{c}"]; v = v.get("values", v)
    if v:
        IMR[c] = np.array([np.log(float(v[str(y)])) if str(y) in v else np.nan for y in Y])
YEARF = {c: Y.astype(float) for c in PL}
YARDS = {"income (log GDP)": LGDP, "life expectancy": LE, "infant mortality (log, -)": {c: -IMR[c] for c in IMR}, "calendar year": YEARF}


def zfix(X):
    allv = np.concatenate([x[~np.isnan(x)] for x in X.values()])
    return {c: (x - allv.mean()) / allv.std() for c, x in X.items()}, allv.mean(), allv.std()


def fit(X, places, mask):
    xs = np.concatenate([X[c][mask] for c in places]); ys = np.concatenate([TFR[c][mask] for c in places])
    ok = ~np.isnan(xs)
    r = least_squares(lambda p: curve(xs[ok], *p) - ys[ok], [1.0, 6.5, 2.0, 0.0], bounds=([0, 1.5, .05, -6], [3, 9, 30, 6]))
    return r.x, xs[ok]


# ================================================================ F1
say("F1. WHICH YARDSTICK GIVES THE SAME CURVE BEFORE AND AFTER 1985?")
early, late = Y <= 1985, Y > 1985
f1 = []
for name, X0 in YARDS.items():
    if name == "calendar year":
        continue
    X, mu, sd = zfix(X0)
    pl = list(X)
    pe, xe = fit(X, pl, early); pl_, xl = fit(X, pl, late)
    lo, hi = max(xe.min(), xl.min()), min(xe.max(), xl.max())
    grid = np.linspace(lo, hi, 50)
    gap = float(np.mean(np.abs(curve(grid, *pe) - curve(grid, *pl_)))) if hi > lo else float("nan")
    errE = np.mean(np.abs(np.concatenate([curve(X[c][early], *pe) - TFR[c][early] for c in pl])[~np.isnan(np.concatenate([X[c][early] for c in pl]))]))
    errL = np.mean(np.abs(np.concatenate([curve(X[c][late], *pl_) - TFR[c][late] for c in pl])[~np.isnan(np.concatenate([X[c][late] for c in pl]))]))
    # how far the late curve sits below the early curve at the overlap's top quarter (the 'rich end')
    top = np.linspace(lo + 0.75 * (hi - lo), hi, 10)
    shift_top = float(np.mean(curve(top, *pl_) - curve(top, *pe))) if hi > lo else float("nan")
    bot = np.linspace(lo, lo + 0.25 * (hi - lo), 10)
    shift_bot = float(np.mean(curve(bot, *pl_) - curve(bot, *pe))) if hi > lo else float("nan")
    f1.append(dict(yardstick=name, places=len(pl), era_gap=gap, shift_low_end=shift_bot, shift_high_end=shift_top,
                   fit_err_early=float(errE), fit_err_late=float(errL), overlap_share=float((hi - lo) / (max(xe.max(), xl.max()) - min(xe.min(), xl.min())))))
    say(f"  {name:28s} ({len(pl)} places): curves differ by {gap:.2f} children on average over the shared range "
        f"(low end {shift_bot:+.2f}, high end {shift_top:+.2f}); fit error {errE:.2f} early, {errL:.2f} late; "
        f"shared range {f1[-1]['overlap_share']:.0%} of all values")
RES["F1"] = f1

# ================================================================ F2
say("\nF2. DOES A DRIFTING CURVE PREDICT HELD-OUT PLACES BETTER? (1961-2024, leave one place out)")
ZG, _, _ = zfix(LGDP); ZE, _, _ = zfix(LE)
T = (Y - 1985) / 20.0


def model(kind):
    def pred(x, t, p):
        if kind == "static":
            return curve(x, *p[:4])
        return curve(x + p[4] * t, *p[:4])        # drift: the same curve, shifted along x as calendar time passes
    return pred


f2 = []
for xname, X in (("income", ZG), ("life expectancy", ZE)):
    for kind in ("static", "drift"):
        pred = model(kind); errs = {}
        for c in PL:
            tr = [x for x in PL if x != c]
            xs = np.concatenate([X[o] for o in tr]); ts = np.tile(T, len(tr)); ys = np.concatenate([TFR[o] for o in tr])
            p0 = [1.0, 6.5, 2.0, 0.0] + ([0.3] if kind == "drift" else [])
            lb = [0, 1.5, .05, -6] + ([-3] if kind == "drift" else []); ub = [3, 9, 30, 6] + ([3] if kind == "drift" else [])
            p = least_squares(lambda q: pred(xs, ts, q) - ys, p0, bounds=(lb, ub)).x
            errs[c] = float(np.mean(np.abs(pred(X[c], T, p) - TFR[c])))
        m = float(np.mean(list(errs.values())))
        f2.append(dict(yardstick=xname, kind=kind, mean_err=m, by_place=errs))
        say(f"  {xname:16s} {kind:6s}: mean held-out error {m:.3f}  " + " ".join(f"{c} {v:.2f}" for c, v in errs.items()))
RES["F2"] = f2

# ================================================================ F3
say("\nF3. REPLACEMENT AT LOWER INCOME OVER TIME? (first year below 2.1 for good)")
GDP = {c: np.exp(LGDP[c]) for c in PL}
f3 = []
for c in PL:
    below = TFR[c] < 2.1
    if not below[-1]:
        continue
    i = len(Y) - 1
    while i > 0 and below[i - 1]:
        i -= 1
    f3.append(dict(place=c, year=int(Y[i]), gdp=float(GDP[c][i]), life_exp=float(LE[c][i])))
    say(f"  {c}: {Y[i]} at GDP per capita {GDP[c][i]:,.0f} (constant US$), life expectancy {LE[c][i]:.1f}")
yrs = np.array([r["year"] for r in f3]); g = np.log([r["gdp"] for r in f3]); le = np.array([r["life_exp"] for r in f3])
b = np.polyfit(yrs, g, 1)[0]
say(f"  Income at replacement changes {100*(np.exp(10*b)-1):+.0f}% per decade of later crossing "
    f"(n = {len(f3)}); life expectancy at crossing ranges {le.min():.1f}-{le.max():.1f} years "
    f"(spread {le.max()-le.min():.1f}) while income ranges {np.exp(g).min():,.0f}-{np.exp(g).max():,.0f} "
    f"({np.exp(g).max()/np.exp(g).min():.1f}x)")
RES["F3"] = dict(crossings=f3, income_change_per_decade=float(np.exp(10 * b) - 1))

# ================================================================ F4
say("\nF4. NEW SHOCK OR OLD DRIFT? (extrapolate each place's 2000-2014 gap trend to 2024)")
f4 = []
m = (Y >= 2000) & (Y <= 2014)
for c in PL:
    gap = TFR[c] - SURV[c]
    k, a = np.polyfit(Y[m], gap[m], 1)
    pred24 = a + k * 2024
    obs24 = float(gap[-1])
    f4.append(dict(place=c, trend_per_decade=float(10 * k), predicted_gap_2024=float(pred24), observed_gap_2024=obs24,
                   surprise=float(obs24 - pred24)))
    say(f"  {c}: 2000-14 trend {10*k:+.2f}/decade -> 2024 gap predicted {pred24:+.2f}, observed {obs24:+.2f} "
        f"(surprise {obs24-pred24:+.2f})")
sur = np.array([r["surprise"] for r in f4])
say(f"  Mean surprise {sur.mean():+.2f}; places with an extra drop beyond the old trend (< -0.15): {int((sur < -0.15).sum())} of 6")
RES["F4"] = dict(rows=f4, mean_surprise=float(sur.mean()))

with open(os.path.join(OUT, "modernity_suite.txt"), "w") as f:
    f.write("\n".join(LINES) + "\n")
json.dump(RES, open(os.path.join(OUT, "modernity_suite.json"), "w"), indent=1, default=float)
