# Does assortative mating plus competition fit Hong Kong, China, Japan, Thailand and the Philippines?

This checks the mechanism from `ASSORTATIVE_FINDINGS.md` (fewer and later marriages, driven by rising competition while women's status overtakes men's) against four ingredients in each place:
1. births are mostly within marriage;
2. the decline runs mainly through marriage;
3. women's education has overtaken men's (female-to-male tertiary enrolment ratio, `education_ratio.json`, World Bank via FRED);
4. births are delayed.

It also uses the timing results in `RESULTS_AND_RESEARCH.md`. This is an evidence check, not a new simulation.

| Place | Births mostly marital | Decline mainly via marriage | Women's tertiary enrolment ahead of men's | Fits? |
| --- | --- | --- | --- | --- |
| Korea | Yes, about 96% | Yes (Choi 2022; KIHASA 2015) | Young-adult degree holders 58.4% of women vs 47.8% of men (2020), though the enrolment ratio is still below 1 (0.86 in 2022) | Yes, all five facts |
| Hong Kong | Yes, non-marital births low | Yes: falling marriage is the primary driver 1981–2021, with marital fertility also falling after 2016 (Bai et al. 2025) | Since about 2003 (1.01 in 2005; 1.09 in 2023) | Yes, with a twist |
| China | Yes, births tightly linked to marriage | Very likely: marriages fell from 13.47m (2013) to 6.1m (2024); about 30% of 30-year-olds unmarried in 2023 vs 14.5% in 2013 | Since about 2008 (1.08 in 2010; 1.14 in 2023) | Probably, timing matches |
| Japan | Yes, nearly all | Yes: about 70% marriage, 30% marital fertility, 1970–2000 | No: still just below 1 (0.97 in 2022) | Partly. The low-gap case |
| Thailand | Mostly union-bound; cohabitation 6% to 9% | Not decomposed here | Since 1993 (1.26 in 2023) | Recent phase consistent; early decline was family planning |
| Philippines | No: 58% non-marital (2022) | No: mostly fewer births within unions (−0.69 vs −0.32 from union formation, 2013–22) | Since at least 1971 (1.24), while fertility stayed high for decades | No |

## Place by place

**Hong Kong fits, but cross-border marriage changes who stays single.** Women's education overtook men's, marriage collapsed, and births moved later: median age at first marriage for brides rose from 26.2 in 1991 to 30.6 in 2021. But local men's education has little effect on whether they marry (Zhou, Wu and He 2017). For decades, lower-status Hong Kong men could marry women from mainland China. Mainland-born couples were 20% of marriages registered in Hong Kong in 1986 and 56% in 2006. That safety valve weakens the men's gradient the model predicts. The share of cross-boundary marriages that are Hong Kong brides with mainland grooms has risen from 6.1% (1991) to 35.8% (2019). Housing costs are also unusually important in Hong Kong, which the model omits.

**China fits on timing.** Women's tertiary enrolment passed men's around 2008. Marriages peaked in 2013 and have since halved. The fertility shortfall below the development path reopened after 2015 (timing test, E1). Part of the marriage fall is smaller young cohorts, not lower rates, and China's surplus of men (not modelled here) should strengthen the low-status-men side of the mismatch. A rate decomposition for 2013–2024 is still needed.

**Japan is the case that tests the mechanism's key ingredient.** Its decline is about 70% marriage-driven, but women's tertiary enrolment never overtook men's. The model predicts marriage delay without an extreme status mismatch, and so no ultra-low depth beyond development. That is what the timing test found: life expectancy alone reproduces Japan's 2024 level (predicted 1.06 vs observed 1.15). Japan's marriage decline started in the 1970s, before any education gap, so competition and delay can reduce marriage without women overtaking men. The overtaking is what pushes places below the development path.

**The Philippines does not fit, and it is a useful counterexample.** Women have out-enrolled men in tertiary education since at least 1971, yet fertility stayed high for decades. A status mismatch alone does not suppress childbearing where births do not depend on marriage: 58% of births are non-marital. The recent fall is mostly within unions, with little delay (tempo-adjusted TFR 2.06 vs 1.95 observed). That points to contraception and unmet need, not the marriage market.

## Thailand (added)

**Thailand fits for the recent ultra-low phase, but not for its early decline.**
- **Childbearing is mostly union-bound.** Cohabitation is low but rising, from 6% of individuals in 2005–09 to 9% in 2010–14. Couples married by Buddhist ceremony without registration count as married.
- **Women overtook men in tertiary enrolment in 1993** (1.17 in 2000; 1.26 in 2023).
- **There is direct evidence on the women's side of the mismatch.** A PIER study using Labor Force Survey data finds a university degree lowers Thai women's probability of marriage by 14.8% (the "Gold Miss" effect). A small Bangkok survey found the opposite gradient, so the evidence is not unanimous.

The timing splits Thailand into two stories:
- **The early decline was not this mechanism.** Thailand was already 0.6 children below its development path in 1995, before the education crossover mattered. The 1960s–80s fall came through marital fertility under a strong family-planning programme, while age at marriage changed little in the 1960s. That is an earlier and different mechanism.
- **The recent depth is consistent with it.** The gap had closed by 2015 (−0.03 to −0.18), then reopened by 2024 (−0.28 to −0.43; observed 1.20). That is two decades after women's enrolment overtook men's, with educated women marrying less.

What is missing: a marriage-versus-marital-fertility decomposition for Thailand since 2010, and age-specific rates, neither of which is in this package. Without them, Thailand is "consistent with" rather than "fits".

Sources for this section:
- Paweenawat and Liao, "Gold Miss" or "Earthy Mom"? Evidence from Thailand, PIER Discussion Paper 110; *Asian-Pacific Economic Literature* 2025. https://econpapers.repec.org/paper/puidpaper/110.htm
- Cohabitation in Thailand, cohort study. https://pmc.ncbi.nlm.nih.gov/articles/PMC9486337
- Bangkok women's education and marriage survey (Chulalongkorn). https://cuir.car.chula.ac.th/xmlui/handle/123456789/69793

## What it means for the mechanism

The mechanism needs three conditions together:
1. childbearing tied to marriage;
2. competition that lengthens schooling and narrows acceptable partners;
3. women's status overtaking men's.

Korea, Hong Kong and China have all three, and they are the places furthest below the development path. Japan has the first two but not the third, and it sits on the path. The Philippines has the third but not the first, and the mechanism does not operate there. Escape valves that let low-status men marry, such as cross-border brides in Hong Kong, weaken the men's side of the mismatch.

## Limits

- **The two education measures disagree for Korea.** Enrolment ratios count all ages and are affected by men's military service; young-adult attainment is the better status measure.
- **China's marriage figures are counts, not age-specific rates.**
- **Hong Kong and China decompositions are from published abstracts** and press figures, not rerun here.

## Sources

- Bai et al. (2025), Hong Kong TFR decomposition 1981–2021, *China Population and Development Studies*. https://link.springer.com/article/10.1007/s42379-025-00201-x
- Zhou, Wu and He (2017), Marriage in an immigrant society, *Demographic Research* 37(18). https://www.demographic-research.org/volumes/vol37/18/
- Hong Kong Census and Statistics Department, as reported (marriage ages, cross-boundary marriages). https://asianews.network/?p=78577
- China Ministry of Civil Affairs marriage registrations, as reported. https://www.caixinglobal.com/2025-02-12/charts-of-the-day-chinas-new-marriages-fall-to-46-year-low-102287604.html
- Japan decomposition, *Journal of Population Studies* (J-STAGE). https://www.jstage.jst.go.jp/browse/jps/26/0/_contents/-char/en
- Philippines non-marital births 2022, UP Population Institute. https://www.uppi.upd.edu.ph/sites/default/files/pdf/CRVS-forum-Implication-of-birth-statistics.pdf
- Philippines union decomposition, PIDS DP 2023-19. https://pidswebs.pids.gov.ph/CDN/document/pidsdps2319.pdf
