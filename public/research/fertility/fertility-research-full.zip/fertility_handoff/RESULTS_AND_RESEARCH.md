# Fertility atlas research, handoff

## Research question and user preferences

Trey is developing a separate fertility section of an existing atlas. He wants to know whether existing economic and demographic explanations reproduce the timing and depth of fertility decline across Hong Kong, Japan, South Korea, China, Thailand, and the Philippines. Reconstruct the long story from approximately 1950–60 through recent data, then project modestly forward. He values simple competing models, Monte Carlo sensitivity analysis, birth-order and cohort distinctions, and Scott Page's many-model approach. Models should contain mechanisms. Statistical trend extrapolations are useful benchmarks.

The user specifically wants the endogenous decisions to form a union, enter marriage, have a first child, and have later children. Period postponement should be separated from completed-cohort fertility. For the Philippines, cohabitation must be separated from legal marriage. Heterogeneity by education, income/wealth, and potentially deciles or quintiles matters.

His substantive hypothesis links family investment to the formal economy. As credential floors rise, the child needs qualifications to access formal jobs. Ranked competition adds investments beyond that floor. Parents who experienced these conditions anticipate the cost, adjust the number and timing of births, and may delay family formation while securing work. Family networks may lose effectiveness as channels for economic opportunity and support. Pensions and other arrangements can change the old-age value of children. Expectations, autonomy, gender divisions, housing, and contraceptive access are competing or interacting mechanisms. Treat these as hypotheses, not empirical conclusions.

## Results, oldest to newest

### Early Hong Kong and Japan exploratory work

See hk_japan_explore.py and results/hk_japan_explore.txt. Fifty thousand draws examine a rough Hong Kong marriage/birth decomposition and Japanese age contributions. The family-pressure coefficient is deliberately invented and uniformly varied, so the resulting cultural scenario is NOT empirical evidence. The time-trend comparison uses selected decadal fertility values. The inputs and denominators should be independently audited before using these early numbers.

exploratory_tests.py contains a hypothetical education-group composition calculation and simple cohort timing toy. The simulated values are not country estimates.

### Existing published global model

De Silva and Tenreyro, “The Fall in Global Fertility: A Quantitative Model,” American Economic Journal: Macroeconomics 12(3), 2020, DOI https://doi.org/10.1257/mac.20180296. The model includes endogenous education and fertility plus family-size norms. It uses 25-year generations, with 1960, 1985, and 2010 comparisons. Its country parameterization uses information from 2010, so a 2010 match is not a genuine independent forecast. Korea, Thailand, and Philippines appear in its 15-country exercise. Japan, Hong Kong, and China are absent.

fertility_reconstruction.py implements household first-order conditions from the paper using rounded Table A4 coefficients. The aggregate equations gave approximately 5.98 at the start, consistent with the paper's approximately 6. Country reconstruction encountered an apparent convention mismatch. Interpreting A4 values as the prior-generation weight, instead of the equation's replacement-level weight, fits 1960 initial conditions more closely. This interpretation is unverified and the Korea policy path had no locally maximizing interior solution under that implementation. Optimizer branch selection does not guarantee a global optimum. Thailand's reconstructed rates and timing failed badly. The original AEA replication package link redirected to a repository inaccessible through the search tool. Do not call this a validated reproduction or attribute our failed implementation to the authors as a model result.

### Shared statistical benchmarks

asia_fertility_test.py uses 1965–2009 for training and 2010–2024 for testing across six places. Each rolling prediction uses fertility five years earlier. Because the input is updated from later observed values, a 2024 prediction uses 2019 fertility. Results from the original run:

- Persistence, mean absolute error 0.223 children per woman.
- Shared lagged fertility model, 0.170.
- Add lagged GDP, 0.171.
- Shared lag plus country intercepts, 0.217.
- Lag, GDP, and country intercepts, 0.232.
- Leave-one-country-out lag model MAE 0.174; plus GDP 0.187.
- On the same five-country sample, add lagged infant mortality: MAE 0.164 to 0.182. Hong Kong lacked that mortality series in the extract.

A separate exploratory matched-sample test of female-to-male tertiary enrollment yielded MAE 0.168 for lag fertility and 0.275 with the enrollment ratio on 82 test observations. It is a gender-parity ratio, not school-attainment level or credential competition, and its missing data, especially Japan, restrict interpretation.

fertility_trend_experiments.py is a harder 2010–2024 recursive test starting from observed 2009 and not resetting fertility each year. It uses observed explanatory variables at five-year lags, including after 2009, so it is a conditional historical test, not an actual 2009 forecast. Mean absolute error: prior fertility and slope 0.138, plus GDP 0.134, plus life expectancy 0.164, plus country adjustments 0.240. A 400-draw bootstrap resampled entire countries, not annual rows. Inspect results/fertility_trend_experiments.txt for country paths and intervals.

### Mechanism-driven and threshold models

fertility_mechanism_test.py fits changes in log GDP, life expectancy, or both to annual fertility changes through 2009, with no intercept. When measured inputs stop changing, fertility stays fixed. It anchors historical paths in 1970 and later paths in 2009. Life expectancy is an imperfect survival proxy. 2010–2024 MAE was approximately 0.351 for GDP, 0.325 for life expectancy, and 0.364 for both. The combined model missed the Philippines 2024 badly, predicting about 2.93 versus 1.89, and overshot declines elsewhere.

kin_credential_experiment.py is a simplified discrete household-choice model with heterogeneous child preferences, a developing-economy proxy, declining old-age benefit, cost per child, parenthood fixed costs, and smooth or imposed threshold education pressure. It anchors each country at 1970 and fits shared parameters to 1975–2005 observations. Historical fitting MAE was about 0.57 smooth versus 0.54 threshold. 2010–2024 MAE was 0.35 versus 0.27. The threshold model produced Philippines 2024 approximately 1.89, but 2009 approximately 2.18 versus observed 3.38, so the endpoint match hides an early and severe timing error. Korea 2024 was 1.10 versus 0.75; China 1.45 versus 1.01. Twenty whole-country bootstrap refits favored threshold 19 times on this test window, a tiny sensitivity exercise with in-sample calibration and no independent evidence that a threshold exists.

Critical flaw: the model uses one GDP-derived index as a proxy for development while pension, kin support, education costs, and household choice all move with that index. Parameters are not separately identified. The threshold is explicitly imposed, not generated by firms, and there is no measured individualism. Outcomes are chosen from 0 through 8 via softmax with hypothetical taste distributions. Do not call these values causal or calibrated estimates of kin effects.

### Birth-order simulations

birth_transition_experiment.py builds an illustrative age/order schedule, anchored to Korean 2015 TFR 1.239 and fitted separately to 2023 TFR 0.721. Each mechanism is therefore guaranteed to match the endpoint where the solver succeeds. The first-child barrier, later-child cost, postponement, and combined versions yielded very different first-birth shares and subsequent paths. The delay-only model needed an approximately 3.28-year increase in its stylized birth schedule across eight years, then rebounded after the shift stopped. In 400 hypothetical parameter draws, the later-birth-only case reached the target in 212 draws within the prescribed parameter search range.

This is a stylized period schedule, not a complete cohort microsimulation. Initial parity, distributions, and age responses are assumptions. 2033 results are illustrative scenario outcomes, not forecasts. No effect in that exercise was identified as actual Korean career or tutoring effects.

### Stone's demographic accounting and observed age/order checks

Stone and Spencer James, Marriage Still Matters (2022): https://ifstudies.org/reports/marriage-still-matters/2022/executive-summary . Their marital-status-apportioned TFR weights each age-specific marital/nonmarital fertility rate by the proportion of women in that status. This is descriptive and does not establish the causal direction between marriage and fertility. They note marriage can itself depend on plans for children.

Stone's first-progression approach divides first births at each age by childless women at risk at that age, rather than all women. Later-birth hazards use women with the corresponding previous parity. See https://ifstudies.org/blog/1-in-4-projecting-childlessness-among-todays-young-women . The Human Fertility Database provides birth-order, age, and selected cohort data: https://www.humanfertility.org/ . Korea and Japan have differing coverage. Avoid treating period first-birth TFR as a childless-woman-specific progression probability.

Stone, Anderson, and Thiehoff, “Amish fertility in the United States,” use the Coale–Trussell m indicator as a descriptive age-pattern benchmark for fertility control, alongside ACS and registry comparisons: https://doi.org/10.4054/demres.2025.52.26 . Stone's Ultra-Orthodox ACS study also distinguishes age, marriage, and marital fertility: https://doi.org/10.4054/demres.2023.49.29 .

Stone_fertility_tests.py applies a symmetric/Shapley-style arithmetic decomposition to rounded rates in PIDS Table 1. In the Philippines 2013–2022 period, reconstructed TFR declined from 3.058 to 1.965. Components were -0.319 from changes in age-specific proportions ever in a union, -0.687 from birth rates among women ever in a union, and -0.087 from birth rates among those never in a union. “Ever in a union” includes marriage-like unions and former unions. These are not births occurring strictly within marriage. The PIDS original used a somewhat different decomposition, assumed zero births among never-married women before 1993, and reports rounded -0.4 union and -0.7 marital fertility for 2013–2022. Source: https://pidswebs.pids.gov.ph/CDN/document/pidsdps2319.pdf .

On published Korean synthetic parity-progression schedules, the 1965–83 to 1984–97 change is dominated by third and higher births. From 1984–97 to 1998–2014, the modeled synthetic family-size change 1.666 to 1.393 divides into approximately -0.092 first, -0.170 second, -0.012 higher births. These are our arithmetic decompositions of period progression schedules, not measured completed cohorts. Source OECD Table 2.3: https://www.oecd.org/en/publications/korea-s-unborn-future_005ce8f7-en/full-report/fewer-children-later-in-life-changing-fertility-behaviour-and-its-consequences_fe61e8f5.html .

In Korean Statistics Korea age rates as presented by OECD, TFR rose 1.177 to 1.306 from 2002 to 2012. The decline under age 30 (-0.229) was outweighed by increases at 30–34 (+0.235) and 35+ (+0.123). From 2012 to 2022 TFR fell to 0.771, including -0.334 under 30, -0.242 at 30–34, and +0.041 at 35+. Period data cannot establish within-cohort recuperation. OECD workbook https://stat.link/jm4h0u .

credential_cohort_tests.py extends Philippine 2013–17 age-specific trends to 2022, yielding about 2.23 versus observed about 1.95 from rounded component rates. Under 25 accounted for about 0.176 of the 0.28 error. Ten thousand draws over assumed rounding intervals gave a 5th–95th range of approximately 0.167–0.185 for that component. This is not a statistical confidence interval. Birth rates are reported per 1,000 and survey windows refer to the preceding three years. Source https://ncr.cpd.gov.ph/wp-content/uploads/2024/03/PPD-POA_Final-Copy-2.pdf .

The same script extrapolates Korean age rates from 2002–12 to 2022. Its projected age 30–34 rate was 168.8 per 1,000 versus observed 73.5, accounting for about 0.477 children of the extrapolation error. This simplistic projection is a descriptive counterexample to continued catch-up, not a causal estimate.

### Research leads and evidence, with limits

- Kim, Tertilt, Yum (2024), Korea education-status externalities. The model counterfactual raises modeled fertility 28% when an externality is eliminated, relative to the authors' modeled baseline, not today's observed TFR. https://doi.org/10.1257/aer.20220583
- Dongwoo Kim (2026), education competition and scarce career destinations, working paper. Its model finds an allocation counterfactual and attributes the cohort trend to preference shifts within its specification. https://doi.org/10.2139/ssrn.7362758
- Hwang (2023), “Later, Fewer, None?” South Korean cohort decomposition. Changes within education groups explain most decline; educational composition accounts for under 8% of decline between specified 1956–60 and 1976–80 cohorts. Descriptive, not a causal mechanism. https://doi.org/10.1215/00703370-10585316
- Uchikoshi, Mugiyama, Yoda, Raymo (2026), Japanese panel evidence associates childbearing intentions with later marriage after controls for marriage desires. Causality remains unresolved. https://doi.org/10.1111/padr.70050
- Stone and colleagues, Baby Nudges, cross-country survey on perceived practical support, social norms, and admired public figures. Survey associations do not identify causal effects. https://ifstudies.org/report-brief/baby-nudges-how-social-influences-shape-fertility-choices
- Caldwell's wealth-flows theory and later economic models concern intergenerational transfers, child labor and old-age support. Networks can simultaneously supply care and impose obligations.
- Abarcar and Theoharides use U.S. visa-policy changes to study Filipino nursing supply. This is a documented credential-supply shock, not a demonstrated fertility effect. https://doi.org/10.1162/rest_a_01131
- Korean 1997–98 labor-market-entry shock was associated with persistent employment, earnings, marriage, and fertility differences among male college-graduate cohorts. https://pubmed.ncbi.nlm.nih.gov/32989344/
- The Philippine 2013 K–12 law and 2016 senior-high implementation occurred long after fertility first fell. It can be tested for effects in exposed cohorts, but anticipation and indirect spillovers complicate identification. https://www.deped.gov.ph/2015/09/02/all-set-for-k-to-12-implementation/
- Philippine contraceptive unmet need fell, especially among the poorest, from 2013 to 2022. This is an additional candidate for the recent decline. https://pubmed.ncbi.nlm.nih.gov/39464843/

Public data series:
World Bank TFR via FRED https://fred.stlouisfed.org/data/SPDYNTFRTINPHL and use country suffix THA, KOR, JPN, HKG, CHN. GDP per capita https://fred.stlouisfed.org/data/NYGDPPCAPKDPHL with the same suffix convention. Life expectancy https://fred.stlouisfed.org/data/SPDYNLE00INPHL . Female/male tertiary enrollment ratio https://fred.stlouisfed.org/data/SEENRTERTFMZSPHL .

## Next research work

Build competing models using observed age and parity transitions, and track time to stable employment, education/credential entry requirements, anticipated education costs, first-child opportunity costs, contraceptive access, and family support as independent observable processes where possible. Distinguish a changing measured variable from a fitted latent preference or assumed threshold. Compare historically held-out periods, held-out countries, depth and sustained threshold-crossing timing, age-specific first and later births, and completed cohorts when available. Establish exact data availability and compare on common samples. Candidate sources include the Human Fertility Database, OECD Family Database, CORESIDENCE historical household composition database, UNESCO UIS, PIDS and national statistics. Co-residence does not fully measure practical support or individualism.

Use age-, parity-, and partnership-specific inputs without assuming weddings are required for births in the Philippines. Retain room for preferences to change as well as desired fertility not being achieved. Evaluate policy scenarios only against empirical elasticities or transparently labeled assumptions. Preserve endogenous responses and avoid identifying all mechanisms with the same GDP proxy.

No website updates or publishing were authorized. User explicitly asked to wait.

## Timing and depth test (added 10 November 2026)

`timing_depth_test.py`, output in `results/timing_depth_test.txt` and `.json`. This addresses the handoff's open question of whether development mechanisms reproduce the timing and depth of decline, rather than five-year forecasts. Short-horizon forecasts reward momentum, so persistence beats every mechanism model on them (0.13–0.14 vs 0.27–0.36 MAE above). The useful test of a mechanism is explanatory: hold one place out, fit on the other five, and simulate the held-out place's whole 1961–2024 path from its own income or survival path. Then compare the year it crossed TFR 2.1, 1.5 and 1.3 (sustained crossing) and its 2024 level.

Six models: a calendar null (the other places' average TFR in the same year), a static logistic curve in log GDP, the same in life expectancy, both combined, and lagged-adjustment versions of the income and survival curves started from observed 1961 TFR.

| Model | Path MAE | 2024 error | Years off, crossing 2.1 | Years off, crossing 1.5 | Years off, crossing 1.3 |
| --- | ---: | ---: | ---: | ---: | ---: |
| Calendar null | 0.92 | 0.33 | 15.2 | 16.8 (1 miss) | 9.6 (1 miss) |
| Income curve | 1.09 | 0.66 | 14.5 (2 miss) | 17.0 (3 miss) | 32.0 (4 miss) |
| Survival curve | **0.61** | 0.33 | **9.4** (1 miss) | 7.4 | 22.5 (3 miss) |
| Income + survival | 0.62 | 0.33 | 9.8 (1 miss) | **7.2** | 22.5 (3 miss) |
| Income, lagged | 0.85 | 0.43 | 16.8 | 13.6 (1 miss) | 20.3 (3 miss) |
| Survival, lagged | 0.79 | 0.36 | 14.0 | **6.4** (1 miss) | **15.0** (1 miss) |

A "miss" means the model never crosses when the place did, or crosses when it did not.

Findings:

1. **Survival explains timing; income does not.** Fitted on the other five, the life-expectancy curve places Korea's sustained fall below 1.5 in 2002 (observed 1998), Hong Kong's in 1984 (observed 1985) and China's in 2013 (observed 2019). It is 17 years early for Japan and 9 years late for Thailand. The income curve misses half the crossings and does not transport across these places. Adding income to survival adds nothing.
2. **No development model reaches ultra-low fertility.** Every model misses the depth. Held-out 2024 predictions for Korea are 1.12–1.68 against 0.75, and for Hong Kong 1.20–1.50 against 0.84. The reason is structural: a fitted curve's floor is set by the lowest places in its training set. With Korea held out, the survival curve's floor is 1.15. The fall below about 1.1–1.3 in Korea, Hong Kong, China and Thailand is therefore a separate level that development does not explain, while Japan's 2024 level is reproduced (1.06 vs 1.15).
3. **The Philippines runs the other way.** Static development curves predict 2.22 for 2024 (observed 1.89), but lagged curves predict 1.2–1.3. Its decline came late relative to survival gains, then fast (below 2.1 only in 2020). This fits the handoff's recent-decline candidates (unions, contraception, unmet need) better than a smooth development path.
4. **Diversity:** effective number of independent models is 1.94 of 6, and the equal-weight ensemble (0.675) does not beat the survival curve alone (0.608).

**Check without a floor.** Logistic curves impose a floor, so the depth result was rerun with a log-linear curve (log TFR linear in the driver, same leave-one-out design). The survival version has path MAE 0.644. Its held-out 2024 predictions are Korea 1.07 (observed 0.75), China 1.47 (1.01), Thailand 1.63 (1.20), Hong Kong 0.92 (0.84) and Japan 0.92 (1.15). Hong Kong's depth is therefore largely consistent with extrapolating its very high life expectancy. The gap that survives both curve shapes is **Korea (about 0.3–0.5 children), China (about 0.4–0.5) and Thailand (about 0.3–0.4)**.

What this means for the credential hypothesis: development and survival get each place most of the way down, roughly on time, to about 1.3–1.5. The unexplained part is the depth below that. It survives both curve shapes in Korea, China and Thailand. Hong Kong's depth is largely consistent with its very high life expectancy once the curve has no floor. That residual is where credential competition, delayed marriage, housing and first-birth barriers must earn their place. They should be tested on age, union and parity data, not on GDP.

Limits: six places; life expectancy trends with time and partly stands in for general development; period TFR, not cohort; China's birth-planning policy is not modelled; crossing years from smooth curves are sensitive to small level shifts near a threshold.

Next step: get the Human Fertility Database series (free registration) for Korea and Japan, plus Hong Kong and Taiwan age-specific rates from national statistics. Then split the depth residual into first-birth versus later-birth progression and timing. That tests directly whether the ultra-low gap is mainly fewer first births (union and first-child barriers) or fewer second births (cost of investing in each child).

## Experimental suite (added 10 November 2026)

See `SUITE_FINDINGS.md` and `experimental_suite.py`. Using only data in this package, it finds that about 0.2 of Korea's shortfall below the development path is postponement (2022 tempo-adjusted TFR 0.98 vs 0.77 observed). Korea's 2012–2022 age pattern is reproduced only by a two-part account: the schedule shifted about 2.1 years older and fell about 25% at every age. Neither pure postponement, nor a uniform fall, nor a young-age barrier reproduces it. The Philippine 2013–2022 decline is mostly a uniform fall at every age with little postponement.

## Mechanism signature test (added 10 November 2026)

See `MECHANISMS_FINDINGS.md` and `mechanism_signatures.py`. Korea's decline runs mainly through fewer marriages, since about 96% of births are marital. Of Trey's mechanisms, the credential floor and job queue fits best, and only in combination with educational hypergamy, which together reproduce all five Korean facts tested. Ranked competition fails as the main channel when it acts within marriage. In its anticipation form it is indistinguishable from ideation. Old-age value fits the earlier third-birth collapse, not ultra-low fertility. Published job and income gradients in men's marriage (KERI, KLI) favour the credential floor over ideation as hypergamy's partner.

## Assortative mating plus competition (added 10 November 2026)

See `ASSORTATIVE_FINDINGS.md`. Symmetric assortative mating with rising pickiness cannot cut marriage on its own. Once women's status distribution rises past men's, it reproduces all five Korean facts with no separate job rule. Pickier choice produces the fall in marriage and more self-investment produces the delay.

## Cross-country fit (added 10 November 2026)

See `CROSS_COUNTRY_FIT.md`. The assortative-mating-plus-competition mechanism needs childbearing tied to marriage, rising competition, and women's status overtaking men's. Korea, Hong Kong and China have all three and sit furthest below the development path. Japan lacks the education overtaking and sits on the path. The Philippines lacks marriage-bound childbearing (58% non-marital births) and does not fit; its decline is within unions.


## Creative experiments (X1, X1b, X2, X3)
See CREATIVE_FINDINGS.md. In short: the enrolment-ratio level adds nothing. The change in women's relative position helps Korea, Hong Kong, Thailand and China but hurts Japan, and the best lag is 0 (no support for 15-20 years). In the model, decoupling births from marriage (+0.37) and closing the status gap or raising men's prospects (about +0.2) beat realistic cash (+0.08). Japan contradicts the age-29 ratchet: first-birth age reached 30.7 and TFR rose from 1.26 to 1.45 (2005-2015).


## Unified suite (U1-U4)
See UNIFIED_FINDINGS.md. The placebo test fails for the women-overtaking term: 31% of shuffled enrolment histories fit as well, and the year-to-year correlation has the wrong sign. So X1b gives no national-level evidence for the mechanism. All six places fell below their development path from 2015 to 2024 (average -0.46), which looks like a common shock. A common channel with onset 2015-2020 improves held-out error (0.390 against 0.401), and country-to-country spillover does not help. In the synthetic cohort model, the credential race is the universal channel (about -0.4 in either regime), while the matching squeeze amplifies the fall only where births need marriage (-0.42 against -0.12).


## Page suite (P1-P4)
See PAGE_FINDINGS.md. The eight models are effectively 1.33 models (error correlation 0.83). Survival alone beats any crowd (held-out squared error 0.330 against 0.448-0.453). In the threshold model, a temporary shock causes a permanent drop only with peer feedback in a homogeneous society. With strong feedback, undoing a collapse takes about 8x the push that would have prevented it. The cohort-model rankings hold in 86-100% of 400 parameter draws, partly by construction.


## Modernity suite (F1-F4), prompted by Fernandez-Villaverde
See MODERNITY_FINDINGS.md. Against income, the fertility curve shifted down after 1985 (gap 1.50, mostly at the low end), and a time-drifting income curve predicts better (0.86 vs 1.09). Against survival it needs no drift (0.61 static vs 0.71 drift); infant mortality is the steadiest yardstick (0.54). Replacement arrived at incomes 16x apart ($990-$16,279, -28% per decade later) but within 67.5-74.7 years of life expectancy. After 2015 all six fell below their own 2000-14 gap trend (mean -0.71), so the drop is a break, not the old drift continuing.


## Microplastics / biological fecundity test
See MICROPLASTICS_FINDINGS.md. A fecundity shock needs 60% fewer conceptions to explain Korea and puts 0% of the fall through marriage. It scores 1/5 on the Korean facts (3/5 with hypergamy, against 5/5 for credential floor plus hypergamy). The timing test cannot separate smooth plastics exposure from a 2015 step. The post-2015 drop is unrelated to marriage regime (r = +0.01), so it is a universal shock and not the marriage squeeze; biology is not ruled out for that part.


## Late marriage x biological clock
See FECUNDITY_AGE_FINDINGS.md. The monthly reproductive model is calibrated to Habbema et al. 2015 (within 1-6 points on five targets). Moving Korean women's marriage from 25.3 to 31.6 costs 0.21 children per married woman (1.83 to 1.61 of two wanted). Involuntary childlessness rises from 8% to 15%. This explains about 21% of Korea's TFR fall with marriage rates held fixed. It matches the first-birth fall but less than half of the second-birth fall. No IVF is modelled, so this is an upper bound.


## Clock across six places
See FECUNDITY_COUNTRIES_FINDINGS.md. Late marriage plus the biological clock explains about 26% of the fall in Hong Kong, 21% in Korea and 18% in China. In Japan it is consistent with the whole small 1995-2019 change. In Thailand (estimate) and the Philippines it explains 1-2%, because unions still start in the early-to-mid 20s. Each extra year of delay cuts births per married couple about 2 points (r = +0.93).


## IVF, decomposition and policy
See IVF_POLICY_FINDINGS.md. IVF, calibrated to Habbema and validated against Korea's 15.1% treatment births at about 71% uptake, gives back only 16% of the clock cost. In the completed-family decomposition, 2000-2024, marriage accounts for 16-39%, the clock for 9%, and the within-marriage residual for 51-75%. This conflicts with period decompositions; it may reflect a post-2015 within-marriage drop. Policy: ever-married +10 pts (+0.12) and second-birth support (+0.13) beat marriage 2 years earlier (+0.04) and full IVF (+0.02). All four together give +0.35.


## Kate's model
See KATE_FINDINGS.md. Education expansion works through four channels, giving completed fertility 1.84 to 1.43 (-22%) and marriage age 23.3 to 26.0. Shapley split: more choices 68% (set by assumption), partner standard 27%, career start 3% (but +1.1 years of marriage age), diet and stress 2%. The partner standard alone produces the leftover pattern: 16% of tertiary women and 17% of non-tertiary men never married. Halving conception chances costs little unless marriage is late.


## Kate round 2 and momentum test
See ROUND_KATE2_MOMENTUM_FINDINGS.md. Survey intentions (1.76 to 1.70; educated women not lower) shrink Kate's fall to -13%. Housing plus a 5-year career start reproduces China's +4.7-year marriage delay. Intended 1.70 against achieved 1.39: biology 0.14, never marrying 0.13, clock 0.04. Momentum is highest in Thailand and the Philippines (smooth trends), and pull-back appears only in Japan and Hong Kong. Pre-2015 dynamics did not predict the post-2015 depth (China predicted 1.86 against 1.01 actual).


## The post-2015 shock (12 experiments)
See SHOCK_FINDINGS.md. The six-place synchronized fall is unique since 1975. It was mostly pre-COVID in Korea, the Philippines and Thailand, and mostly COVID-era in China, Hong Kong and Japan. Break years do not follow local smartphone adoption (r = -0.46). Korean births per marriage fell 12% pre-COVID, then marriages collapsed in 2020-24. Fertility became pro-cyclical after 2015 (r 0.46 against 0.13). The phone-proxy mechanisms that fit are social comparison / intensive parenting and anxiety / pessimism, not courtship displacement.
