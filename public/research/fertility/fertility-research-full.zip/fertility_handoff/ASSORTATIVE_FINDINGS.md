# Assortative mating plus rising competition (Korea)

Run `python mechanism_assortative.py` (output in `results/mechanism_assortative.txt` and `.json`). Trey's question: could assortative mating combined with increased competition explain Korea's pattern on its own? By competition he means everyone becoming more competitive, both in investing in themselves and in whom they choose.

## Set-up

Each person has a status score (education, income, prospects). One competition strength moves two things together:
- **Pickier choice:** a couple forms only if their status scores are within a band, and the band narrows. This is two-sided assortative mating.
- **More self-investment:** everyone spends up to 3 more years in school and credentials before entering the marriage market.

It is tuned so completed fertility falls from 1.64 to 1.20, then scored on the same five Korean facts as `mechanism_signatures.py`.

## Results

1. **With the same status distribution for both sexes, it cannot work.** Even at maximum pickiness, completed fertility does not fall to 1.20. If everyone wants someone like themselves and the two distributions match, almost everyone still finds a match. Assortative mating alone does not reduce marriage.
2. **Once women's status rises past men's, it reproduces all five Korean facts.** This is what has been measured: among Koreans aged 19–34 in 2020, 58.4% of women had a degree against 47.8% of men. The narrowing band then pinches high-status women and low-status men:
   - 84% of the fall comes through fewer marriages;
   - births come 2.2 years later;
   - married women still nearly all have a first child, and the second-birth fall shows up;
   - top-half women are 41 points more likely to stay single than bottom-half women;
   - bottom-half men are 44 points more likely than top-half men.
3. **The two halves of competition do different jobs.** At the tuned strength:
   - Pickier choice alone cuts marriage (76% ever married) and fertility to 1.29, with no delay.
   - More self-investment alone delays births by about 2.3 years, with almost no effect on marriage, and fertility falls only to 1.53.
   - Together they give 1.20, with fewer and later marriages: Korea's "fewer and later".
4. **How picky people need to be depends on the size of the status gap:**

| Gap between women's and men's status | Partner band needed | Extra schooling |
| ---: | ---: | ---: |
| 0.6 SD | ±0.13 SD (extreme) | 3.0 years |
| 0.8 SD | ±0.38 SD | 2.7 years |
| 1.0 SD | ±0.55 SD | 2.5 years |
| 1.2 SD | ±0.68 SD | 2.4 years |

## What it means

This is a more general version of the best pair in `MECHANISMS_FINDINGS.md`, credential floor plus hypergamy, and it needs no separate job rule. Competition in oneself produces the delay. Competition in whom one chooses produces the fall in marriage, but only because the two sexes' status distributions have moved apart. The key ingredient is the mismatch, not the pickiness.

It also does not need hypergamy as a separate preference. Symmetric "like with like" preferences are enough once women's status distribution sits above men's.

## Limits

- **Status is one dimension.** In reality education, income and job security are separate, and people weigh them differently by sex.
- **The real band width is unknown.** Educational assortative-mating correlations are typically moderate, so the 1.0–1.2 SD rows are the plausible ones only if the relevant status gap really is that large. That is not measured here.
- **Synthetic and invented.** One cohort, invented parameters, no divorce or cohabitation. As before, this shows the mechanism *can* produce Korea's pattern, not that it did.
- **The decisive test is the next one:** marriage rates by both partners' education and income, over time. If pickier matching under a widening status gap is the story, the unmarried should be concentrated among high-status women and low-status men, increasingly so over time. Korean census tables by sex and education, or the KLI and KERI microdata, could check that.
