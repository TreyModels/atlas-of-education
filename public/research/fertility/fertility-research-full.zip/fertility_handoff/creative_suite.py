"""Creative suite: testing The Networked Domus phase-2 mechanism across places and policies.

X1  One model, six places. A marriage-squeeze term driven by each place's own female-to-male tertiary
    enrolment history (education_ratio.json), scaled by how bound childbearing is to marriage, is added to
    the leave-one-out survival (development) model. Its three parameters (how strongly the enrolment ratio
    maps to a status gap, how far women will marry down, and the lag from enrolment to marriage) are fitted
    on five places and the sixth is predicted. Compared with development alone. The fitted lag tests the
    paper's 15-20 year lag claim.
X2  Policy levers in a squeeze world. In a Korea-like marriage-squeeze cohort, which interventions raise
    completed fertility: cash for births, looser partner norms, raising low-status men's prospects, a
    cross-border marriage valve, finishing credentials earlier, or accepting births outside marriage?

Matching rule: a woman accepts a man whose status is at least her own minus b (she will not marry far
down); marrying up is always acceptable. Women's status mean is shifted by d = k * ln(enrolment ratio).
Deterministic (fixed seeds); numpy only. Synthetic mechanisms with fitted or invented parameters: shows what
the mechanism can and cannot reproduce, not causal effects.
"""
import bisect
import contextlib
import io
import json
import os
import runpy

import numpy as np
from scipy.optimize import minimize

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "results")
LINES, RES = [], {}


def say(s=""):
    print(s)
    LINES.append(s)


with contextlib.redirect_stdout(io.StringIO()):
    TD = runpy.run_path(os.path.join(HERE, "timing_depth_test.py"))
TFR, YEARS, PLACES = TD["TFR"], TD["YEARS"], TD["PLACES"]
SURV = TD["paths"]["M2 survival"]          # leave-one-out survival (development) model paths

E = json.load(open(os.path.join(HERE, "education_ratio.json")))


def gpi_series(c):
    v = E[c]["values"]
    ys = np.array(sorted(int(y) for y in v))
    vals = np.array([float(v[str(y)]) for y in ys])
    allyears = np.arange(1940, 2025)
    return dict(zip(allyears, np.interp(allyears, ys, vals)))   # flat before first / after last observation


GPI = {c: gpi_series(c) for c in PLACES}

# share of births outside marriage (how far childbearing escapes the marriage market)
# PHL 0.58 (2022, UPPI/PSA); KOR ~0.04 (96.1% marital, 2022); JPN ~0.025 (OECD Family Database: below 10 pp change since 1970).
# HKG, CHN, THA: not looked up for this run -> assumptions, varied in the sensitivity check below.
NONMARITAL = {"PHL": 0.58, "KOR": 0.04, "JPN": 0.025, "HKG": 0.08, "CHN": 0.05, "THA": 0.20}

# ------------------------------------------------------------------ marriage-share lookup table
N = 3000


def married_share(d, b, seed=11):
    rng = np.random.default_rng(seed)
    zw = rng.normal(d, 1, N)
    zm = np.sort(rng.normal(0, 1, N)).tolist()
    order = rng.permutation(N)
    matched = 0
    for w in order:
        lo = bisect.bisect_left(zm, zw[w] - b)          # any man at or above (her status - b)
        if lo < len(zm):
            k = lo + int(rng.integers(len(zm) - lo))
            zm.pop(k)
            matched += 1
    return matched / N


DG = np.round(np.arange(-1.5, 1.51, 0.1), 2)
BG = np.round(np.arange(0.0, 2.01, 0.1), 2)
TABLE = np.array([[married_share(d, b) for b in BG] for d in DG])


def M(d, b):
    d = np.clip(d, DG[0], DG[-1])
    b = float(np.clip(b, BG[0], BG[-1]))
    j = np.interp(b, BG, np.arange(len(BG)))
    j0 = int(np.floor(j)); j1 = min(j0 + 1, len(BG) - 1); wj = j - j0
    col = TABLE[:, j0] * (1 - wj) + TABLE[:, j1] * wj
    return np.interp(d, DG, col)


def predict(c, k, b, lag, nm=None):
    nm = NONMARITAL[c] if nm is None else nm
    g = np.array([GPI[c][int(y - lag)] if int(y - lag) in GPI[c] else GPI[c][1940] for y in YEARS])
    d = k * np.log(g)
    rel = M(d, b) / M(np.zeros_like(d) - 1.0, b)     # relative to a no-squeeze reference (women well below men)
    return SURV[c] * (nm + (1 - nm) * rel)


WIN = YEARS >= 1985


def loss(params, places, nmmap=None):
    k, b, lag = params
    if not (0 <= k <= 6 and 0 <= b <= 2 and 0 <= lag <= 30):
        return 1e6
    return float(np.mean(np.concatenate([np.abs(predict(c, k, b, round(lag), None if nmmap is None else nmmap[c])[WIN] - TFR[c][WIN]) for c in places])))


def fit(places, nmmap=None):
    best = None
    for lag in range(0, 31, 2):
        for k0 in (0.5, 1.5, 3.0):
            for b0 in (0.2, 0.6, 1.2):
                r = minimize(lambda p: loss((p[0], p[1], lag), places, nmmap), [k0, b0], method="Nelder-Mead",
                             options=dict(xatol=1e-3, fatol=1e-4, maxiter=300))
                v = r.fun
                if best is None or v < best[0]:
                    best = (v, r.x[0], r.x[1], lag)
    return best


say("X1. ONE MODEL, SIX PLACES: development + marriage squeeze from each place's own enrolment ratio")
say("Fit on five places (1985-2024), predict the sixth. Error = mean |predicted - observed TFR|, 1985-2024.")
rows = []
fits = {}
for c in PLACES:
    train = [x for x in PLACES if x != c]
    v, k, b, lag = fit(train)
    fits[c] = (k, b, lag)
    p = predict(c, k, b, lag)
    e_sq = float(np.mean(np.abs(p[WIN] - TFR[c][WIN])))
    e_dev = float(np.mean(np.abs(SURV[c][WIN] - TFR[c][WIN])))
    rows.append(dict(place=c, k=round(k, 2), b=round(b, 2), lag=lag, err_development=round(e_dev, 3),
                     err_development_plus_squeeze=round(e_sq, 3), tfr2024_obs=round(float(TFR[c][-1]), 2),
                     tfr2024_dev=round(float(SURV[c][-1]), 2), tfr2024_squeeze=round(float(p[-1]), 2)))
    say(f"  {c}: fitted on others k {k:.2f}, b {b:.2f}, lag {lag:2d}y | error dev {e_dev:.3f} -> dev+squeeze {e_sq:.3f} | "
        f"2024 obs {TFR[c][-1]:.2f}, dev {SURV[c][-1]:.2f}, dev+squeeze {p[-1]:.2f}")
md = np.mean([r["err_development"] for r in rows]); ms = np.mean([r["err_development_plus_squeeze"] for r in rows])
say(f"  Mean held-out error: development {md:.3f}, development + squeeze {ms:.3f}; places improved: "
    f"{sum(r['err_development_plus_squeeze'] < r['err_development'] for r in rows)} of 6")
RES["X1_loco"] = rows

# scope condition: what if childbearing were assumed marriage-bound everywhere (Philippines too)?
nm_all = {c: 0.03 for c in PLACES}
v, k, b, lag = fit([x for x in PLACES if x != "PHL"], nm_all)
pp = predict("PHL", k, b, lag, 0.03)
say(f"\n  Scope check, Philippines treated as marriage-bound (non-marital share 3% instead of 58%): "
    f"held-out error {np.mean(np.abs(pp[WIN]-TFR['PHL'][WIN])):.3f} (vs {rows[0]['err_development_plus_squeeze']:.3f}); "
    f"2009 predicted {pp[YEARS==2009][0]:.2f} vs observed {TFR['PHL'][YEARS==2009][0]:.2f}")
RES["X1_scope_PHL_marriage_bound"] = dict(err=float(np.mean(np.abs(pp[WIN]-TFR['PHL'][WIN]))),
                                          pred2009=float(pp[YEARS == 2009][0]))

# sensitivity to the assumed non-marital shares for HKG, CHN, THA
say("  Sensitivity, assumed non-marital shares for Hong Kong, China, Thailand (all-place fit):")
sens = []
for lab, alt in [("low", {"HKG": 0.03, "CHN": 0.02, "THA": 0.10}), ("high", {"HKG": 0.15, "CHN": 0.10, "THA": 0.40})]:
    nmm = dict(NONMARITAL); nmm.update(alt)
    v, k, b, lag = fit(PLACES, nmm)
    sens.append(dict(case=lab, k=round(k, 2), b=round(b, 2), lag=lag, in_sample_err=round(v, 3)))
    say(f"    {lab:4s}: k {k:.2f}, b {b:.2f}, lag {lag}y, in-sample error {v:.3f}")
v, k, b, lag = fit(PLACES)
say(f"    base: k {k:.2f}, b {b:.2f}, lag {lag}y, in-sample error {v:.3f}")
RES["X1_sensitivity"] = sens + [dict(case="base", k=round(k, 2), b=round(b, 2), lag=lag, in_sample_err=round(v, 3))]

# lag profile on all places
say("  Lag profile (all-place fit, error by lag):")
prof = []
for L in range(0, 31, 5):
    best = min((minimize(lambda p: loss((p[0], p[1], L), PLACES), [k0, b0], method="Nelder-Mead").fun, k0)
               for k0 in (0.5, 1.5, 3.0) for b0 in (0.2, 0.6, 1.2))[0]
    prof.append(dict(lag=L, err=round(best, 3)))
say("    " + "  ".join(f"{p['lag']}y:{p['err']:.3f}" for p in prof))
RES["X1_lag_profile"] = prof

# ------------------------------------------------------------------ X1b relative gain
say("\nX1b. SAME TEST, BUT THE SQUEEZE IS DRIVEN BY HOW FAR WOMEN'S RELATIVE POSITION HAS RISEN")
say("Status gap d = k * [ln(ratio at t - lag) - ln(ratio in the earliest observed year)]: norms set when")
say("women's relative position was lower meet a later generation in which it is higher.")
BASEG = {c: GPI[c][1940] for c in PLACES}


def predict_rel(c, k, b, lag, nm=None):
    nm = NONMARITAL[c] if nm is None else nm
    g = np.array([GPI[c][int(y - lag)] if int(y - lag) in GPI[c] else GPI[c][1940] for y in YEARS])
    d = k * (np.log(g) - np.log(BASEG[c]))
    rel = M(d, b) / M(np.zeros_like(d) - 1.0, b)
    return SURV[c] * (nm + (1 - nm) * rel)


def loss_rel(params, places):
    k, b, lag = params
    if not (0 <= k <= 6 and 0 <= b <= 2 and 0 <= lag <= 30):
        return 1e6
    return float(np.mean(np.concatenate([np.abs(predict_rel(c, k, b, round(lag))[WIN] - TFR[c][WIN]) for c in places])))


def fit_rel(places):
    best = None
    for lag in range(0, 31, 2):
        for k0 in (0.5, 1.5, 3.0):
            for b0 in (0.2, 0.6, 1.2):
                r = minimize(lambda q: loss_rel((q[0], q[1], lag), places), [k0, b0], method="Nelder-Mead",
                             options=dict(xatol=1e-3, fatol=1e-4, maxiter=300))
                if best is None or r.fun < best[0]:
                    best = (r.fun, r.x[0], r.x[1], lag)
    return best


say("  Earliest observed ratio: " + ", ".join(f"{c} {BASEG[c]:.2f}" for c in PLACES) +
    "; latest: " + ", ".join(f"{c} {GPI[c][2024]:.2f}" for c in PLACES))
rows_b = []
for c in PLACES:
    v, k, b, lag = fit_rel([x for x in PLACES if x != c])
    p = predict_rel(c, k, b, lag)
    e = float(np.mean(np.abs(p[WIN] - TFR[c][WIN])))
    rows_b.append(dict(place=c, k=round(k, 2), b=round(b, 2), lag=lag, err=round(e, 3),
                       err_development=[r for r in rows if r["place"] == c][0]["err_development"],
                       tfr2024=round(float(p[-1]), 2), tfr2024_obs=round(float(TFR[c][-1]), 2)))
    say(f"  {c}: fitted on others k {k:.2f}, b {b:.2f}, lag {lag:2d}y | error {e:.3f} "
        f"(development {rows_b[-1]['err_development']:.3f}) | 2024 {p[-1]:.2f} vs obs {TFR[c][-1]:.2f}")
say(f"  Mean held-out error: development {md:.3f}, level version {ms:.3f}, relative-gain version "
    f"{np.mean([r['err'] for r in rows_b]):.3f}; places better than development: "
    f"{sum(r['err'] < r['err_development'] for r in rows_b)} of 6")
v, k, b, lag = fit_rel(PLACES)
say(f"  All-place fit: k {k:.2f}, b {b:.2f}, lag {lag}y, error {v:.3f}")
prof_b = []
for L in range(0, 31, 5):
    bb = min(minimize(lambda q: loss_rel((q[0], q[1], L), PLACES), [k0, b0], method="Nelder-Mead").fun
             for k0 in (0.5, 1.5, 3.0) for b0 in (0.2, 0.6, 1.2))
    prof_b.append(dict(lag=L, err=round(bb, 3)))
say("  Lag profile: " + "  ".join(f"{q['lag']}y:{q['err']:.3f}" for q in prof_b))
RES["X1b_relative_gain"] = dict(loco=rows_b, all_fit=dict(k=k, b=b, lag=lag, err=v), lag_profile=prof_b)

# ------------------------------------------------------------------ X2 policy levers
say("\nX2. POLICY LEVERS IN A MARRIAGE-SQUEEZE WORLD (Korea-like cohort)")
say("Women's status 1 SD above men's; women will not marry more than 0.55 SD down; births mostly marital.")
AGES = range(18, 46)


def fecund(age):
    return np.clip((45 - age) / 10, 0, 1) if age >= 35 else 1.0


def cohort(gap=1.0, band=0.55, men_up=0.0, valve=0.0, delay=2.5, cash=0.0, nonmarital=0.0, seed=7, n=8000):
    rng = np.random.default_rng(seed)
    nm_ = int(n * (1 + valve))
    zm = rng.normal(men_up, 1, nm_)
    if valve:
        zm[n:] = rng.normal(gap, 0.6, nm_ - n)          # cross-border partners, status near the women's
    zw = rng.normal(gap, 1, n)
    m_entry = 20 + delay + 2 * (zm > 0.1); w_entry = 19 + delay + 2 * (zw > 0.1)
    m_free = np.ones(nm_, bool); w_mar = np.zeros(n, bool); parity = np.zeros(n, int); ages = []
    h1, h2, h3 = 0.50, 0.07 * (1 + cash), 0.01 * (1 + cash)
    for age in AGES:
        elig = np.flatnonzero(m_free & (age >= m_entry)); o = np.argsort(zm[elig])
        pz = list(zm[elig][o]); pid = list(elig[o])
        women = np.flatnonzero((~w_mar) & (age >= w_entry) & (rng.random(n) < 0.2)); rng.shuffle(women)
        for w in women:
            lo = bisect.bisect_left(pz, zw[w] - band)
            if lo < len(pz):
                k = lo + int(rng.integers(len(pz) - lo)); m = pid.pop(k); pz.pop(k); m_free[m] = False; w_mar[w] = True
        hz = np.select([parity == 0, parity == 1], [h1, h2], h3) * fecund(age)
        born = (w_mar & (rng.random(n) < hz)) | ((~w_mar) & (age >= 25) & (rng.random(n) < hz * nonmarital))
        ages.extend([age] * int(born.sum())); parity += born
    return float(parity.mean()), float(w_mar.mean()), float(np.mean(ages))


base_cf, base_em, base_age = cohort()
say(f"  Baseline: completed fertility {base_cf:.2f}, ever married {base_em:.2f}, mean age at birth {base_age:.1f}")
levers = [
    ("Cash for births (+30% second and later birth rates)", dict(cash=0.30)),
    ("Bigger cash (+100% second and later birth rates)", dict(cash=1.00)),
    ("Looser partner norms (marry-down limit 0.55 -> 0.85 SD)", dict(band=0.85)),
    ("Raise low-status men's prospects (+0.5 SD for all men)", dict(men_up=0.5)),
    ("Cross-border marriage valve (+15% partners near women's status)", dict(valve=0.15)),
    ("Finish credentials 2 years earlier", dict(delay=0.5)),
    ("Accept births outside marriage (single women at 30% of marital rates from 25)", dict(nonmarital=0.30)),
    ("Close the status gap (women's lead 1.0 -> 0.5 SD)", dict(gap=0.5)),
]
pol = []
for nm, kw in levers:
    cf, em, ma = cohort(**kw)
    pol.append(dict(lever=nm, cf=round(cf, 3), change=round(cf - base_cf, 3), ever_married=round(em, 3), mean_age=round(ma, 2)))
    say(f"  {nm:72s} CF {cf:.2f} ({cf-base_cf:+.2f}); ever married {em:.2f}; birth age {ma:.1f}")
RES["X2_policy"] = dict(baseline=dict(cf=base_cf, ever_married=base_em, mean_age=base_age), levers=pol)

with open(os.path.join(OUT, "creative_suite.txt"), "w") as f:
    f.write("\n".join(LINES) + "\n")
json.dump(RES, open(os.path.join(OUT, "creative_suite.json"), "w"), indent=1, default=float)
