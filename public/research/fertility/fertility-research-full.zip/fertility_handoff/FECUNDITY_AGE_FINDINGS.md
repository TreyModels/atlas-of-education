# Late marriage × the biological clock

Script: `fecundity_age_model.py` (about 50 seconds). Results: `results/fecundity_age_model.txt` and `results/fecundity_age_model.json`.

This is a monthly reproductive simulation:
- conception chances differ between couples and fall with age;
- permanent sterility arrives at an individual age;
- miscarriage risk rises with age;
- pregnancy lasts 9 months, then couples wait before trying again.

Couples try until they reach the number of children they want, or until sterility or age 50. IVF is not modelled, so every cost here is an upper bound.

## A1. Calibrated to Habbema et al. (2015), natural conception

| Start trying at | Children wanted | Published chance | Model |
|---|---|---|---|
| 32 | 1 | 90% | 89% |
| 27 | 2 | 90% | 91% |
| 23 | 3 | 90% | 92% |
| 41 | 1 | 50% | 47% |
| 35 | 3 | 50% | 56% |

Fitted biology:
- monthly conception chance 0.16, declining from age 34;
- median age at sterility 43;
- 6% of couples infertile from the start.

## A2. Korea: women's first marriage at 25.3 (1995) vs 31.6 (2024)

Couples want two children and start trying a year after marrying. The marriage age is spread with a standard deviation of 3.5 years.

| | 1995 schedule | 2024 schedule |
|---|---|---|
| Children per married woman (2 wanted) | 1.83 | 1.61 |
| Involuntarily childless | 7.8% | 15.4% |
| Stop at one | 1.9% | 7.7% |

- The later marriage costs **0.21 children per married woman**, or 12%.
- With marriage rates held fixed, that alone takes TFR from 1.63 to 1.44.
- Korea is at 0.72, so **the clock explains about a fifth (21%) of the fall.** The other four fifths come from fewer marriages and from choices.

## A3. Signature

| | Model: 1995 → 2024 | Korea (OECD) |
|---|---|---|
| Married women reaching a first birth | 0.92 → 0.85 (−0.08) | 0.92 → 0.87 (−0.05) |
| Second birth given a first | 0.98 → 0.91 (−0.07) | 0.71 → 0.54 (−0.17) |

- The clock accounts for Korea's small fall in first births.
- It accounts for less than half of the second-birth fall. The rest has to be a choice, consistent with cost and the credential race.

## A4. The cliff: wanting two, by the age trying starts

| Start | Children | Both | None |
|---|---|---|---|
| 25 | 1.85 | 92% | 7% |
| 30 | 1.78 | 87% | 9% |
| 32 | 1.72 | 83% | 12% |
| 35 | 1.53 | 71% | 18% |
| 37 | 1.32 | 58% | 26% |
| 39 | 1.04 | 43% | 38% |
| 41 | 0.73 | 26% | 53% |

- The loss is gentle until the early 30s, then steepens sharply.
- Korean women now marry at 31.6 on average and have a first child at 33.7, which puts the median couple at the edge of the steep part.

## Reading

1. **Late marriage plus the clock is a real amplifier, worth about 0.2 children per married woman in Korea.** It explains about a fifth of the fall, more than microplastics could, and it works through a measured mechanism.
2. **It is not the main cause.** Fewer marriages and second-birth choices are larger.
3. **It sharpens the marriage story.** Every year that the marriage market delays a match costs more children than the last, especially past 33–35. A marriage-market fix that pulls weddings earlier gains twice: more marriages, and more births per marriage.
4. **IVF would shrink the cost.** In Habbema et al., IVF moves the 90% thresholds three to four years later.

Sources:
- Habbema, Eijkemans, Leridon & te Velde (2015), *Human Reproduction* 30(9): 2215–21: https://pure.eur.nl/en/publications/realizing-a-desired-family-size-when-should-couples-start/
- Statistics Korea (2025), via Korea Times: https://www.koreatimes.co.kr/amp/southkorea/society/20250903/marriages-in-korea-rise-for-2nd-straight-year-in-2024-data
