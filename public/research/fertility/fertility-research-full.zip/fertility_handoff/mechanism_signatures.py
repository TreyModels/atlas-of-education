"""Why later and fewer? A signature test of Trey's mechanisms against rivals (Korea).

Each mechanism is switched on ALONE in the same synthetic cohort simulation, and its strength is tuned
so completed fertility falls by the same amount (about 1.64 -> 1.20 children per woman, roughly the size
of Korea's shortfall below its development path). The mechanisms are
then scored on five Korean facts they were NOT tuned to:

  S1  Most of the decline comes from fewer women marrying, not fewer births per married woman.
      (Choi 2022, J. Population Research: proportion married is the main contributor 1990-2015 and marital
      birth rates contributed an increase; KIHASA 2015: marital fertility rose 2005-2013 while marriage fell;
      about 96% of Korean births are within marriage.)
  S2  Childbearing moves later: mean age at birth rises by at least 1.5 years
      (Korea 2012-2022: 31.25 -> 33.38, experimental_suite.py E2).
  S3  Married women still mostly reach a first birth; the per-married-woman fall is concentrated in
      second births rather than first (OECD synthetic progressions: first-birth progression 0.92 -> 0.87,
      second 0.71 -> 0.54, 1984-97 to 1998-2014).
  S4  More-educated women are MORE likely to stay single (2020 census reporting: women with higher
      education married less; 22.1% of women with master's degrees single in their 30s).
  S5  Men's marriage follows their economic position: low-earning, non-regular and less-qualified men stay
      single far more often (Korea Labor Institute 2017-19: ever married at 36-40, 47% in the bottom
      income decile vs 91% in the top; KERI: regular workers marry 1.65 times as often as non-regular
      workers with education and age held constant). Proxy here: high-school men single by 45 minus
      college men, at least 5 points.

Mechanisms (Trey's hypotheses first, then rivals):
  M1  Credential floor and job queue: men need a stable formal job to marry; the queue lengthens.
  M2  Ranked competition: rising per-child investment cost lowers second and later births in marriage.
  M2a Anticipated child cost deters marriage itself (the anticipation version of M2).
  M3  Old-age value of children falls (pensions, weaker kin obligations): fewer third and later births,
      and somewhat fewer second births.
  R1  Housing threshold: couples need savings from years of stable work before marrying.
  R2  Educational hypergamy: women marry men with at least their own education, while women's college
      share rises past men's.
  R3  Ideation: marriage becomes less desired for everyone.

This is a synthetic signature test with invented parameters. It shows which mechanisms CAN produce
Korea's pattern, not which one did. Deterministic (fixed seeds); numpy only.
"""
import json
import os

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "results")
os.makedirs(OUT, exist_ok=True)

N = 12000               # women (and the same number of men) per run
AGES = range(18, 46)
BASE = dict(job_hs=0.35, job_col=0.45, marry=0.20, h1=0.50, h2=0.07, h3=0.01,
            house=0, col_w=0.30, col_m=0.45, hypergamy=False)


def apply(mech, s):
    p = dict(BASE)
    if mech == "M1":   # credential floor: stable-job hazards fall, more for those below the floor
        p["job_hs"] *= (1 - 0.99 * s)
        p["job_col"] *= (1 - 0.9 * s)
    elif mech == "M2":
        p["h2"] *= (1 - s)
        p["h3"] *= (1 - s)
    elif mech == "M2a":
        p["marry"] *= (1 - 0.9 * s)
    elif mech == "M3":
        p["h3"] *= (1 - s)
        p["h2"] *= (1 - 0.6 * s)
    elif mech == "R1":
        p["house"] = 20 * s          # years of stable work the man needs before marrying
    elif mech == "R2":
        p["hypergamy"] = True
        p["col_w"] = 0.30 + 0.55 * s
    elif mech == "R3":
        p["marry"] *= (1 - 0.9 * s)
    elif mech != "none":
        raise ValueError(mech)
    return p


def fecund(age):
    return np.clip((45 - age) / 10, 0, 1) if age >= 35 else 1.0


def simulate(p, seed=7):
    rng = np.random.default_rng(seed)
    w_col = rng.random(N) < p["col_w"]
    m_col = rng.random(N) < p["col_m"]
    m_school_end = np.where(m_col, 24, 20)          # men finish school (incl. service) later with college
    w_school_end = np.where(w_col, 23, 19)
    m_job = np.zeros(N, bool)
    m_job_years = np.zeros(N)
    m_married = np.zeros(N, bool)
    w_married = np.zeros(N, bool)
    w_marriage_age = np.full(N, np.nan)
    parity = np.zeros(N, int)
    birth_ages, birth_parity = [], []
    for age in AGES:
        # men: stable formal job queue
        seeking = (~m_job) & (age >= m_school_end)
        hz = np.where(m_col, p["job_col"], p["job_hs"])
        m_job |= seeking & (rng.random(N) < hz)
        m_job_years += m_job
        # marriage market
        eligible_m = (~m_married) & m_job & (m_job_years >= p["house"]) & (age >= m_school_end)
        want_w = (~w_married) & (age >= w_school_end) & (rng.random(N) < p["marry"])
        women = np.flatnonzero(want_w)
        rng.shuffle(women)
        if p["hypergamy"]:
            women = np.r_[women[w_col[women]], women[~w_col[women]]]   # constrained women search first
        pool_col = list(np.flatnonzero(eligible_m & m_col))
        pool_hs = list(np.flatnonzero(eligible_m & ~m_col))
        rng.shuffle(pool_col)
        rng.shuffle(pool_hs)
        for w in women:
            if p["hypergamy"] and w_col[w]:
                pools = [pool_col]
            else:
                pools = [pool_col, pool_hs] if rng.random() < len(pool_col) / max(1, len(pool_col) + len(pool_hs)) else [pool_hs, pool_col]
            for pool in pools:
                if pool:
                    m = pool.pop()
                    m_married[m] = True
                    w_married[w] = True
                    w_marriage_age[w] = age
                    break
        # births, married women only (96% of Korean births are marital)
        f = fecund(age)
        hz = np.select([parity == 0, parity == 1], [p["h1"], p["h2"]], p["h3"]) * f
        born = w_married & (rng.random(N) < hz)
        birth_ages.extend([age] * int(born.sum()))
        birth_parity.extend(parity[born].tolist())
        parity += born
    ever = w_married
    return dict(
        cf=parity.mean(),
        ever_married=ever.mean(),
        per_married=parity[ever].mean() if ever.any() else 0.0,
        mean_age_birth=float(np.mean(birth_ages)) if birth_ages else np.nan,
        p_first_married=float((parity[ever] >= 1).mean()) if ever.any() else 0.0,
        p_second_given_first=float((parity >= 2).sum() / max(1, (parity >= 1).sum())),
        single35_col=float(1 - np.mean(w_married[w_col])) if w_col.any() else np.nan,
        single35_hs=float(1 - np.mean(w_married[~w_col])),
        men_single_gap_hs_minus_col=float((1 - np.mean(m_married[~m_col])) - (1 - np.mean(m_married[m_col]))),
        mean_marriage_age=float(np.nanmean(w_marriage_age)),
    )


def tune(mech, target=1.20):
    lo, hi = 0.0, 1.0
    if simulate(apply(mech, hi))["cf"] > target:
        return None, None
    for _ in range(18):
        mid = (lo + hi) / 2
        if simulate(apply(mech, mid))["cf"] > target:
            lo = mid
        else:
            hi = mid
    return hi, simulate(apply(mech, hi))


base = simulate(apply("none", 0))
lines = []
say = lambda s="": (print(s), lines.append(s))
say("BASELINE (no mechanism): completed fertility %.2f, ever married %.2f, children per married woman %.2f, "
    "mean age at birth %.1f, P(2nd | 1st) %.2f, single by 45: college women %.2f vs high-school women %.2f"
    % (base["cf"], base["ever_married"], base["per_married"], base["mean_age_birth"], base["p_second_given_first"],
       base["single35_col"], base["single35_hs"]))

names = {"M1": "M1 credential floor / job queue (Trey)", "M2": "M2 ranked competition, per-child cost (Trey)",
         "M2a": "M2a anticipated child cost deters marriage (Trey)", "M3": "M3 old-age value of children falls (Trey)",
         "R1": "R1 housing threshold", "R2": "R2 hypergamy + rising women's college share", "R3": "R3 ideation: marriage less desired"}
rows = []
say("\nEach mechanism alone, tuned so completed fertility falls to 1.20. Then scored on S1-S5 (not tuned):")
for k, nm in names.items():
    s, r = tune(k)
    if r is None:
        say(f"  {nm:50s} cannot lower completed fertility to 1.20 on its own")
        rows.append(dict(mechanism=nm, reachable=False))
        continue
    d_total = base["cf"] - r["cf"]
    # decomposition of the fall: ever-married share vs children per married woman (symmetric)
    d_marry = 0.5 * ((base["ever_married"] - r["ever_married"]) * (base["per_married"] + r["per_married"]))
    share_marriage = d_marry / d_total
    shift_age = r["mean_age_birth"] - base["mean_age_birth"]
    first_drop = base["p_first_married"] - r["p_first_married"]
    second_drop = base["p_second_given_first"] - r["p_second_given_first"]
    edu_gap = r["single35_col"] - r["single35_hs"]
    S1 = bool(share_marriage >= 0.6)
    S2 = bool(shift_age >= 1.5)
    S3 = bool((second_drop >= first_drop) and (r["p_first_married"] >= 0.85))
    S4 = bool(edu_gap > 0.02)
    S5 = bool(r["men_single_gap_hs_minus_col"] >= 0.05)
    rows.append(dict(mechanism=nm, reachable=True, strength=round(s, 3), cf=round(r["cf"], 2),
                     share_of_fall_from_marriage=round(share_marriage, 2), age_shift=round(shift_age, 2),
                     marriage_age_shift=round(r["mean_marriage_age"] - base["mean_marriage_age"], 2),
                     p_first_among_married=round(r["p_first_married"], 2), p2_given_1=round(r["p_second_given_first"], 2),
                     single_gap_college_minus_hs=round(edu_gap, 3), men_gap_hs_minus_col=round(r["men_single_gap_hs_minus_col"], 3),
                     S1=S1, S2=S2, S3=S3, S4=S4, S5=S5, score=int(S1) + int(S2) + int(S3) + int(S4) + int(S5)))
    say(f"  {nm:50s} fall from marriage {share_marriage:5.0%} | birth age {shift_age:+.1f}y | "
        f"P(2nd|1st) {r['p_second_given_first']:.2f} | single gap col-hs {edu_gap:+.2f} | "
        f"men gap {r['men_single_gap_hs_minus_col']:+.2f} | "
        f"S1 {'Y' if S1 else '-'} S2 {'Y' if S2 else '-'} S3 {'Y' if S3 else '-'} S4 {'Y' if S4 else '-'} S5 {'Y' if S5 else '-'}  = {int(S1)+int(S2)+int(S3)+int(S4)+int(S5)}/5")

# pairs: each mechanism contributes half the fall
say("\nPairs (each mechanism at the strength that alone gives half the fall, to about 1.42), combined:")
half = {k: tune(k, target=1.42)[0] for k in names}
pairs = [("M1", "R2"), ("M1", "M2"), ("M1", "R1"), ("M2a", "R2"), ("R1", "R2"), ("M1", "M3"), ("R3", "R2")]
pair_rows = []
for a, b in pairs:
    if half[a] is None or half[b] is None:
        continue
    pa, pb = apply(a, half[a]), apply(b, half[b])
    p = dict(BASE)
    for key in p:
        if pa[key] != BASE[key]:
            p[key] = pa[key]
        if pb[key] != BASE[key]:
            p[key] = pb[key]
    r = simulate(p)
    d_total = base["cf"] - r["cf"]
    share_marriage = 0.5 * ((base["ever_married"] - r["ever_married"]) * (base["per_married"] + r["per_married"])) / d_total
    shift_age = r["mean_age_birth"] - base["mean_age_birth"]
    first_drop = base["p_first_married"] - r["p_first_married"]
    second_drop = base["p_second_given_first"] - r["p_second_given_first"]
    edu_gap = r["single35_col"] - r["single35_hs"]
    S = [bool(share_marriage >= 0.6), bool(shift_age >= 1.5), bool((second_drop >= first_drop) and r["p_first_married"] >= 0.85), bool(edu_gap > 0.02),
         bool(r["men_single_gap_hs_minus_col"] >= 0.05)]
    pair_rows.append(dict(pair=f"{a}+{b}", cf=round(r["cf"], 2), share_of_fall_from_marriage=round(share_marriage, 2),
                          age_shift=round(shift_age, 2), p2_given_1=round(r["p_second_given_first"], 2),
                          single_gap_college_minus_hs=round(edu_gap, 3), men_gap_hs_minus_col=round(r["men_single_gap_hs_minus_col"], 3),
                          S1=S[0], S2=S[1], S3=S[2], S4=S[3], S5=S[4], score=sum(S)))
    say(f"  {a+'+'+b:8s} CF {r['cf']:.2f} | fall from marriage {share_marriage:5.0%} | birth age {shift_age:+.1f}y | "
        f"P(2nd|1st) {r['p_second_given_first']:.2f} | single gap {edu_gap:+.2f} | men gap {r['men_single_gap_hs_minus_col']:+.2f} | "
        + " ".join(f"S{i+1} {'Y' if v else '-'}" for i, v in enumerate(S)) + f" = {sum(S)}/5")

with open(os.path.join(OUT, "mechanism_signatures.txt"), "w") as f:
    f.write("\n".join(lines) + "\n")
json.dump(dict(baseline=base, single=rows, pairs=pair_rows), open(os.path.join(OUT, "mechanism_signatures.json"), "w"),
          indent=1, default=float)
