# Why later and fewer? Testing Trey's mechanisms against rivals (Korea)

Run `python mechanism_signatures.py` (output in `results/mechanism_signatures.txt` and `.json`). This follows `SUITE_FINDINGS.md`, which showed *what* happened in Korea (births about 2 years later and about 25% fewer at every age). This file asks *why*.

## The fact that reframes the question

About 96% of Korean births are to married couples. Every published decomposition finds the decline runs mainly through fewer women being married, not through married couples having fewer children:
- Choi (2022, *Journal of Population Research*), 1990–2015: the proportion married is the main contributor, and marital birth rates actually contributed an *increase*.
- KIHASA (2015): from 2005 to 2013 marital fertility rose while marriage kept falling.
- The share of women aged 25–29 who have never married rose from about 40% in 2000 to 89% in 2024; at 30–34, from 11% to 58%.

So "later and fewer" in Korea is mostly "later and fewer marriages". A mechanism must work through marriage to be the main cause.

## The test

Seven mechanisms were each switched on alone in the same synthetic marriage-and-births simulation. Each was tuned so completed fertility falls by the same amount (1.64 to 1.20 children per woman, about the size of Korea's shortfall below its development path). Each was then scored on five Korean facts it was not tuned to:

| Fact | Korean evidence |
| --- | --- |
| S1 Most of the fall comes from fewer women marrying | Choi 2022; KIHASA 2015 |
| S2 Births move at least 1.5 years later | Mean age at birth 31.3 to 33.4, 2012–22 |
| S3 Married women still reach a first birth; the per-family fall is in second births | OECD progressions: first 0.92 to 0.87, second 0.71 to 0.54 |
| S4 More-educated women are more likely to stay single | 2020 census reporting |
| S5 Less-qualified or lower-earning men are more likely to stay single | Korea Labor Institute 2017–19; KERI |

## Results

**Single mechanisms (out of 5 facts):**

| Mechanism | Score | What it gets wrong |
| --- | ---: | --- |
| M1 Credential floor / job queue (Trey) | 3 | Not enough of the fall through marriage (47%, needs 60%); no education gradient among women |
| R2 Educational hypergamy, with women's college share rising past men's | 3 | No delay (+0.3 years) |
| M2a Anticipated child cost deters marriage (Trey) | 2 | No education gradients; identical to ideation on every fact |
| R1 Housing threshold | 2 | Delay far too large (+6.9 years); fall comes within marriage |
| R3 Ideation: marriage less desired | 2 | No education gradients |
| M2 Ranked competition, per-child cost within marriage (Trey) | 1 | Fall is entirely within marriage, and births get *younger* |
| M3 Old-age value of children falls (Trey) | — | Too weak to reach 1.20 alone (it acts on third births) |

**Pairs that match all five facts:**
- credential floor + hypergamy
- anticipated child cost + hypergamy
- ideation + hypergamy

No pair without hypergamy scores higher than 3. Ranked competition within marriage paired with the credential floor scores 1.

## What this says about Trey's hypothesis

1. **The credential floor is the strongest of the four proposed mechanisms, but it works through the marriage market, not the nursery.** Men who cannot get a stable formal job cannot marry. Combined with women's education rising past men's, that reproduces every Korean fact here.
   - The real-world evidence separates it from ideation: Korean regular workers marry at 1.65 times the rate of non-regular workers with education held constant (KERI), and at ages 36–40 only 47% of men in the bottom income decile have ever married against 91% in the top (Korea Labor Institute).
   - That is a job and income effect within education levels, which the credential-floor and job-queue mechanism predicts and ideation does not. The simulation cannot show this, because every version requires a stable job to marry; it is the measured gradient that does the work.
2. **Ranked competition fails as the main channel if it works inside marriage.** Raising the cost of each child cuts second births and makes births younger, not later, and leaves marriage untouched. That contradicts Korea's rising marital fertility in the 2000s. It could still contribute to the second-birth fall (S3).
3. **Ranked competition survives only in its anticipation form, but there it is indistinguishable from ideation.** If expected child costs deter marriage itself, the result matches "marriage less desired" on every fact here. Separating them needs data on why single people avoid marriage, for example stated reasons, or marriage rates by the expected cost of children.
4. **Old-age value fits the earlier transition, not ultra-low fertility.** It acts on third births, which collapsed in Korea between 1965–83 and 1984–97, but it cannot produce the recent fall.
5. **Housing alone delays too much.** As a single threshold it pushes marriage far later and cuts fertility within marriage. It may still matter regionally, which national data cannot test.

## Limits

- **Invented parameters.** This is a signature test: it shows which mechanisms can produce Korea's pattern, not how much each contributed.
- **Pass thresholds are judgement calls.** The 60% marriage share, the 1.5-year shift and the 5-point gap are choices, and the results near them (M1 at 47%) should be read as close, not as failures.
- **One synthetic cohort, not a period series,** with no divorce or cohabitation. Cohabitation matters for the Philippines but is rare in Korea.
- **Hypergamy is the only mechanism here that creates an education gradient among women,** so S4 favours it by construction. A richer model might generate the gradient other ways, for example through women's own career costs.
- **Evidence sources.** The Korean income and job gradients are from published reports (KLI, KERI) as covered in the press. The decompositions are from published abstracts.

## Sources

- Choi, Y. (2022). A decomposition of declining crude birth rate in South Korea, 1990–2015. *Journal of Population Research* 39(3). https://doi.org/10.1007/s12546-022-09287-3
- KIHASA (2015), *Causes of continued lowest-low fertility and future policy directions*. https://www.kdevelopedia.org/Resources/view/05201508040139326.do
- Korea Labor Institute, male income and marriage, 2017–19 data, as reported. https://www.asiae.co.kr/en/article/2023051412194167863
- Korea Economic Research Institute, marriage and birth rates by worker type, as reported. https://www.asiae.co.kr/en/article/2022110213205472723
- Unmarried shares by age, Statistics Korea as reported. https://en.thairath.co.th/news/foreign/2902401
- UN DESA presentation (Meejung Chin), 96.1% of births within marriage, 2022. https://social.desa.un.org/sites/default/files/Presentation%20Meejung%20Chin.pdf
