# What was the post-2015 shock? Twelve experiments

Script: `shock_suite.py` (a few seconds). Results: `results/shock_suite.txt` and `results/shock_suite.json`.

## Results

**X1. Not mainly COVID in Korea, the Philippines and Thailand.** Share of the 2015–24 fall below the development path that came *before* 2020:

| Place | Before 2020 |
|---|---|
| Philippines | 67% |
| Korea | 64% |
| Thailand | 48% |
| Hong Kong | 37% |
| Japan | 27% |
| China | 18% |

In China, Hong Kong and Japan, most of the fall came during or after COVID.

**X2. Break years cluster in East Asia:** Korea 2015, China 2015, Hong Kong 2016, Japan 2018 and Thailand 2013. The Philippines broke earlier, in 2011.

**X3. The breaks do not follow local smartphone adoption.** The correlation between break year and the year adult ownership passed about 50% is −0.46, the wrong sign.
- Korea had smartphones first (~2011) but broke in 2015.
- The Philippines got them last (~2018) but broke first (2011).

So phones as a literal local cause is not supported. The East Asian breaks look like a shared calendar shock. The Philippine fall started earlier and fits its own story: the 2012 Reproductive Health Law, plus a 47% fall in teen births (X9). That is an untested hypothesis.

**X4. Unique in 50 years.** Since 1975, the only nine-year windows in which all six places fell clearly below their path are those starting in 2014 and 2015. Before 2005 the average was about one place per window.

**X5–X6. Economy.**
- Across places, bigger slowdowns did not mean bigger falls (r = +0.02).
- Within places, fertility became tied to the economy after 2015. A point of growth last year moves the gap +0.022 (r = +0.46), against +0.003 (r = +0.13) before.
- Fertility became more sensitive to economic conditions: a sign of choice and pessimism.

**X7. Fewer marriages, or fewer births per marriage?** Births are set against the previous year's marriages:

| Period | Births | Marriages | Births per marriage | Share of fall from fewer marriages |
|---|---|---|---|---|
| Korea 2016→19 (pre-COVID) | ×0.75 | ×0.85 | **×0.88** | 55% |
| Korea 2019→24 | ×0.79 | ×0.75 | ×1.05 | ~all |
| Japan 2016→24 | ×0.70 | ×0.75 | ×0.94 | 82% |
| China 2016→24 (approximate) | ×0.53 | ×0.63 | ×0.85 | 74% |
| Hong Kong 2018→24 | ×0.68 | ×0.93 | ×0.72 | 18% (emigration after 2020 confounds this) |

Korea's shock came in two phases: births per marriage fell before COVID, then marriages collapsed during it.

**X8. Statistics Korea agrees.** Married women's fertility in their late 20s and early 30s peaked in 2015, fell, and has risen since 2022.

**X9. Ages.**
- Korea 2012→2022: under-30 births fell 69–78%, 30–34 fell 40%, and 35+ rose. Mostly postponement.
- Philippines 2017→22: every age fell, most of all teens (−47%).

**X10. China's policy echo is small.** The 2016–17 two-child bump was +0.12. TFR then fell from 1.67 (2015) to 1.01 (2024), so even ignoring the bump China fell 39%.

**X11. What could phones be a proxy for?** Signatures of four proxy mechanisms in the cohort model:

| Proxy | Marriage-bound | Non-marital regime (ratio) | Route |
|---|---|---|---|
| Courtship displacement (meeting −40%) | −9% | −2% (0.26) | Later marriage |
| Social comparison / intensive parenting (child cost ×1.4) | −15% | −13% (0.89) | Second births −0.14 |
| Anxiety and pessimism (intent ×0.8, meeting −15%) | −11% | −10% (0.90) | Second births −0.10 |
| Childfree norm spreads (15%) | −15% | −15% (0.99) | First births only |

## X12. Scorecard

| Candidate | Before COVID | Hits non-marital regimes | Births per marriage fell pre-COVID | Second births hardest | Tracks local phone timing | Tracks economy |
|---|---|---|---|---|---|---|
| COVID | − | + | − | ? | n/a | ? |
| Economic precarity / pessimism | + | + | + | + | n/a | partly |
| Courtship displacement (phone proxy) | + | − | − | − | − | ? |
| **Social comparison, intensive parenting (phone proxy)** | + | + | + | + | − | ? |
| **Anxiety and pessimism (phone proxy)** | + | + | + | + | − | partly |
| Childfree norm diffusion | + | + | + | − | − | ? |
| Microplastics / biology | + | + | + | − | n/a | ? |

## Verdict

1. **The shock is real and unique.** No other window in 50 years has all six places falling below their path.
2. **It has two layers.**
   - From about 2015, a pre-COVID fall *within* marriage, hitting second births most and appearing in all regimes.
   - From 2020, COVID-era marriage postponement, which is partly reversing in 2023–24.
3. **If phones are involved, they are a proxy, not a local cause.** The timing does not follow local adoption.
4. **The proxy that fits is not "less dating."** Courtship displacement would spare places with many births outside marriage, and the Philippines fell 33%.
5. **It fits two things:**
   - **Social comparison and intensive-parenting norms,** which raise the felt cost of each child, especially a second.
   - **Anxiety and pessimism.** Fertility became tied to the economy only after 2015.

   Both spread through shared media rather than local hardware, which would explain the shared calendar.
6. **The Philippines is a separate story** (earlier break, teen births, Reproductive Health Law), to be tested.

**Data that would separate social comparison from pessimism:**
- trends in ideal versus intended family size since 2015;
- second-birth progression by income;
- time use and survey measures of youth mental health.

## Sources

- Korea births and marriages, 2015–19 (Statistics Korea, via a dashboard citing KOSTAT): https://seoulvision2030.pages.dev/dashboards/demographic-tracker/
- Korea births 2023 and 2024: https://www.koreatimes.co.kr/amp/economy/20250827/newborn-numbers-rise-in-2024-for-1st-time-in-9-years
- Korea marriages 2023 and 2024: https://asianews.network/?p=224812
- Korea married women's fertility: https://kathmandupost.com/world/2025/09/07/south-korea-sees-marriages-fall-by-half-births-down-two-thirds-more-foreign-spouses
- Japan births and marriages 2023–24 (MHLW via Nippon.com): https://www.nippon.com/en/japan-data/h02429/
- Japan marriages 2015: https://nbakki.hatenablog.com/entry/Changes_in_the_Number_of_Marriages_in_Japan
- Japan births in 2016 (977,000) are approximate.
- Hong Kong Immigration Department:
  - https://www.immd.gov.hk/publications/a_report_2019/en/appendix11.html
  - https://www.immd.gov.hk/publications/a_report_2021/en/appendix11.html
  - https://www.immd.gov.hk/publications/a_report_2024/en/appendix10.html
- China marriages (Ministry of Civil Affairs): https://govt.chinadaily.com.cn/s/202502/10/WS67b2cfb6498eec7e1f72f746/china-records-6-1m-marriage-registrations-in-2024.html
- China 2015 marriages and births are approximate.
- Smartphone ownership:
  - Pew 2015–17: https://www.pewresearch.org/global/feature/technology-use-in-africa-smartphones/
  - Pew 2016 report: https://www.pewresearch.org/global/2016/02/22/smartphone-ownership-and-internet-usage-continues-to-climb-in-emerging-economies/
