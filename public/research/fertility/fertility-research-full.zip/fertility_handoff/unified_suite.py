"""Unified suite: is low fertility one epidemic with local severity?

U1  Placebo for the relative-gain (women-overtaking) term. Reassign each place's enrolment history to a
    different place, all 719 ways, refit, and see where the real assignment ranks. Also a change-on-change
    test (year-to-year residual change vs year-to-year enrolment change), which strips shared trends.
U2  Synchrony. Do the six places' departures from their development path move together, and has that
    co-movement grown since 2010? When did each place break below its development path, in calendar time
    and in development time (life expectancy)?
U3  Three-layer model. Development (survival) x matching (relative gain) x a contagion layer.
    V1 common channel: a logistic adoption curve with one onset year for everyone, hitting places in
       proportion to their susceptibility (development level). Onset profile 1990-2020.
    V2 spillover: a place's extra shortfall follows the lagged average shortfall of the other places.
    Leave-one-place-out throughout.
U4  Cohort model with the three proposed transmission channels plus kin. From a 1990-like world to a
    2020-like world, switch on one channel at a time: credential race (costlier children), coupling
    recession (fewer meetings), kin dissolution (less grandparent childcare), women overtaking men.
    Which moves completed fertility most, through marriage or through births per married woman, and
    how much does a births-outside-marriage regime blunt each?

numpy/scipy only, fixed seeds. Synthetic mechanisms with fitted or invented parameters; six places is a
tiny sample, so U1-U3 are weak tests by construction. They show what the data can and cannot tell apart.
"""
import bisect
import contextlib
import io
import itertools
import json
import os
import runpy

import numpy as np
from scipy.optimize import minimize

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "results")
LINES, RES = [], {}


def say(s=""):
    print(s, flush=True)
    LINES.append(s)


with contextlib.redirect_stdout(io.StringIO()):
    TD = runpy.run_path(os.path.join(HERE, "timing_depth_test.py"))
TFR, YEARS, PLACES, ZE, LE = TD["TFR"], TD["YEARS"], TD["PLACES"], TD["ZE"], TD["LE"]
SURV = TD["paths"]["M2 survival"]
WIN = YEARS >= 1985

E = json.load(open(os.path.join(HERE, "education_ratio.json")))


def gpi_series(c):
    v = E[c]["values"]
    ys = np.array(sorted(int(y) for y in v))
    vals = np.array([float(v[str(y)]) for y in ys])
    allyears = np.arange(1940, 2025)
    return dict(zip(allyears, np.interp(allyears, ys, vals)))


GPI0 = {c: gpi_series(c) for c in PLACES}
NONMARITAL = {"PHL": 0.58, "KOR": 0.04, "JPN": 0.025, "HKG": 0.08, "CHN": 0.05, "THA": 0.20}

# ---------------------------------------------------------------- matching table (same as creative_suite)
N = 3000


def married_share(d, b, seed=11):
    rng = np.random.default_rng(seed)
    zw = rng.normal(d, 1, N)
    zm = np.sort(rng.normal(0, 1, N)).tolist()
    order = rng.permutation(N)
    matched = 0
    for w in order:
        lo = bisect.bisect_left(zm, zw[w] - b)
        if lo < len(zm):
            k = lo + int(rng.integers(len(zm) - lo))
            zm.pop(k)
            matched += 1
    return matched / N


DG = np.round(np.arange(-1.5, 1.51, 0.1), 2)
BG = np.round(np.arange(0.0, 2.01, 0.1), 2)
TABLE = np.array([[married_share(d, b) for b in BG] for d in DG])


def M(d, b):
    d = np.clip(d, DG[0], DG[-1])
    b = float(np.clip(b, BG[0], BG[-1]))
    j = np.interp(b, BG, np.arange(len(BG)))
    j0 = int(np.floor(j)); j1 = min(j0 + 1, len(BG) - 1); wj = j - j0
    col = TABLE[:, j0] * (1 - wj) + TABLE[:, j1] * wj
    return np.interp(d, DG, col)


def gpath(gser):
    g = np.array([gser[int(y)] for y in YEARS])
    return np.log(g) - np.log(gser[1940])


LOGREL0 = {c: gpath(GPI0[c]) for c in PLACES}


def match_factor(c, k, b, logrel):
    nm = NONMARITAL[c]
    rel = M(k * logrel, b) / M(np.zeros_like(logrel) - 1.0, b)
    return nm + (1 - nm) * rel


def err(p, c):
    return float(np.mean(np.abs(p[WIN] - TFR[c][WIN])))


def fit_kb(places, logrel, starts=((1.5, 0.6), (4.0, 1.5))):
    def L(q):
        k, b = q
        if not (0 <= k <= 6 and 0 <= b <= 2):
            return 1e6
        return np.mean([err(SURV[c] * match_factor(c, k, b, logrel[c]), c) for c in places])
    best = None
    for s in starts:
        r = minimize(L, s, method="Nelder-Mead", options=dict(xatol=1e-3, fatol=1e-4, maxiter=200))
        if best is None or r.fun < best.fun:
            best = r
    return best.fun, best.x


# ================================================================ U1 placebo
say("U1. PLACEBO FOR THE WOMEN-OVERTAKING (RELATIVE GAIN) TERM")
real_v, real_kb = fit_kb(PLACES, LOGREL0)
say(f"  Real assignment, all places, lag 0: error {real_v:.4f} (k {real_kb[0]:.2f}, b {real_kb[1]:.2f})")
dev_only = np.mean([err(SURV[c], c) for c in PLACES])
say(f"  Development only: {dev_only:.4f}")
perm_vals = []
for perm in itertools.permutations(PLACES):
    if perm == tuple(PLACES):
        continue
    lr = {c: LOGREL0[p] for c, p in zip(PLACES, perm)}
    v, _ = fit_kb(PLACES, lr)
    perm_vals.append(v)
perm_vals = np.array(perm_vals)
rank = int(np.sum(perm_vals <= real_v)) + 1
say(f"  Shuffled assignments: {len(perm_vals)}; median error {np.median(perm_vals):.4f}, best {perm_vals.min():.4f}")
say(f"  Real assignment ranks {rank} of {len(perm_vals)+1} (share of shuffles at least as good: {(rank-1)/len(perm_vals):.3f})")

# change-on-change: residual vs development, year-to-year
dr, dg, grp = [], [], []
for c in PLACES:
    r = TFR[c] - SURV[c]
    x = LOGREL0[c]
    m = WIN[1:]
    dr.append(np.diff(r)[m]); dg.append(np.diff(x)[m]); grp.append(np.full(m.sum(), c))
dr, dg = np.concatenate(dr), np.concatenate(dg)
obs_corr = float(np.corrcoef(dr, dg)[0, 1])
rng = np.random.default_rng(3)
null = []
for _ in range(2000):   # shift each place's enrolment-change series by a random circular offset
    parts = []
    off = 0
    for c in PLACES:
        n = int(WIN[1:].sum())
        seg = dg[off:off + n]
        parts.append(np.roll(seg, rng.integers(1, n)))
        off += n
    null.append(np.corrcoef(dr, np.concatenate(parts))[0, 1])
null = np.array(null)
p_two = float(np.mean(np.abs(null) >= abs(obs_corr)))
say(f"  Change-on-change: corr(yearly residual change, yearly enrolment-ratio change) = {obs_corr:+.3f}; "
    f"circular-shift p = {p_two:.3f}. The theory predicts a negative value.")
RES["U1"] = dict(real=real_v, k=real_kb[0], b=real_kb[1], dev_only=dev_only, perm_median=float(np.median(perm_vals)),
                 perm_best=float(perm_vals.min()), rank=rank, n=len(perm_vals) + 1, diff_corr=obs_corr, diff_p=p_two)

# ================================================================ U2 synchrony
say("\nU2. SYNCHRONY: DO THE PLACES' DEPARTURES FROM DEVELOPMENT MOVE TOGETHER?")
R = {c: TFR[c] - SURV[c] for c in PLACES}


def comove(y0, y1, places):
    m = (YEARS[1:] >= y0) & (YEARS[1:] <= y1)
    X = np.array([np.diff(TFR[c])[m] for c in places])
    C = np.corrcoef(X)
    iu = np.triu_indices(len(places), 1)
    ev = np.linalg.eigvalsh(np.cov((X - X.mean(1, keepdims=True)) / X.std(1, keepdims=True)))
    return float(np.mean(C[iu])), float(ev[-1] / ev.sum())


syn = []
for (y0, y1) in [(1975, 1994), (1995, 2009), (2010, 2024)]:
    a, s = comove(y0, y1, PLACES)
    a5, s5 = comove(y0, y1, [c for c in PLACES if c != "PHL"])
    syn.append(dict(window=f"{y0}-{y1}", mean_corr=a, first_factor=s, mean_corr_noPHL=a5, first_factor_noPHL=s5))
    say(f"  {y0}-{y1}: mean pairwise corr of yearly TFR changes {a:+.2f} (first common factor {s:.0%}); "
        f"without PHL {a5:+.2f} ({s5:.0%})")
# slope of residual 2015-2024
say("  Gap below development path, 2015 vs 2024 (TFR minus development prediction):")
brk = []
for c in PLACES:
    r = R[c]
    i15, i24 = list(YEARS).index(2015), list(YEARS).index(2024)
    # break: first year residual <= -0.15 and stays <= -0.15 for the next 4 years
    by = None
    for i in range(len(YEARS) - 4):
        if YEARS[i] >= 1975 and np.all(r[i:i + 5] <= -0.15):
            by = int(YEARS[i]); break
    le = float(LE[c][list(YEARS).index(by)]) if by else None
    brk.append(dict(place=c, gap2015=float(r[i15]), gap2024=float(r[i24]), break_year=by, le_at_break=le))
    say(f"    {c}: {r[i15]:+.2f} -> {r[i24]:+.2f}; first sustained break below path: "
        f"{by if by else 'none'}{'' if not by else f' (life expectancy {le:.1f})'}")
RES["U2"] = dict(synchrony=syn, breaks=brk)

# ================================================================ U3 three-layer model
say("\nU3. THREE-LAYER MODEL: DEVELOPMENT x MATCHING x CONTAGION (leave one place out)")


def suscept(c, a, z0):
    return 1 / (1 + np.exp(-a * (ZE[c] - z0)))


def adopt(onset, s):
    return 1 / (1 + np.exp(-s * (YEARS - onset - 4)))     # half-way ~4 years after onset


def pred_v1(c, q, onset):
    k, b, dl, a, z0, s = q
    return SURV[c] * match_factor(c, k, b, LOGREL0[c]) * (1 - dl * adopt(onset, s) * suscept(c, a, z0))


def pred_v2(c, q, lag=2):
    k, b, beta = q
    base = SURV[c] * match_factor(c, k, b, LOGREL0[c])
    others = np.mean([np.minimum(R[o], 0) for o in PLACES if o != c], axis=0)   # observed shortfall elsewhere
    sh = np.concatenate([np.zeros(lag), others[:-lag]])
    return base * np.exp(beta * sh)


def fit_v1(places, onset):
    def L(q):
        k, b, dl, a, z0, s = q
        if not (0 <= k <= 6 and 0 <= b <= 2 and 0 <= dl <= 0.8 and 0 <= a <= 6 and -3 <= z0 <= 3 and 0.1 <= s <= 3):
            return 1e6
        return np.mean([err(pred_v1(c, q, onset), c) for c in places])
    best = None
    for s0 in [(real_kb[0], real_kb[1], 0.2, 2.0, 0.5, 0.6), (2.0, 1.0, 0.4, 1.0, 1.0, 1.0)]:
        r = minimize(L, s0, method="Nelder-Mead", options=dict(xatol=1e-3, fatol=1e-5, maxiter=1500))
        if best is None or r.fun < best.fun:
            best = r
    return best.fun, best.x


def fit_v2(places):
    def L(q):
        k, b, beta = q
        if not (0 <= k <= 6 and 0 <= b <= 2 and 0 <= beta <= 3):
            return 1e6
        return np.mean([err(pred_v2(c, q), c) for c in places])
    best = None
    for s0 in [(real_kb[0], real_kb[1], 0.3), (2.0, 1.0, 1.0)]:
        r = minimize(L, s0, method="Nelder-Mead", options=dict(maxiter=800))
        if best is None or r.fun < best.fun:
            best = r
    return best.fun, best.x


prof = []
for onset in range(1990, 2021, 5):
    v, q = fit_v1(PLACES, onset)
    prof.append(dict(onset=onset, err=round(v, 4), depth=round(q[2], 3)))
say("  Common-channel onset profile (all places): " + "  ".join(f"{p['onset']}:{p['err']:.3f}" for p in prof))
best_on = min(prof, key=lambda p: p["err"])["onset"]
say(f"  Best onset {best_on}. For comparison, matching only (all places) {real_v:.3f}, development only {dev_only:.3f}")

rows = []
for c in PLACES:
    tr = [x for x in PLACES if x != c]
    _, kb = fit_kb(tr, LOGREL0)
    e_match = err(SURV[c] * match_factor(c, kb[0], kb[1], LOGREL0[c]), c)
    # V1: onset chosen on training places only
    cand = [(fit_v1(tr, on), on) for on in (2000, 2005, 2010, 2015)]
    (v1, q1), on1 = min(cand, key=lambda t: t[0][0])
    e1 = err(pred_v1(c, q1, on1), c)
    v2, q2 = fit_v2(tr)
    e2 = err(pred_v2(c, q2), c)
    p1 = pred_v1(c, q1, on1)
    rows.append(dict(place=c, dev=err(SURV[c], c), match=e_match, v1=e1, v1_onset=on1, v1_depth=q1[2],
                     v2=e2, v2_beta=q2[2], pred2024_v1=float(p1[-1]), obs2024=float(TFR[c][-1])))
    say(f"  {c}: development {rows[-1]['dev']:.3f} | +matching {e_match:.3f} | +common channel {e1:.3f} "
        f"(onset {on1}, depth {q1[2]:.2f}) | +spillover {e2:.3f} (beta {q2[2]:.2f}) | 2024 V1 {p1[-1]:.2f} vs {TFR[c][-1]:.2f}")
mean = {k: float(np.mean([r[k] for r in rows])) for k in ("dev", "match", "v1", "v2")}
say(f"  Mean held-out error: development {mean['dev']:.3f}, +matching {mean['match']:.3f}, "
    f"+common channel {mean['v1']:.3f}, +spillover {mean['v2']:.3f}")
RES["U3"] = dict(onset_profile=prof, loco=rows, mean=mean)

# ================================================================ U4 channels in a cohort model
say("\nU4. WHICH CHANNEL MOVES COMPLETED FERTILITY? (synthetic cohort, 1990-like -> 2020-like)")
AGES = range(18, 46)


def fecund(age):
    return np.clip((45 - age) / 10, 0, 1) if age >= 35 else 1.0


def cohort(gap=0.0, band=0.55, meet=0.25, cost=1.0, kin=0.6, nonmarital=0.0, n=8000, seed=7):
    """gap: women's status lead (SD). meet: yearly chance of a search attempt (coupling).
    cost: relative cost of a child (credential race); kin: share with grandparent childcare.
    Birth hazards are divided by an effective cost = cost * (1 - 0.5 * kin_i)."""
    rng = np.random.default_rng(seed)
    zm = rng.normal(0, 1, n); zw = rng.normal(gap, 1, n)
    m_entry = 21 + 2 * (zm > 0.1); w_entry = 20 + 2 * (zw > 0.1) + 1.0 * (cost - 1)   # costlier race -> later finish
    has_kin = rng.random(n) < kin
    eff = cost * (1 - 0.5 * has_kin) / (1 - 0.5 * 0.6)                                 # 1.0 at baseline
    m_free = np.ones(n, bool); w_mar = np.zeros(n, bool); parity = np.zeros(n, int)
    for age in AGES:
        elig = np.flatnonzero(m_free & (age >= m_entry)); o = np.argsort(zm[elig])
        pz = list(zm[elig][o]); pid = list(elig[o])
        women = np.flatnonzero((~w_mar) & (age >= w_entry) & (rng.random(n) < meet)); rng.shuffle(women)
        for w in women:
            lo = bisect.bisect_left(pz, zw[w] - band)
            if lo < len(pz):
                k = lo + int(rng.integers(len(pz) - lo)); m = pid.pop(k); pz.pop(k); m_free[m] = False; w_mar[w] = True
        base = np.select([parity == 0, parity == 1, parity == 2], [0.45, 0.22, 0.06], 0.01)
        hz = base / np.where(parity == 0, eff ** 0.5, eff) * fecund(age)
        born = (w_mar & (rng.random(n) < hz)) | ((~w_mar) & (age >= 24) & (rng.random(n) < hz * nonmarital))
        parity += born
    cf = float(parity.mean()); em = float(w_mar.mean())
    per_married = float(parity[w_mar].mean()) if w_mar.any() else 0.0
    return cf, em, per_married


B90 = dict(gap=0.0, meet=0.25, cost=1.0, kin=0.6)
B20 = dict(gap=0.8, meet=0.15, cost=1.8, kin=0.25)
names = {"gap": "Women overtake men (gap 0 -> 0.8 SD)", "meet": "Coupling recession (meetings -40%)",
         "cost": "Credential race (child cost x1.8, later finish)", "kin": "Kin dissolution (grandparent care 60% -> 25%)"}
u4 = {}
for regime, nmv in [("marriage-bound (East Asia)", 0.0), ("births outside marriage common", 0.45)]:
    cf0, em0, pm0 = cohort(**B90, nonmarital=nmv)
    cf1, em1, pm1 = cohort(**B20, nonmarital=nmv)
    say(f"  [{regime}] 1990-like: CF {cf0:.2f}, ever married {em0:.2f}, per married {pm0:.2f} | "
        f"2020-like: CF {cf1:.2f}, ever married {em1:.2f}, per married {pm1:.2f} (fall {cf0-cf1:.2f})")
    rr = []
    for key in ("gap", "meet", "cost", "kin"):
        on = dict(B90); on[key] = B20[key]
        cfa, ema, pma = cohort(**on, nonmarital=nmv)            # switch this one on alone
        off = dict(B20); off[key] = B90[key]
        cfb, emb, pmb = cohort(**off, nonmarital=nmv)           # switch this one off from the full 2020 world
        rr.append(dict(channel=names[key], alone=cf0 - cfa, removed_gain=cfb - cf1, em_alone=ema, pm_alone=pma))
        say(f"    {names[key]:48s} alone -{cf0-cfa:.2f} (ever married {ema:.2f}, per married {pma:.2f}); "
            f"undoing it in 2020 world +{cfb-cf1:.2f}")
    u4[regime] = dict(cf1990=cf0, cf2020=cf1, em1990=em0, em2020=em1, pm1990=pm0, pm2020=pm1, channels=rr)
RES["U4"] = u4

with open(os.path.join(OUT, "unified_suite.txt"), "w") as f:
    f.write("\n".join(LINES) + "\n")
json.dump(RES, open(os.path.join(OUT, "unified_suite.json"), "w"), indent=1, default=float)
