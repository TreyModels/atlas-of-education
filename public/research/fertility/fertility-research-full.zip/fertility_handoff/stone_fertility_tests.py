"""Reproduce demographic accounting from PIDS Table 1 and OECD Table 2.3/Fig 2.5."""
from itertools import permutations

import numpy as np
from openpyxl import load_workbook

# PIDS Table 1. Age-specific rates, births per 100 women per year.
# 'Ever married' includes marriage-like unions. Early never-married
# rates were assumed zero by the source. All numbers are rounded.
ph = {
    1973: ([89.1,50.2,21.5,11.6,8.0,7.3,6.7],
           [37.6,46.2,40.8,32.6,22.1,13.5,2.9], [0]*7),
    2013: ([89.5,57.6,30.9,15.8,10.1,8.2,7.2],
           [39.8,28.9,22.4,15.7,10.1,3.8,.6], [.8,2.3,1.6,2.3,0,0,0]),
    2022: ([94.1,71.0,35.9,18.0,12.9,8.1,8.9],
           [30.3,24.3,16.8,12.7,6.2,2.4,.2], [.5,.5,1.2,1.0,.4,.1,0]),
}

def age_components(never_share, ever_rate, never_rate):
    share = np.asarray(never_share)/100
    return (1-share)*np.asarray(ever_rate)*.05, share*np.asarray(never_rate)*.05

def total(never_share, ever_rate, never_rate):
    return np.sum(age_components(never_share, ever_rate, never_rate))

def shapley(f, old, new):
    changes = np.zeros(len(old))
    orders = list(permutations(range(len(old))))
    for order in orders:
        inputs = list(old)
        before = f(*inputs)
        for j in order:
            inputs[j] = new[j]
            after = f(*inputs)
            changes[j] += after-before
            before = after
    return changes/len(orders)

for start, end in [(1973,2013), (2013,2022), (1973,2022)]:
    old, new = ph[start], ph[end]
    print("PHL", start, end, "TFR", round(total(*old),3), round(total(*new),3),
          "union history / ever-union rates / never-union rates",
          np.round(shapley(total,old,new),3),
          "freeze union history",round(total(old[0],*new[1:]),3),
          "freeze birth rates",round(total(new[0],*old[1:]),3))
    for year in [start,end]:
        print("  actual contributions",year,[round(p.sum(),3) for p in age_components(*ph[year])])

# OECD Table 2.3, Woo and Jang progression estimates. Sum products through order 7.
# These are synthetic period progression schedules, rather than measured completed cohorts.
kor = {
    "1965–1983": [.966,.932,.614,.493,.412,.356,.314],
    "1984–1997": [.920,.711,.128,.095,.080,.071,.065],
    "1998–2014": [.866,.543,.111,.081,.065,.056,.049],
}
def births(first, second, higher):
    return np.cumprod([first,second,*higher]).sum()

def group(p):
    return p[0],p[1],p[2:]

for (start,old),(end,new) in zip(list(kor.items())[:-1],list(kor.items())[1:]):
    old,new = group(old),group(new)
    print("KOR parity",start,end,"synthetic family size",round(births(*old),3),
          round(births(*new),3),"first / second / higher",np.round(shapley(births,old,new),3))

# Statistics Korea age rates underlying OECD Figure 2.5.
with open('stone_stat_jm4h0u','rb') as source:
    book=load_workbook(source, read_only=True, data_only=True)
    years={}
    for row in book['Fig_2_5'].values:
        if row[0]=='15-19':
            years={2002:[],2012:[],2022:[]}
        if years and isinstance(row[0],str) and row[0][:2].isdigit():
            for year,rate in zip(years,row[1:4]):
                years[year].append(rate*.005)
    for start,end in [(2002,2012),(2012,2022)]:
        change=np.array(years[end])-np.array(years[start])
        print("KOR age",start,end,"TFR",round(sum(years[start]),3),round(sum(years[end]),3),
              "under 30 / 30–34 / 35+",np.round([sum(change[:3]),change[3],sum(change[4:])],3))
