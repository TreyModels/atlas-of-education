# Additional results from inline exploratory runs

These computations were run interactively in the earlier conversation and are recorded here because the original snippets were not all saved as standalone scripts.

## Philippines recent birth rates by age

Using Philippine DHS 2013, 2017, and 2022 published rounded rates per 1,000 women:

- 2013: 57, 148, 146, 127, 84, 37, 7.
- 2017: 47, 131, 135, 114, 75, 29, 2.
- 2022: 25, 84, 105, 95, 58, 21, 2.
- Ages are 15–19, 20–24, 25–29, 30–34, 35–39, 40–44, 45–49.
- In 2017–2022, 48.3% of the summed age-specific decline was under age 25 and 69.2% was under age 30. Multiplying the 143 per 1,000 sum by five gives a 0.715 TFR-point decline from rounded figures.
- Extending the 2013–2017 age-specific slope five additional years to 2022, clipping negative individual rates to zero, overpredicted total fertility by about 0.28. About 0.176 of the miss came from ages 15–24. This is a trend diagnostic, not an estimate of the K–12 effect.
- Pre/post rate changes used non-overlapping survey reference periods but only three survey waves. 2013–17 average annual change in TFR contribution was -0.0338 below 25 and -0.0438 at 30+. 2017–22 values were -0.069 and -0.044 respectively. K–12 exposure within age groups is incomplete. The comparison does not identify a causal effect.

Source: https://ncr.cpd.gov.ph/wp-content/uploads/2024/03/PPD-POA_Final-Copy-2.pdf

## Philippine one-variable hindcasts

Five training observations for 1970, 1980, 1990, 2000, and 2010, plus test years 2013, 2017, and 2019. Each linear model uses its contemporaneous predictor in the test year, so this is conditional hindcasting. Household size was interpolated between census years. Average absolute errors: time 0.161, household size 0.201, female lower-secondary completion 0.507, GDP 1.489, infant mortality 0.662. Female education readings shifted from 71.11% in 2013 to 62.03% in 2017 and 73.35% in 2019, raising comparability concerns. The model contains only five training points and household size is partly determined by children, so these are not independent causal rankings.

## Female-to-male education ratio test

Matched sample of 167 training and 82 test observations across six places, with Japan contributing 7 of 82 test years. Lag-fertility-only MAE 0.168, adding tertiary female/male enrollment ratio 0.275, adding GDP alone 0.167, adding both 0.280. Within-country annual data were irregular and the most recent ratio up to five years old was used. The ratio does not measure education level or the degree of credential competition.

## Life expectancy and unions, purely illustrative

Synthetic age-by-age marriage and partner-survival schedule, not Lyman Stone's model and not calibrated to historical records. Starting scenario: total fertility 2.252. Partner mortality 1% to 0.2% per year holding other inputs fixed: 2.367. More universal and earlier marriage: 2.775. Both: 2.946. Both plus higher assumed marital fertility: 3.311. Across 5,000 hypothetical draws, median simulated increases were 0.069 for survival and 0.411 for changing marriage. The exact article being recalled about Lyman Stone and the baby boom was never located or verified. These arbitrary results cannot be attributed to Stone.

## Fixed versus threshold child-investment experiment

Another hypothetical 50,000-household toy varied a development index and explicitly imposed a threshold in expected education costs at 0.65. At index 0.50, mean children were 1.54 smooth versus 2.51 threshold; at 0.80, 0.87 versus 0.75. The threshold was a model input and cannot be used as evidence that it exists in actual country histories.
