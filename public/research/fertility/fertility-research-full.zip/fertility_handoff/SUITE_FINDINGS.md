# Experimental suite: what explains fertility below the development path?

Run `python experimental_suite.py` (output in `results/experimental_suite.txt` and `.json`). It uses only data already in this package: the six-place TFR, GDP and life-expectancy panel; Korean age-specific rates for 2002, 2012 and 2022 (Statistics Korea via OECD); Philippine DHS age-specific rates for 2013, 2017 and 2022; and OECD Korean synthetic parity progressions. No Human Fertility Database data. It follows `timing_depth_test.py`, which found that life expectancy explains when each place fell to about 1.3–1.5, but not why Korea, China and Thailand went 0.3–0.5 children lower.

## Main results

**1. About half of Korea's gap is postponement (E2).** Korea's mean age at childbearing rose 0.21 years per year from 2012 to 2022 (31.25 to 33.38). The Bongaarts–Feeney adjustment puts the 2022 tempo-adjusted TFR at **0.98**, against the observed 0.77. The survival model expected about 1.07–1.22 in 2024. So roughly 0.2 of Korea's 0.3–0.5 shortfall is births being delayed rather than forgone. The remaining level, about 1.0, is still below the development path.

**2. Korea is later *and* fewer, not either one (E3).** Each mechanism was fitted to the 2022 TFR only, then scored on the 2022 age pattern it never saw:
- Pure quantum (the same proportional fall at every age) misses by 8.8 births per 1,000 women per age group.
- Pure postponement misses by 9.0: it puts far too many births at 35–44.
- A fall concentrated under age 28 cannot produce the 2022 schedule at all.
- Postponement plus quantum fits best (3.7): the schedule shifted about **2.1 years older** and fell about **25%** at every age.

For 2002–2012, when TFR rose slightly, the same two-part account again fits far better (6.6) than any single mechanism (14–22).

**3. The Philippine decline is mostly fewer births at every age (E2, E3).** From 2013 to 2022, the mean age at childbearing rose only 0.5 years, and the tempo-adjusted TFR (2.06) is close to the observed 1.95. The proportional-fall mechanism matches the 2022 age pattern best among the single mechanisms (8.0, against 14.5 for postponement). A barrier concentrated at young ages fits worst (20.1), even though teen births fell from 57 to 25 per 1,000, because births fell at nearly every age. For 2017–2022 alone, postponement edges ahead (5.7 vs 6.3): some delay started recently.

**4. Korea's decline moved from third births to second births, with first births smaller (E4).** In OECD's synthetic period progressions, the drop from 1965–83 to 1984–97 came mostly from third and higher births (−0.74). From 1984–97 to 1998–2014 it came mostly from second births (−0.17), then first births (−0.09).

**5. When the gap opens (E1).** Single-kink break dating was uninformative, but the gap at fixed years is clear:
- **Korea:** the gap opened after the late 1990s (−0.3 to −0.4 by 2005), nearly closed by 2015, and reopened to −0.3 to −0.5 by 2024. It is not one shock.
- **China:** far below the path in 1995 (−0.8, birth-planning era), on the path by 2015, below again by 2024 (−0.35 to −0.46).
- **Thailand:** below the path throughout.
- **Philippines:** above the path until about 2015, then below it by 2024 (−0.33 to −0.36). It caught up fast.
- **Japan:** above the path throughout.

**6. Scenarios to 2035 (E5).** These are not forecasts:
- If Korea's level holds, TFR stays at 0.75.
- If postponement ends by 2030, TFR rises to about 0.98.
- If half the postponement gap recovers, TFR is about 0.86.
- Ten-year momentum would push TFR down to the 0.5 floor.

The observed 2024 rise (0.72 to 0.75) runs against momentum and fits the postponement-ending scenarios, but it is one year.

**7. Diversity.** The single-parameter mechanisms have an effective number of 1.79 independent models. The age data separate them better than the TFR-only models did, which is the point of using new information.

## What this means for the credential hypothesis

Korea's ultra-low fertility has two parts. About 0.2 children is postponement, which should partly reverse when the mean age stops rising. The rest is a roughly 25% fall at every age, with second births the main parity loss in the period data. A hypothesis about credential competition and the cost of investing in each child predicts exactly this: fewer second children and later births, rather than a barrier to starting a family at young ages. The Philippines looks different: a broad fall at all ages, with little postponement, consistent with the contraception and union explanations in the handoff.

## Limits

- **Period rates.** Postponement adjustment assumes the delay applies equally across birth orders. With order-specific rates it would be done order by order.
- **Coarse data.** There are three time points per country, in five-year age groups.
- **Age is not parity.** The "young barrier" and "older stopping" mechanisms are crude stand-ins for first-birth and later-birth barriers.
- **E4 uses OECD's synthetic period progressions,** not completed cohorts.
- **E1 inherits the survival model's limits:** six places, and life expectancy trends with time.
- **Philippine DHS rates refer to the three years before each survey.**
- **China, Thailand and Hong Kong have no age schedules in this package,** so experiments E2–E3 cover only Korea and the Philippines.
