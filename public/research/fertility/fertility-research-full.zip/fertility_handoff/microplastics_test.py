"""'OK, maybe microplastics': what would a biological fecundity shock look like, and does it fit?

B1  Signature test. Add biological mechanisms to the Korean signature simulation (mechanism_signatures.py):
      BIO  couples conceive less often at every age (uniform fecundity loss);
      BIOA fecundity loss that worsens with age (25 -> 40), which bites harder when marriage is late.
    Tune each so completed fertility falls to 1.20, then score on the same five Korean facts (S1-S5).
    Also test each paired with hypergamy, and report how big the fecundity loss must be.
B2  Timing test. Exposure to plastics grows smoothly with cumulative production (roughly exponential since
    1950; approximate figures: about 2 Mt a year in 1950, about 380 Mt a year in 2015). Does a smooth
    exposure curve explain each place's gap below its development path (1985-2024) better than a step in
    2015? Shared effect size, place-specific intercepts; also with a 0-15 year accumulation lag.
B3  Regime test. A biological shock does not care whether births need marriage. Compare the post-2015
    drop with how marriage-bound each place is.

Synthetic; invented parameters for B1; approximate production figures for B2. A fit is not evidence that
microplastics cause anything. The reverse is the test: whether the observed pattern is the kind a
biological shock would produce.
"""
import contextlib, io, json, os, runpy
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "results")
LINES, RES = [], {}


def say(s=""):
    print(s, flush=True); LINES.append(s)


# reuse the signature simulator without re-running its experiments
src = open(os.path.join(HERE, "mechanism_signatures.py")).read()
ns = {"__file__": os.path.join(HERE, "mechanism_signatures.py")}
exec(src.split("\nbase = simulate(")[0], ns)
BASE, simulate, fecund0 = ns["BASE"], ns["simulate"], ns["fecund"]
apply0 = ns["apply"]

# biological mechanisms: scale birth hazards inside simulate via a fecundity multiplier
BIO = {"kind": None, "s": 0.0}


def fecund_bio(age):
    f = fecund0(age)
    if BIO["kind"] == "BIO":
        return f * (1 - BIO["s"])
    if BIO["kind"] == "BIOA":
        ramp = np.clip((age - 25) / 15, 0, 1)
        return f * (1 - BIO["s"] * ramp)
    return f


ns["fecund"] = fecund_bio          # simulate() looks fecund up in its own namespace


def run(kind, s, other=None):
    BIO["kind"], BIO["s"] = kind, s
    p = dict(BASE) if other is None else other
    r = simulate(p)
    BIO["kind"], BIO["s"] = None, 0.0
    return r


def tune(kind, target=1.20, other=None):
    lo, hi = 0.0, 0.99
    if run(kind, hi, other)["cf"] > target:
        return None, None
    for _ in range(16):
        mid = (lo + hi) / 2
        if run(kind, mid, other)["cf"] > target:
            lo = mid
        else:
            hi = mid
    return hi, run(kind, hi, other)


base = simulate(dict(BASE))


def score(r):
    d_total = base["cf"] - r["cf"]
    share = 0.5 * ((base["ever_married"] - r["ever_married"]) * (base["per_married"] + r["per_married"])) / d_total
    shift = r["mean_age_birth"] - base["mean_age_birth"]
    first_drop = base["p_first_married"] - r["p_first_married"]
    second_drop = base["p_second_given_first"] - r["p_second_given_first"]
    edu = r["single35_col"] - r["single35_hs"]
    S = [share >= 0.6, shift >= 1.5, (second_drop >= first_drop) and r["p_first_married"] >= 0.85, edu > 0.02,
         r["men_single_gap_hs_minus_col"] >= 0.05]
    return dict(share_from_marriage=float(share), age_shift=float(shift), p_first_married=float(r["p_first_married"]),
                p2_given_1=float(r["p_second_given_first"]), S=[bool(x) for x in S], score=int(sum(S)))


say("B1. SIGNATURE TEST: CAN A FECUNDITY SHOCK PRODUCE KOREA'S PATTERN?")
say(f"  Baseline: completed fertility {base['cf']:.2f}; married women reaching a first birth {base['p_first_married']:.2f}")
b1 = []
names = {"BIO": "Fecundity loss, all ages", "BIOA": "Fecundity loss rising with age (25->40)"}
for k, nm in names.items():
    s, r = tune(k)
    if r is None:
        say(f"  {nm}: cannot reach 1.20 even at 99% loss"); b1.append(dict(mechanism=nm, reachable=False)); continue
    sc = score(r)
    b1.append(dict(mechanism=nm, strength=s, **sc))
    say(f"  {nm:42s} needs {s:.0%} fewer conceptions{' at 40' if k=='BIOA' else ''} | fall from marriage {sc['share_from_marriage']:.0%} | "
        f"birth age {sc['age_shift']:+.1f}y | married reaching 1st birth {sc['p_first_married']:.2f} | "
        + " ".join(f"S{i+1} {'Y' if v else '-'}" for i, v in enumerate(sc["S"])) + f" = {sc['score']}/5")
# pairs with hypergamy: half the fall each
say("  Paired with hypergamy (each giving about half the fall):")
s_h = None
lo, hi = 0.0, 1.0
for _ in range(16):
    mid = (lo + hi) / 2
    if simulate(apply0("R2", mid))["cf"] > 1.42:
        lo = mid
    else:
        hi = mid
p_h = apply0("R2", hi)
for k, nm in names.items():
    s_half, _ = tune(k, target=1.42)
    r = run(k, s_half, p_h)
    sc = score(r)
    b1.append(dict(mechanism=nm + " + hypergamy", strength=s_half, cf=float(r["cf"]), **sc))
    say(f"    {nm + ' + hypergamy':56s} CF {r['cf']:.2f} | fall from marriage {sc['share_from_marriage']:.0%} | "
        f"birth age {sc['age_shift']:+.1f}y | " + " ".join(f"S{i+1} {'Y' if v else '-'}" for i, v in enumerate(sc["S"])) + f" = {sc['score']}/5")
RES["B1"] = b1

# ================================================================ B2 timing
say("\nB2. TIMING TEST: SMOOTH PLASTICS EXPOSURE vs A 2015 STEP (gap below development path, 1985-2024)")
with contextlib.redirect_stdout(io.StringIO()):
    TD = runpy.run_path(os.path.join(HERE, "timing_depth_test.py"))
TFR, Y, PL, SURV = TD["TFR"], TD["YEARS"], TD["PLACES"], TD["paths"]["M2 survival"]
win = Y >= 1985
G = {c: (TFR[c] - SURV[c])[win] for c in PL}
yy = Y[win]
r_prod = np.log(380 / 2) / (2015 - 1950)          # approximate exponential growth of annual production


def cum_prod(year):
    return (np.exp(r_prod * (year - 1950)) - 1) / r_prod   # cumulative production since 1950, relative units


def fit_shared(X):
    """gap_c(t) = a_c + b * X(t), shared b; returns SSE, b, and leave-one-place-out mean abs error."""
    Xc = {c: X for c in PL}
    def solve(places):
        xd = np.concatenate([Xc[c] - Xc[c].mean() for c in places]); gd = np.concatenate([G[c] - G[c].mean() for c in places])
        return float(xd @ gd / (xd @ xd))
    b = solve(PL)
    sse = sum(float(np.sum((G[c] - G[c].mean() - b * (Xc[c] - Xc[c].mean())) ** 2)) for c in PL)
    loco = []
    for c in PL:
        bb = solve([o for o in PL if o != c])
        # intercept from the held-out place's own 1985-1999 years only, then predict 2000-2024
        early = yy < 2000
        a = float(np.mean(G[c][early] - bb * Xc[c][early]))
        loco.append(float(np.mean(np.abs(G[c][~early] - (a + bb * Xc[c][~early])))))
    return sse, b, float(np.mean(loco))


b2 = []
for lag in (0, 5, 10, 15):
    X = cum_prod(yy - lag); X = X / X.max()
    sse, b, lo = fit_shared(X)
    b2.append(dict(model=f"plastics exposure, lag {lag}y", sse=sse, effect=b, loco=lo))
    say(f"  Plastics exposure (cumulative production), lag {lag:2d}y: SSE {sse:6.2f}; effect {b:+.2f} at today's exposure; held-out 2000-24 error {lo:.3f}")
for step in (2010, 2015, 2016):
    X = (yy >= step).astype(float)
    sse, b, lo = fit_shared(X)
    b2.append(dict(model=f"step in {step}", sse=sse, effect=b, loco=lo))
    say(f"  Step in {step}:                                SSE {sse:6.2f}; effect {b:+.2f}; held-out 2000-24 error {lo:.3f}")
X = (yy - yy.min()) / (yy.max() - yy.min())
sse, b, lo = fit_shared(X)
b2.append(dict(model="straight line in time", sse=sse, effect=b, loco=lo))
say(f"  Straight line in time:                        SSE {sse:6.2f}; effect {b:+.2f}; held-out 2000-24 error {lo:.3f}")
RES["B2"] = b2

# ================================================================ B3 regime
say("\nB3. REGIME TEST: DOES THE POST-2015 DROP DEPEND ON HOW MARRIAGE-BOUND BIRTHS ARE?")
NONMARITAL = {"PHL": 0.58, "KOR": 0.04, "JPN": 0.025, "HKG": 0.08, "CHN": 0.05, "THA": 0.20}
i15, i24 = list(Y).index(2015), list(Y).index(2024)
rows = []
for c in PL:
    g15, g24 = TFR[c][i15] - SURV[c][i15], TFR[c][i24] - SURV[c][i24]
    rel = (TFR[c][i24] - TFR[c][i15]) / TFR[c][i15]
    rows.append(dict(place=c, nonmarital=NONMARITAL[c], gap_change=float(g24 - g15), tfr_change_pct=float(rel)))
    say(f"  {c}: births outside marriage {NONMARITAL[c]:.0%}; gap change {g24-g15:+.2f}; TFR change 2015-24 {rel:+.0%}")
nm = np.array([r["nonmarital"] for r in rows]); pc = np.array([r["tfr_change_pct"] for r in rows])
say(f"  Correlation of births-outside-marriage share with the % fall: {np.corrcoef(nm, pc)[0,1]:+.2f} (n = 6). "
    f"Range of % falls: {pc.min():+.0%} to {pc.max():+.0%}")
RES["B3"] = rows

with open(os.path.join(OUT, "microplastics_test.txt"), "w") as f:
    f.write("\n".join(LINES) + "\n")
json.dump(RES, open(os.path.join(OUT, "microplastics_test.json"), "w"), indent=1, default=float)
