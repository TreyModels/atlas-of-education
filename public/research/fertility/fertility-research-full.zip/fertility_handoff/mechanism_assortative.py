"""Assortative mating plus rising competition: can it alone produce Korea's pattern?

Trey's question: what if there is just assortative mating combined with increased competition,
with everyone more competitive both in themselves and in whom they choose?

Each person has a status score (education, income, prospects). One "competition" strength s moves
three things together:
  - pickier choice: a couple can only form if their status scores are within a band, and the band
    narrows as s rises (two-sided assortative mating);
  - more self-investment: everyone spends longer in school and credentials before entering the market
    (up to 3 extra years at s = 1);
  - the same stable-job requirement as the other models (unchanged by s).
Variant B adds the measured change in who has status: women's status distribution rises relative to
men's (women's education overtaking men's), so the narrowing band pinches high-status women and
low-status men.

The strength is tuned so completed fertility falls 1.64 -> 1.20, then scored on the same five Korean facts
as mechanism_signatures.py (S1 fall mainly through marriage; S2 births at least 1.5 years later; S3 married
women still reach a first birth, the per-family fall is in second births; S4 higher-status women more often
single; S5 lower-status men more often single). Synthetic, invented parameters; deterministic; numpy only.
"""
import bisect
import json
import os

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "results")
N = 12000
AGES = range(18, 46)
BASE = dict(job=0.40, marry=0.20, h1=0.50, h2=0.07, h3=0.01)


def fecund(age):
    return np.clip((45 - age) / 10, 0, 1) if age >= 35 else 1.0


def simulate(s, women_rise=0.0, seed=7):
    rng = np.random.default_rng(seed)
    zm = rng.normal(0, 1, N)
    zw = rng.normal(women_rise * s, 1, N)
    tol = 2.6 * (1 - s) + 0.12
    delay = 3.0 * s
    m_entry = 20 + delay + 2.0 * (zm > 0.1)        # higher status = more schooling before entry
    w_entry = 19 + delay + 2.0 * (zw > 0.1)
    m_job = np.zeros(N, bool)
    m_married = np.zeros(N, bool)
    w_married = np.zeros(N, bool)
    parity = np.zeros(N, int)
    birth_ages = []
    for age in AGES:
        seek = (~m_job) & (age >= m_entry)
        m_job |= seek & (rng.random(N) < BASE["job"])
        elig = np.flatnonzero((~m_married) & m_job & (age >= m_entry))
        order = np.argsort(zm[elig])
        pool_z = list(zm[elig][order])
        pool_id = list(elig[order])
        women = np.flatnonzero((~w_married) & (age >= w_entry) & (rng.random(N) < BASE["marry"]))
        rng.shuffle(women)
        for w in women:
            lo = bisect.bisect_left(pool_z, zw[w] - tol)
            hi = bisect.bisect_right(pool_z, zw[w] + tol)
            if hi > lo:
                k = lo + int(rng.integers(hi - lo))
                m = pool_id.pop(k)
                pool_z.pop(k)
                m_married[m] = True
                w_married[w] = True
        hz = np.select([parity == 0, parity == 1], [BASE["h1"], BASE["h2"]], BASE["h3"]) * fecund(age)
        born = w_married & (rng.random(N) < hz)
        birth_ages.extend([age] * int(born.sum()))
        parity += born
    ever = w_married
    top_w, top_m = zw > np.median(zw), zm > np.median(zm)
    return dict(cf=float(parity.mean()), ever_married=float(ever.mean()),
                per_married=float(parity[ever].mean()) if ever.any() else 0.0,
                mean_age_birth=float(np.mean(birth_ages)) if birth_ages else float("nan"),
                p_first_married=float((parity[ever] >= 1).mean()) if ever.any() else 0.0,
                p2_given_1=float((parity >= 2).sum() / max(1, (parity >= 1).sum())),
                women_single_gap_top_minus_bottom=float((1 - ever[top_w].mean()) - (1 - ever[~top_w].mean())),
                men_single_gap_bottom_minus_top=float((1 - m_married[~top_m].mean()) - (1 - m_married[top_m].mean())))


def tune(women_rise, target=1.20):
    lo, hi = 0.0, 1.0
    if simulate(hi, women_rise)["cf"] > target:
        return None, None
    for _ in range(14):
        mid = (lo + hi) / 2
        if simulate(mid, women_rise)["cf"] > target:
            lo = mid
        else:
            hi = mid
    return hi, simulate(hi, women_rise)


def score(base, r):
    d = base["cf"] - r["cf"]
    share = 0.5 * (base["ever_married"] - r["ever_married"]) * (base["per_married"] + r["per_married"]) / d
    shift = r["mean_age_birth"] - base["mean_age_birth"]
    first_drop = base["p_first_married"] - r["p_first_married"]
    second_drop = base["p2_given_1"] - r["p2_given_1"]
    S = [share >= 0.6, shift >= 1.5, (second_drop >= first_drop) and r["p_first_married"] >= 0.85,
         r["women_single_gap_top_minus_bottom"] > 0.02, r["men_single_gap_bottom_minus_top"] >= 0.05]
    return share, shift, [bool(x) for x in S]


lines = []
say = lambda x="": (print(x), lines.append(x))
base = simulate(0.0)
say(f"BASELINE (wide partner band, no extra schooling): completed fertility {base['cf']:.2f}, ever married "
    f"{base['ever_married']:.2f}, mean age at birth {base['mean_age_birth']:.1f}, P(2nd|1st) {base['p2_given_1']:.2f}")
res = {}
for label, rise in [("A  assortative mating + rising competition (same status distribution for both sexes)", 0.0),
                    ("B  as A, plus women's status rising past men's (women's education overtaking)", 0.6)]:
    s, r = tune(rise)
    if r is None:
        say(f"\n{label}\n   cannot lower completed fertility to 1.20")
        continue
    share, shift, S = score(base, r)
    res[label[:1]] = dict(strength=round(s, 3), partner_band_sd=round(2.6 * (1 - s) + 0.12, 2),
                          extra_schooling_years=round(3 * s, 2), result=r, share_from_marriage=round(share, 2),
                          birth_age_shift=round(shift, 2), S=S, score=sum(S))
    say(f"\n{label}")
    say(f"   strength {s:.2f}: partner band +/-{2.6*(1-s)+0.12:.2f} SD, {3*s:.1f} extra years of schooling")
    say(f"   completed fertility {r['cf']:.2f}; fall from marriage {share:.0%}; birth age {shift:+.1f}y; "
        f"first birth among married {r['p_first_married']:.2f}; P(2nd|1st) {r['p2_given_1']:.2f}")
    say(f"   single gap, top- minus bottom-status women {r['women_single_gap_top_minus_bottom']:+.2f}; "
        f"bottom- minus top-status men {r['men_single_gap_bottom_minus_top']:+.2f}")
    say("   " + " ".join(f"S{i+1} {'Y' if v else '-'}" for i, v in enumerate(S)) + f"  = {sum(S)}/5")

# how much does each half of "competition" matter? pickier choice only vs self-investment only (variant B)
say("\nDecomposing variant B's competition into its two parts (strength fixed at B's tuned value):")
sB = res.get("B", {}).get("strength")
if sB is not None:
    def run(tol_on, delay_on):
        rng_s = sB
        # re-run with one part switched off by editing the formulas through a local copy
        global simulate
        return None
    # pickier choice only
    def sim_parts(s, pick, invest, women_rise=0.6, seed=7):
        rng = np.random.default_rng(seed)
        zm = rng.normal(0, 1, N); zw = rng.normal(women_rise * s, 1, N)
        tol = 2.6 * (1 - s) + 0.12 if pick else 2.72
        delay = 3.0 * s if invest else 0.0
        m_entry = 20 + delay + 2.0 * (zm > 0.1); w_entry = 19 + delay + 2.0 * (zw > 0.1)
        m_job = np.zeros(N, bool); m_married = np.zeros(N, bool); w_married = np.zeros(N, bool)
        parity = np.zeros(N, int); ages = []
        for age in AGES:
            seek = (~m_job) & (age >= m_entry); m_job |= seek & (rng.random(N) < BASE["job"])
            elig = np.flatnonzero((~m_married) & m_job & (age >= m_entry)); o = np.argsort(zm[elig])
            pz = list(zm[elig][o]); pid = list(elig[o])
            women = np.flatnonzero((~w_married) & (age >= w_entry) & (rng.random(N) < BASE["marry"])); rng.shuffle(women)
            for w in women:
                lo = bisect.bisect_left(pz, zw[w] - tol); hi = bisect.bisect_right(pz, zw[w] + tol)
                if hi > lo:
                    k = lo + int(rng.integers(hi - lo)); m = pid.pop(k); pz.pop(k); m_married[m] = True; w_married[w] = True
            hz = np.select([parity == 0, parity == 1], [BASE["h1"], BASE["h2"]], BASE["h3"]) * fecund(age)
            born = w_married & (rng.random(N) < hz); ages.extend([age] * int(born.sum())); parity += born
        return float(parity.mean()), float(w_married.mean()), float(np.mean(ages))
    for nm, pk, iv in [("pickier choice only", True, False), ("more self-investment only", False, True), ("both", True, True)]:
        cf, em, ma = sim_parts(sB, pk, iv)
        say(f"   {nm:28s} completed fertility {cf:.2f}, ever married {em:.2f}, mean age at birth {ma:.1f}")

with open(os.path.join(OUT, "mechanism_assortative.txt"), "w") as f:
    f.write("\n".join(lines) + "\n")
json.dump(dict(baseline=base, variants=res), open(os.path.join(OUT, "mechanism_assortative.json"), "w"), indent=1, default=float)
