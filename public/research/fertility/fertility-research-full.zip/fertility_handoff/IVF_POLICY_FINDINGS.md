# IVF, a Korea decomposition and policy levers

Script: `ivf_policy_suite.py` (about 25 seconds). Results: `results/ivf_policy_suite.txt` and `results/ivf_policy_suite.json`.
It builds on the Habbema-calibrated clock in `fecundity_age_model.py`.

## I1–I2. IVF, calibrated and checked against Korea

- **Calibration.** IVF is calibrated to Habbema et al.'s thresholds with IVF: a 90% chance of 1 child if trying starts by 35, 2 by 31 and 3 by 28. The model gives 89%, 91% and 91%.
- **Assumptions.** Couples start IVF after 12 months of trying (6 from age 35), with up to 4 cycles per child. The fitted live-birth chance is 0.20 per cycle under 35 and falls with age.
- **Validation.** Applied to Korea's 2024 marriage schedule, the model reproduces Korea's observed share of births from infertility treatment, 15.1% in 2024, when about **71% of couples who struggle use treatment**. That is plausible given heavy subsidies. The 15.1% also includes artificial insemination.

## I3. IVF gives back only a sixth of the clock's cost

| | 1995 marriage schedule | 2024 schedule | Clock cost |
|---|---|---|---|
| No IVF | 1.82 | 1.61 | 0.21 |
| Korea's uptake (~71%) | 1.88 | 1.70 | 0.18 |
| Full uptake | 1.91 | 1.74 | 0.17 |

IVF recovers about 16% of the cost at Korea's current uptake, and about 22% at full uptake. It moves the cliff a few years later; it does not remove it.

## I4. Korea 2000 → 2024, decomposed in completed-family terms

**Method.**
- TFR is tempo-adjusted by dividing by 0.8. The mean age at first birth rose about 0.2 years a year in both periods, so the adjustment cancels in the ratio.
- Ever married: 98% in 2000 (women in their 40s). For 2024 there are two scenarios: 88% (women in their 40s in 2020) and 75% (a projection for today's young cohorts).
- Intentions are solved for as the residual.

| Share of the fall | 88% ever married | 75% ever married |
|---|---|---|
| Fewer marriages | 16% | 39% |
| Clock (net of IVF) | 9% | 9% |
| Fewer children wanted or chosen within marriage (residual) | 75% | 51% |
| Implied mean children sought per married couple | 2.09 → 1.21 | 2.09 → 1.44 |

**Caution.** This disagrees with the published *period* decompositions (Choi 2022; KIHASA), which find marriage was the main driver up to 2015 and that marital fertility even rose.
- The difference is partly bookkeeping. A period view counts delayed marriage as "marriage"; a completed-family view counts it as timing.
- The residual is a catch-all, and it is very sensitive to how many of today's young Koreans will ever marry. The data that would settle it are births per married woman by marriage duration, 2015–2024.
- **A reading that fits both:** before 2015 the fall ran through marriage. After 2015 the common shock, which hit all six places whatever their marriage regime (`MICROPLASTICS_FINDINGS.md`, B3), cut births within marriage.

## I5. Policy levers (2024 Korea, 75% ever married)

Baseline: 0.94 completed children per woman (tempo-adjusted).

| Lever | Result | Change |
|---|---|---|
| Ever married +10 points | 1.06 | +0.12 |
| Second-birth support (+0.2 in children sought) | 1.06 | +0.13 |
| Marriage 2 years earlier (31.6 → 29.6) | 0.98 | +0.04 |
| Full IVF uptake | 0.96 | +0.02 |
| Earlier marriage + more marriage | 1.11 | +0.17 |
| All four | 1.29 | +0.35 |

- Getting more people married, and supporting second births, each do about three times as much as moving marriage two years earlier.
- Moving marriage earlier mostly matters past the early 30s, where the cliff is.
- More IVF adds little.
- Even all four together leave Korea far below replacement.

## Sources

- Korea infertility-treatment births, 15.1% in 2024 (HIRA via Korea Herald/ANN): https://asianews.network/?p=251244
- Korea never-married shares (Statistics Korea): https://cm.asiae.co.kr/en/article/2024121911115449527
- Korea never-married shares, 30–34 year olds (Statistics Korea): https://www.asiae.co.kr/en/article/2023112709413596145
- Habbema et al. (2015): https://pure.eur.nl/en/publications/realizing-a-desired-family-size-when-should-couples-start/
