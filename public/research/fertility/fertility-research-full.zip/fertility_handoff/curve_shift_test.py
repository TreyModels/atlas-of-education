"""Fernandez-Villaverde check on our six places: fit TFR on income, and separately on life expectancy, using
1961-1985 only; then ask how far later fertility falls below each frozen curve. If income stopped tracking
'modernity' after 1985 while survival kept tracking it, the income curve should shift down much more."""
import contextlib, io, os, runpy
import numpy as np
from scipy.optimize import least_squares
HERE = os.path.dirname(os.path.abspath(__file__))
with contextlib.redirect_stdout(io.StringIO()):
    TD = runpy.run_path(os.path.join(HERE, "timing_depth_test.py"))
TFR, Y, PL, ZG, ZE, curve = TD["TFR"], TD["YEARS"], TD["PLACES"], TD["ZG"], TD["ZE"], TD["curve"]
early = Y <= 1985
def fit(Z):
    res = lambda p: np.concatenate([curve(Z[c][early], *p) - TFR[c][early] for c in PL])
    return least_squares(res, [1.0, 6.5, 2.0, 0.0], bounds=([0, 3, .05, -4], [3, 9, 20, 4])).x
out = []
for name, Z in (("income", ZG), ("survival", ZE)):
    p = fit(Z)
    e = np.mean(np.abs(np.concatenate([curve(Z[c][early], *p) - TFR[c][early] for c in PL])))
    print(f"{name}: 1961-85 fit error {e:.3f}; floor {p[0]:.2f}")
    for a, b in ((1986, 1995), (1996, 2005), (2006, 2015), (2016, 2024)):
        m = (Y >= a) & (Y <= b)
        r = {c: float(np.mean(TFR[c][m] - curve(Z[c][m], *p))) for c in PL}
        print(f"   {a}-{b}: mean gap below frozen curve {np.mean(list(r.values())):+.2f}  " + " ".join(f"{c} {v:+.2f}" for c, v in r.items()))
# decomposition 1985->2022: movement along the frozen 1961-85 income curve vs shift
i85, i22 = list(Y).index(1985), list(Y).index(2022)
p = fit(ZG)
along = np.mean([curve(ZG[c][i22], *p) - curve(ZG[c][i85], *p) for c in PL])
total = np.mean([TFR[c][i22] - TFR[c][i85] for c in PL])
print(f"1985->2022 mean TFR change {total:+.2f}: along frozen income curve {along:+.2f} ({along/total:.0%}), shift {total-along:+.2f} ({(total-along)/total:.0%})")
p = fit(ZE)
along = np.mean([curve(ZE[c][i22], *p) - curve(ZE[c][i85], *p) for c in PL])
print(f"   same with survival curve: along {along:+.2f} ({along/total:.0%}), shift {total-along:+.2f} ({(total-along)/total:.0%})")
