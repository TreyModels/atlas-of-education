"""Late marriage x biological clock, all six places. Uses the Habbema-calibrated reproductive model from
fecundity_age_model.py (parameters read from results/fecundity_age_model.json, not refitted).

Women's age at first marriage or union, early -> late (sources in FECUNDITY_COUNTRIES_FINDINGS.md):
  KOR mean 25.3 (1995) -> 31.6 (2024)          JPN mean 26.3 (1995) -> 29.6 (2019)
  HKG median 26.2 (1991) -> 31.0 (2024)        CHN mean 23.3 (2000) -> 28.0 (2020)
  PHL median first union 21.6 (1993) -> 22.8 (2022, includes cohabitation)
  THA SMAM 23.5 (1990) -> about 24.8 (2024)  ESTIMATE: the 1990 value plus the 1.3-year rise in mean age
                                                 at childbearing; no recent Thai marriage age was found.
Every couple wants two children and starts trying one year after marrying; spread of marriage ages 3.5 years.
The biological cost is applied to the early TFR with marriage rates held fixed, then compared with the
observed TFR change over the same years (our World Bank panel).
"""
import contextlib, io, json, os, runpy
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__))
src = open(os.path.join(HERE, "fecundity_age_model.py")).read()
ns = {"__file__": os.path.join(HERE, "fecundity_age_model.py")}
exec(src.split('\nTARGETS = ')[0], ns)
simulate = ns["simulate"]
P = tuple(json.load(open(os.path.join(HERE, "results", "fecundity_age_model.json")))["A1"]["params"])
with contextlib.redirect_stdout(io.StringIO()):
    TD = runpy.run_path(os.path.join(HERE, "timing_depth_test.py"))
TFR, Y = TD["TFR"], list(TD["YEARS"])
M = {"KOR": (1995, 25.3, 2024, 31.6), "JPN": (1995, 26.3, 2019, 29.6), "HKG": (1991, 26.2, 2024, 31.0),
     "CHN": (2000, 23.3, 2020, 28.0), "THA": (1990, 23.5, 2024, 24.8), "PHL": (1993, 21.6, 2022, 22.8)}
LINES, rows = [], []
def say(s=""):
    print(s, flush=True); LINES.append(s)
say("LATE MARRIAGE x BIOLOGICAL CLOCK, SIX PLACES (couples want two; marriage rates held fixed)")
for c, (y0, a0, y1, a1) in M.items():
    k0 = simulate(a0 + 1, 2, P, n=40000, start_sd=3.5, seed=3)
    k1 = simulate(a1 + 1, 2, P, n=40000, start_sd=3.5, seed=3)
    share = (k0.mean() - k1.mean()) / k0.mean()
    t0, t1 = TFR[c][Y.index(y0)], TFR[c][Y.index(y1)]
    implied = t0 * (1 - share)
    expl = (t0 - implied) / (t0 - t1) if t0 > t1 else float("nan")
    rows.append(dict(place=c, years=[y0, y1], marriage_age=[a0, a1], per_married=[float(k0.mean()), float(k1.mean())],
                     childless=[float(np.mean(k0 == 0)), float(np.mean(k1 == 0))], clock_cut=float(share),
                     tfr=[float(t0), float(t1)], tfr_if_only_clock=float(implied), share_of_fall_explained=float(expl)))
    say(f"  {c}: marriage {a0} ({y0}) -> {a1} ({y1}) | children per married woman {k0.mean():.2f} -> {k1.mean():.2f} "
        f"(clock cut {share:.0%}); involuntarily childless {np.mean(k0==0):.0%} -> {np.mean(k1==0):.0%} | "
        f"TFR {t0:.2f} -> {t1:.2f}; clock alone -> {implied:.2f}; explains {expl:.0%} of the fall")
x = np.array([r["marriage_age"][1] - r["marriage_age"][0] for r in rows]); yv = np.array([r["clock_cut"] for r in rows])
say(f"  Rise in marriage age vs clock cut: correlation {np.corrcoef(x, yv)[0,1]:+.2f}; cut per extra year of delay "
    f"about {np.polyfit(x, yv, 1)[0]*100:.1f} percentage points")
open(os.path.join(HERE, "results", "fecundity_countries.txt"), "w").write("\n".join(LINES) + "\n")
json.dump(rows, open(os.path.join(HERE, "results", "fecundity_countries.json"), "w"), indent=1)
