# Kate's model

Scripts: `kate_model.py` and `kate_sensitivity.py`. Results: `results/kate_model.txt`, `results/kate_model.json` and `results/kate_sensitivity.txt`.

## Her account, formalised

**Root cause: education expansion.** Women's tertiary share rises from 10% to 55%, and men's from 12% to 50%. That is roughly China's change from 2000 to 2020 (approximate). The expansion works through four channels:

| Channel | Kate's words | Model ("then" → "now") |
|---|---|---|
| K1 Career start | 毕业22岁，找工作花费好几年 (graduate at 22, then years finding work) | Tertiary graduates spend 1 → 3 years establishing work before seeking a partner |
| K2 Partner standard | 更期待另一半也有事业 (expects her partner to have a career too) | Men need an established job; tertiary women accept only tertiary-educated men with a job |
| K3 Diet and stress | 饮食的问题，事业的压力 (diet, career stress) | Monthly conception chance ×0.85 (assumed) |
| K4 More choices | 选择性更多，不以家庭为主 (more choices, family not the centre) | Tertiary women seek 1.5 children instead of 2; 10% choose not to marry |

Births within marriage come from the Habbema-calibrated reproductive clock.

## Results

| World | Marriage age | Ever married | Completed fertility |
|---|---|---|---|
| Then (2000-like) | 23.3 | 100% | 1.84 |
| Education expands, no channel | 24.6 | 100% | 1.83 |
| Now, all four channels | 26.0 | 91% | 1.43 (−22%) |

- In the "now" world, the people never married at 45 are **tertiary women (16%) and non-tertiary men (17%)**. Other women and tertiary men are almost all married. That is the urban "剩女" (left-over women) and rural "剩男" (left-over men) pattern, and it comes from channel K2 alone.
- Education expansion by itself does almost nothing. It matters only through the channels.

**Shapley split of the channel effect (−0.40):**

| Channel | Effect | Share |
|---|---|---|
| K4 More choices | −0.27 | 68% |
| K2 Partner standard | −0.11 | 27% |
| K1 Career start | −0.01 | 3% (but +1.1 years of marriage age, the biggest timing effect) |
| K3 Diet and stress | −0.01 | 2% |

## Sensitivity

**Diet and stress.** This is a couple wanting two:

| Conception chance | Marrying at 28 | Marrying at 31.6 |
|---|---|---|
| ×1.00 | 1.80 | 1.69 |
| ×0.85 | 1.79 | 1.66 |
| ×0.70 | 1.77 | 1.62 |
| ×0.50 | 1.72 | 1.54 |

Even halving fertility costs little, because couples who marry at 28 have years to try. It bites only when marriage is very late.

**Career start.** Each extra two years of establishing work adds about a year to the average marriage age. Fertility falls only once marriage moves past about 30: completed fertility is 1.65 with 3 years and 1.58 with 7 years.

## Against China, 2000 → 2020

| | Observed | Model |
|---|---|---|
| Women's marriage age | 23.3 → 28.0 (+4.7) | 23.3 → 26.0 (+2.7) |
| Fertility | TFR 1.63 → 1.24 (−24%; the 2000 figure was held down by the one-child policy) | Completed fertility −22% |

The model gets the size of the fertility fall but only about 60% of the delay in marriage. Something else also pushes marriage later. Candidates are housing costs and a stricter partner standard than the one modelled.

## Verdict

1. **Kate's account works,** and the pieces line up with the Atlas results:
   - K2 is the credential floor plus hypergamy, the pair that matched all five Korean facts.
   - K1 plus the clock is late marriage.
   - K4 is the within-marriage and ideation channel.
2. **The partner standard does the most distinctive work.** It is the only channel that produces the 剩女/剩男 split.
3. **"More choices" is the largest channel, but its size is set by assumption.** The model assumes educated women seek 1.5 children. Survey data on desired family size by education would test it.
4. **Diet and stress are unlikely to matter much on their own.** Late marriage is what turns any biological weakness into lost births.
5. **Caveats:** the parameters are illustrative, not fitted, and the one-child policy is not modelled.
