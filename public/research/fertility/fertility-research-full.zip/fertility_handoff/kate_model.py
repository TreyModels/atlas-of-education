"""Kate's model of falling birth rates, formalised.

Her account (paraphrased): women's education keeps rising, so women graduate around 22 and may then spend
several years finding and establishing work; the typical marriage age rises. Educated women pursue career
success and expect their partner to have a career too, so their values change. Diet and career stress may
affect fertility. Women have more choices and no longer centre their lives on family.

Root cause: education expansion (women's tertiary share 10% -> 55%; men's 12% -> 50%; roughly China's
2000 -> 2020 change, approximate). Four channels, each switched from a 'then' to a 'now' setting:
  K1 Career start      tertiary graduates spend 1 -> 3 years establishing work before seeking a partner
  K2 Partner standard  then: anyone acceptable; now: men need an established job, and a tertiary woman
                       accepts only a tertiary-educated man with a job
  K3 Diet and stress   monthly conception chance x1.00 -> x0.85 (assumed; human evidence is weak)
  K4 More choices      tertiary women: children sought 2 -> 1.5, and 10% choose not to marry
Births inside marriage come from the Habbema-calibrated monthly reproductive model
(fecundity_age_model.py): age at marriage, children sought and fecundity set how many children a couple has.

Outputs: mean age at marriage, ever married by 45, completed fertility, never-married at 45 by education,
and a Shapley split of the fall across Kate's four channels. Synthetic; parameters are illustrative, not
fitted. China's one-child policy, which capped births in 2000, is not modelled.
"""
import bisect, itertools, json, os
from math import factorial
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "results")
LINES, RES = [], {}


def say(s=""):
    print(s, flush=True); LINES.append(s)


src = open(os.path.join(HERE, "fecundity_age_model.py")).read()
ns = {"__file__": os.path.join(HERE, "fecundity_age_model.py")}
exec(src.split('\nTARGETS = ')[0], ns)
sim_births = ns["simulate"]
P = tuple(json.load(open(os.path.join(OUT, "fecundity_age_model.json")))["A1"]["params"])

# lookup: mean children for a couple marrying at age a (start trying a+1), sought k, fecundity multiplier f
AGES = np.arange(16, 46)
TABLE = {}
for k in (1, 2):
    for f in (1.0, 0.85):
        Pf = (P[0] * f,) + P[1:]
        TABLE[(k, f)] = np.array([sim_births(a + 1.0, k, Pf, n=3000, seed=11).mean() for a in AGES])


def births(age, sought, f):
    lo = np.floor(sought); hi = lo + 1; w = sought - lo
    v = np.interp(age, AGES, TABLE[(int(lo), f)])
    if w > 0:
        v = (1 - w) * v + w * np.interp(age, AGES, TABLE[(int(hi), f)])
    return v


def cohort(edu_w, edu_m, K1, K2, K3, K4, n=6000, seed=5):
    rng = np.random.default_rng(seed)
    wt = rng.random(n) < edu_w; mt = rng.random(n) < edu_m
    est = 3.0 if K1 else 1.0
    w_seek = np.where(wt, 22 + est, 19 + 1.0) + rng.normal(0, 1.0, n)
    m_done = np.where(mt, 23 + (est if K1 else 1.0), 20 + 1.0) + rng.normal(0, 1.0, n)
    optout = K4 & wt & (rng.random(n) < 0.10)
    m_job = np.zeros(n, bool); m_free = np.ones(n, bool)
    w_mar_age = np.full(n, np.nan)
    for age in range(18, 46):
        if K2:
            m_job |= (age >= m_done) & (rng.random(n) < 0.35)
        else:
            m_job |= (age >= m_done)
        elig = np.flatnonzero(m_free & m_job)
        pool_t = list(elig[mt[elig]]); pool_n = list(elig[~mt[elig]])
        rng.shuffle(pool_t); rng.shuffle(pool_n)
        women = np.flatnonzero(np.isnan(w_mar_age) & ~optout & (age >= w_seek) & (rng.random(n) < 0.30))
        rng.shuffle(women)
        for w in women:
            if K2 and wt[w]:
                pools = [pool_t]
            else:
                tot = len(pool_t) + len(pool_n)
                pools = [pool_t, pool_n] if tot and rng.random() < len(pool_t) / tot else [pool_n, pool_t]
            for pool in pools:
                if pool:
                    m = pool.pop(); m_free[m] = False; w_mar_age[w] = age; break
    married = ~np.isnan(w_mar_age)
    sought = np.where(wt & K4, 1.5, 2.0)
    f = 0.85 if K3 else 1.0
    kids = np.zeros(n)
    kids[married] = [births(a, s, f) for a, s in zip(w_mar_age[married], sought[married])]
    return dict(cf=float(kids.mean()), ever_married=float(married.mean()),
                mean_marriage_age=float(np.nanmean(w_mar_age)),
                per_married=float(kids[married].mean()),
                single_w_tertiary=float(1 - married[wt].mean()) if wt.any() else float("nan"),
                single_w_other=float(1 - married[~wt].mean()),
                single_m_other=float(1 - (~m_free)[~mt].mean()), single_m_tertiary=float(1 - (~m_free)[mt].mean()))


THEN = (0.10, 0.12); NOW = (0.55, 0.50)
say("KATE'S MODEL: EDUCATION EXPANSION AND FOUR CHANNELS (synthetic cohort, illustrative parameters)")
base = cohort(*THEN, False, False, False, False)
say(f"  'Then' world (2000-like): marriage age {base['mean_marriage_age']:.1f}; ever married {base['ever_married']:.0%}; "
    f"completed fertility {base['cf']:.2f}")
edu_only = cohort(*NOW, False, False, False, False)
say(f"  Education expands, no channel switched on: marriage age {edu_only['mean_marriage_age']:.1f}; "
    f"ever married {edu_only['ever_married']:.0%}; CF {edu_only['cf']:.2f}")
full = cohort(*NOW, True, True, True, True)
say(f"  'Now' world, all four channels: marriage age {full['mean_marriage_age']:.1f}; ever married {full['ever_married']:.0%}; "
    f"CF {full['cf']:.2f}; per married {full['per_married']:.2f}")
say(f"    Never married at 45: tertiary women {full['single_w_tertiary']:.0%}, other women {full['single_w_other']:.0%}; "
    f"non-tertiary men {full['single_m_other']:.0%}, tertiary men {full['single_m_tertiary']:.0%}")
RES.update(then=base, education_only=edu_only, now_all=full)

names = ["K1 career start", "K2 partner standard", "K3 diet and stress", "K4 more choices"]
say("\n  Each channel alone (education expanded):")
alone = {}
for i, nm in enumerate(names):
    flags = [False] * 4; flags[i] = True
    r = cohort(*NOW, *flags)
    alone[nm] = r
    say(f"    {nm:20s} marriage age {r['mean_marriage_age']:.1f}; ever married {r['ever_married']:.0%}; CF {r['cf']:.2f} "
        f"({r['cf']-edu_only['cf']:+.2f} vs education only)")
RES["alone"] = alone

# Shapley split of the fall in completed fertility (education_only -> all four) across the channels
vals = {}
for combo in itertools.product([False, True], repeat=4):
    vals[combo] = cohort(*NOW, *combo)["cf"]
    vals[combo]
shap = np.zeros(4); shap_age = np.zeros(4); vals_age = {}
for combo in itertools.product([False, True], repeat=4):
    vals_age[combo] = cohort(*NOW, *combo)["mean_marriage_age"]
for i in range(4):
    for combo in itertools.product([False, True], repeat=4):
        if combo[i]:
            continue
        s = sum(combo); w = factorial(s) * factorial(4 - s - 1) / factorial(4)
        withi = list(combo); withi[i] = True
        shap[i] += w * (vals[tuple(withi)] - vals[combo])
        shap_age[i] += w * (vals_age[tuple(withi)] - vals_age[combo])
total = vals[(True,) * 4] - vals[(False,) * 4]
say(f"\n  Shapley split of the fall in completed fertility from the channels ({total:+.2f}; education expansion itself "
    f"{edu_only['cf']-base['cf']:+.2f} on top):")
for nm, v, va in zip(names, shap, shap_age):
    say(f"    {nm:20s} {v:+.2f} ({v/total:.0%} of the channel effect); marriage age {va:+.1f} years")
RES["shapley"] = {nm: dict(cf=float(v), share=float(v / total), marriage_age=float(va)) for nm, v, va in zip(names, shap, shap_age)}
RES["shapley_total"] = float(total)

# comparison with China's observed changes 2000 -> 2020
say("\n  China, observed 2000 -> 2020: women's mean age at first marriage 23.3 -> 28.0 (+4.7); TFR 1.63 -> 1.24 in "
    "our panel (-24%), with the 2000 figure held down by the one-child policy.")
say(f"  Model then -> now: marriage age {base['mean_marriage_age']:.1f} -> {full['mean_marriage_age']:.1f} "
    f"({full['mean_marriage_age']-base['mean_marriage_age']:+.1f}); completed fertility {base['cf']:.2f} -> {full['cf']:.2f} "
    f"({(full['cf']-base['cf'])/base['cf']:+.0%})")

with open(os.path.join(OUT, "kate_model.txt"), "w") as f:
    f.write("\n".join(LINES) + "\n")
json.dump(RES, open(os.path.join(OUT, "kate_model.json"), "w"), indent=1, default=float)
