# Kate's model, round 2, and a tipping test on real data

Scripts: `kate_round2.py` and `momentum_test.py`. Results: `results/kate_round2.txt`, `results/kate_round2.json`, `results/momentum_test.txt` and `results/momentum_test.json`.

## R1. "More choices", calibrated to surveys

- In the 2017 National Fertility Survey, Chinese women intended 1.76 children on average, and 1.70 among those born in the 1990s.
- In CGSS Liaoning, college-educated residents' ideal number of children was *higher* than average: 1.81 against 1.71.
- So educated women do not clearly want fewer children. The assumed 1.5 in round 1 was too strong.
- With survey intentions, Kate's channels give a fall of **−13%** in completed fertility, not −22%.
- "More choices" works mainly through *when and whether* women marry, not through wanting fewer children.

## R2. What closes the marriage-age gap?

China's women's marriage age rose by 4.7 years. Kate's channels alone give +2.7.

| Added mechanism | Marriage age | Completed fertility |
|---|---|---|
| Kate's channels only | +2.7 | −13% |
| Housing: men need 2 years of savings | +3.7 | −15% |
| Housing: 4 years | +5.7 | −17% |
| Stricter partner standard | +3.2 | −14% |
| Slower job queue for men | +4.1 | −18% |
| Housing 2 years + slower job queue | +5.2 | −19% |
| Housing 2 years + career start 5 years | **+4.8** | −16% |

- Housing and men's job prospects close the gap. A stricter partner standard alone does not.
- The "leftover" pattern stays the same in every variant: about 15% of tertiary women and 17% of non-tertiary men never marry.

## R3. The gap between what women intend and what they get

Women intend 1.70 children. The modelled "now" world delivers 1.39 completed. The 0.31 gap breaks down as:
- infertility and miscarriage even with early marriage: 0.14;
- never marrying: 0.13;
- marrying later (the clock): 0.04.

China's period TFR was 1.79 in 2017, 1.24 in 2020 and **1.01 in 2024**. That is far below 1.39, and the rest of the gap is:
- postponement, which depresses period rates (tempo);
- the post-2015 fall in intentions and births within marriage, which none of Kate's channels contains.

## M. A tipping test on the real series

The test fits ΔTFR(t) = ρ·ΔTFR(t−1) + κ·(development path − TFR)(t−1).

| Place | Momentum ρ | Pull-back κ |
|---|---|---|
| Thailand | +0.65 (se 0.09) | −0.006 |
| Philippines | +0.60 (se 0.15) | +0.006 |
| Korea | +0.21 (se 0.14) | +0.04 (ns) |
| Hong Kong | +0.15 | **+0.13** (se 0.07) |
| China | +0.15 | +0.007 |
| Japan | +0.14 | **+0.11** (se 0.06) |

- **The momentum test does not support the tipping story as simply stated.** The strongest momentum is in Thailand and the Philippines, which are mid-transition with smooth, steady falls. That is trend persistence, not a cliff.
- **Pull-back fits the "bend and recover" pattern.** Japan and Hong Kong are pulled back toward their development path, so after overshooting they partly recover. Japan rose from 1.26 to 1.45 between 2005 and 2015. Korea and China show no measurable pull-back, consistent with no recovery.

**Out of sample** (fit on 1985–2014, predict 2015–2024), mean error:
- with momentum: 0.19;
- without momentum: 0.21;
- no change: 0.32.

**Nothing in pre-2015 dynamics predicted the depth after 2015:**

| Place | Predicted 2024 | Actual 2024 |
|---|---|---|
| Korea | 0.99 | 0.75 |
| Hong Kong | 1.09 | 0.84 |
| China | 1.86 | 1.01 |

This is more evidence that the post-2015 drop is a new shock, not momentum from the past. The model also overshoots the Philippines (1.08 predicted against 1.89 actual), because it carries the earlier momentum forward.

## Sources

- 2017 National Fertility Survey (Zhuang, Jiang & Li 2021): https://rkyj.ruc.edu.cn/CN/abstract/abstract3675.shtml
- CGSS Liaoning: https://doaj.org/article/77dc6bfe05ef48ac94f656cf750f3605
