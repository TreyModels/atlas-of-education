"""Timing and depth test: do development mechanisms explain WHEN fertility fell, and how far?

Five-year forecasts reward momentum (persistence beats every mechanism model in this archive).
That is the wrong test for a mechanism. The question here is explanatory: given only a place's
own income and survival path, can a model fitted on the OTHER five places reproduce the year that
place crossed TFR 2.1, 1.5 and 1.3, and how low it went?

Data: World Bank via FRED (asia_panel_data.json, life_asia.json), period TFR 1960-2024, GDP per
capita in constant dollars, life expectancy at birth. Hong Kong has no infant-mortality series in the
extract, so survival is life expectancy. Period TFR, not completed cohort fertility.

Models (each simulates a whole 1961-2024 path; fitted ones are refitted leaving the target place out):
  M0  calendar       the average TFR of the other five places in the same year (no own information)
  M1  income         TFR as a falling logistic curve in log GDP per capita
  M2  survival       TFR as a falling logistic curve in life expectancy
  M3  income+surv    logistic curve in a weighted index of the two
  M4  income-lag     partial adjustment: each year TFR moves a share lambda toward the M1 curve
  M5  survival-lag   partial adjustment toward the M2 curve
M4 and M5 start from the place's observed 1961 TFR; M0-M3 use no observed TFR at all.

Crossing year = first year TFR is below the threshold and stays below for the rest of the series
(sustained crossing). Deterministic; numpy/scipy only; no network.
"""
import json
import os

import numpy as np
from scipy.optimize import least_squares

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "results")
os.makedirs(OUT, exist_ok=True)
PLACES = ["PHL", "THA", "KOR", "JPN", "HKG", "CHN"]
YEARS = np.arange(1961, 2025)
THRESH = [2.1, 1.5, 1.3]

P = json.load(open(os.path.join(HERE, "asia_panel_data.json")))
L = json.load(open(os.path.join(HERE, "life_asia.json")))


def series(d):
    v = d["values"] if "values" in d else d
    return np.array([float(v[str(y)]) for y in YEARS])


TFR = {c: series(P[f"tfr_{c}"]) for c in PLACES}
LGDP = {c: np.log(series(P[f"gdp_{c}"])) for c in PLACES}
LE = {c: series(L[c]) for c in PLACES}
# standardise drivers on the pooled 1961-2024 distribution (fixed, not refitted per fold)
allg, alle = np.concatenate(list(LGDP.values())), np.concatenate(list(LE.values()))
ZG = {c: (LGDP[c] - allg.mean()) / allg.std() for c in PLACES}
ZE = {c: (LE[c] - alle.mean()) / alle.std() for c in PLACES}


def curve(x, lo, hi, k, x0):
    return lo + (hi - lo) / (1 + np.exp(np.clip(k * (x - x0), -50, 50)))


def driver(c, kind, w=None):
    if kind == "g":
        return ZG[c]
    if kind == "e":
        return ZE[c]
    return w * ZG[c] + (1 - w) * ZE[c]


def fit_static(train, kind):
    def res(p):
        lo, hi, k, x0 = p[:4]
        w = 1 / (1 + np.exp(-p[4])) if kind == "ge" else None
        return np.concatenate([curve(driver(c, kind, w), lo, hi, k, x0) - TFR[c] for c in train])
    p0 = [1.0, 6.5, 2.0, 0.0] + ([0.0] if kind == "ge" else [])
    lb = [0.0, 3.0, 0.05, -4.0] + ([-10] if kind == "ge" else [])
    ub = [3.0, 9.0, 20.0, 4.0] + ([10] if kind == "ge" else [])
    r = least_squares(res, p0, bounds=(lb, ub))
    return r.x


def sim_static(c, kind, p):
    w = 1 / (1 + np.exp(-p[4])) if kind == "ge" else None
    return curve(driver(c, kind, w), *p[:4])


def sim_lag(c, kind, p):
    lo, hi, k, x0, lam = p
    target = curve(driver(c, kind), lo, hi, k, x0)
    path = np.empty_like(target)
    path[0] = TFR[c][0]
    for t in range(1, len(target)):
        path[t] = path[t - 1] + lam * (target[t] - path[t - 1])
    return path


def fit_lag(train, kind):
    def res(p):
        return np.concatenate([sim_lag(c, kind, p) - TFR[c] for c in train])
    r = least_squares(res, [1.0, 6.5, 2.0, 0.0, 0.2], bounds=([0, 3, 0.05, -4, 0.01], [3, 9, 20, 4, 1]))
    return r.x


def crossing(path, th):
    below = path < th
    if not below[-1]:
        return None
    idx = len(path) - 1
    while idx > 0 and below[idx - 1]:
        idx -= 1
    return int(YEARS[idx])


def loco_paths():
    paths = {m: {} for m in ["M0 calendar", "M1 income", "M2 survival", "M3 income+survival",
                             "M4 income, lagged", "M5 survival, lagged"]}
    params = {}
    for c in PLACES:
        train = [x for x in PLACES if x != c]
        paths["M0 calendar"][c] = np.mean([TFR[x] for x in train], axis=0)
        for name, kind in [("M1 income", "g"), ("M2 survival", "e"), ("M3 income+survival", "ge")]:
            p = fit_static(train, kind)
            paths[name][c] = sim_static(c, kind, p)
            params[(name, c)] = p
        for name, kind in [("M4 income, lagged", "g"), ("M5 survival, lagged", "e")]:
            p = fit_lag(train, kind)
            paths[name][c] = sim_lag(c, kind, p)
            params[(name, c)] = p
    return paths, params


paths, params = loco_paths()

lines = []
say = lambda s="": (print(s), lines.append(s))
say("TIMING AND DEPTH TEST, leave-one-place-out (each place simulated by a model fitted on the other five)")
say("Observed sustained crossing years and 2024 TFR:")
obs_cross = {c: {th: crossing(TFR[c], th) for th in THRESH} for c in PLACES}
for c in PLACES:
    say(f"  {c}: " + ", ".join(f"<{th}: {obs_cross[c][th]}" for th in THRESH) + f"; 2024 TFR {TFR[c][-1]:.2f}; min {TFR[c].min():.2f}")

rows = []
for m, pc in paths.items():
    for c in PLACES:
        path = pc[c]
        r = dict(model=m, place=c, path_mae=float(np.mean(np.abs(path - TFR[c]))),
                 tfr2024_pred=float(path[-1]), tfr2024_obs=float(TFR[c][-1]))
        for th in THRESH:
            pr, ob = crossing(path, th), obs_cross[c][th]
            r[f"cross{th}_pred"] = pr
            r[f"cross{th}_obs"] = ob
            r[f"cross{th}_err"] = (pr - ob) if (pr is not None and ob is not None) else None
        rows.append(r)

say("\nPer model (averaged over the six places):")
say(f"{'model':22s} {'path MAE':>8s} {'2024 err':>8s} | crossing-year error, years (mean |err|; misses = predicted never crosses or crosses when it did not)")
summary = []
for m in paths:
    R = [r for r in rows if r["model"] == m]
    pm = np.mean([r["path_mae"] for r in R])
    e24 = np.mean([abs(r["tfr2024_pred"] - r["tfr2024_obs"]) for r in R])
    parts = []
    s = dict(model=m, path_mae=round(pm, 3), err2024=round(e24, 3))
    for th in THRESH:
        errs = [abs(r[f"cross{th}_err"]) for r in R if r[f"cross{th}_err"] is not None]
        miss = sum(1 for r in R if (r[f"cross{th}_pred"] is None) != (r[f"cross{th}_obs"] is None))
        s[f"cross{th}_mae_years"] = round(float(np.mean(errs)), 1) if errs else None
        s[f"cross{th}_misses"] = miss
        parts.append(f"<{th}: {np.mean(errs):5.1f} ({miss} miss)" if errs else f"<{th}: n/a ({miss} miss)")
    summary.append(s)
    say(f"{m:22s} {pm:8.3f} {e24:8.3f} | " + "   ".join(parts))

say("\nPer place, crossing year below 1.5 (observed vs each model):")
say(f"{'place':5s} {'obs':>5s} " + " ".join(f"{m.split()[0]:>5s}" for m in paths))
for c in PLACES:
    say(f"{c:5s} {str(obs_cross[c][1.5]):>5s} " + " ".join(
        f"{str(next(r['cross1.5_pred'] for r in rows if r['model'] == m and r['place'] == c)):>5s}" for m in paths))

say("\nPer place, 2024 TFR (observed vs each model):")
say(f"{'place':5s} {'obs':>5s} " + " ".join(f"{m.split()[0]:>5s}" for m in paths))
for c in PLACES:
    say(f"{c:5s} {TFR[c][-1]:5.2f} " + " ".join(
        f"{next(r['tfr2024_pred'] for r in rows if r['model'] == m and r['place'] == c):5.2f}" for m in paths))

# diversity of the models' path errors (Page): effective number of independent models
E = np.array([np.concatenate([paths[m][c] - TFR[c] for c in PLACES]) for m in paths])
C = np.corrcoef(E)
lam = np.linalg.eigvalsh(C)
eff = lam.sum() ** 2 / (lam ** 2).sum()
off = C[~np.eye(len(C), dtype=bool)]
say(f"\nDiversity: {len(C)} models, mean error correlation {off.mean():.2f}, effective number of independent models {eff:.2f}")
ens = E.mean(axis=0)
say(f"Equal-weight ensemble path MAE {np.mean(np.abs(ens)):.3f} vs best single "
    f"{min(s['path_mae'] for s in summary):.3f} and median single {np.median([s['path_mae'] for s in summary]):.3f}")

with open(os.path.join(OUT, "timing_depth_test.txt"), "w") as f:
    f.write("\n".join(lines) + "\n")
json.dump(dict(rows=rows, summary=summary, effective_models=round(float(eff), 2)),
          open(os.path.join(OUT, "timing_depth_test.json"), "w"), indent=1, default=str)
