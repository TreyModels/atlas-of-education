# The story so far: why fertility collapsed in East and Southeast Asia

Prepared 11 November 2026. The places covered are the Philippines, Thailand, South Korea, Japan, Hong Kong and China.

Labels:
- **[data]** measured from real series;
- **[sim]** from a simulation, some calibrated to published data;
- **[ruled out]** tested and rejected.

The findings file for each part is in brackets.

## 1. Survival sets the floor

[data] Life expectancy alone predicts each place's fall, held out one place at a time, to about 1.3–1.5 children
(`SUITE_FINDINGS.md`, `timing_depth_test.py`).

[data] Income is the wrong yardstick (Fernández-Villaverde):
- Replacement fertility arrived at incomes 16 times apart ($990–$16,279), but always at a life expectancy of 67.5–74.7.
- The fertility–income curve drifted after 1985. The fertility–survival curve did not (`MODERNITY_FINDINGS.md`).

## 2. Education turns children and marriage into credential contests

This is Trey's Networked Domus and Kate's account.

- **[sim] Credential race.** Costlier children lower fertility about 0.4 in any regime, mostly through second births (`UNIFIED_FINDINGS.md`).
- **[sim] Marriage market jams.** Men need a stable job to marry, and women's education overtakes men's while women will not marry down.
  - In Korea, credential floor plus hypergamy was the only pair to reproduce all five Korean facts (`MECHANISMS_FINDINGS.md`).
  - It produces the "leftover" pattern: educated women and less-educated men unmarried (`KATE_FINDINGS.md`).
- **[sim] Kate's model:**
  - Education works through career start, partner standard, diet/stress and choices.
  - Calibrated to surveys (intended 1.70–1.76; educated women not lower), it explains about half of China's fall.
  - Housing plus a longer career start reproduce China's +4.7-year rise in marriage age (`ROUND_KATE2_MOMENTUM_FINDINGS.md`).
- **[sim] Regime matters.** The jam is large where births need marriage and shrinks about 70% where births outside marriage are common (`UNIFIED_FINDINGS.md`, `PAGE_FINDINGS.md` robustness).

## 3. Late marriage meets the biological clock

[sim, calibrated to Habbema et al. 2015] Every year of delay costs more, steeply after 33–35 (`FECUNDITY_AGE_FINDINGS.md`, `FECUNDITY_COUNTRIES_FINDINGS.md`).

| Place | Share of the fall explained by late marriage |
|---|---|
| Hong Kong | 26% |
| Korea | 21% |
| China | 18% |
| Thailand, Philippines | 1–2% |

[sim, validated against Korea's 15.1% of births from treatment] IVF recovers only about a sixth of the cost (`IVF_POLICY_FINDINGS.md`).

## 4. A shared shock after 2015

[data]
- **Unique.** The only nine-year windows since 1975 in which all six places fell clearly below their development path start in 2014–15.
- **Large.** The fall averaged 0.46 children, or 0.71 against each place's own pre-2015 trend.
- **Unforeseen.** Pre-2015 dynamics missed it: China was predicted at 1.86 for 2024 and came in at 1.01 (`UNIFIED_FINDINGS.md`, `MODERNITY_FINDINGS.md`, `SHOCK_FINDINGS.md`).
- **Not the marriage jam.** The fall was the same whether or not births need marriage (r = +0.01) (`MICROPLASTICS_FINDINGS.md`).

**Two layers** (`SHOCK_FINDINGS.md`):
- **from about 2015, a pre-COVID fall *within* marriage.** In Korea, births per marriage fell 12% from 2016 to 2019, and married women's fertility peaked in 2015. Before 2020 came 64% of Korea's fall and 67% of the Philippines'.
- **from 2020, a COVID-era marriage collapse,** which was most of the fall in China, Hong Kong and Japan and is partly reversing in 2023–24.

**Not the cause:**
- [ruled out] local smartphone adoption: break years run the wrong way, r = −0.46;
- [ruled out] country-to-country spread;
- [ruled out] microplastics or biology as the main cause;
- [ruled out] China's policy echo, which is small.

**Fertility became tied to the economy after 2015** (r = 0.46, against 0.13 before).

**If phones matter, they are a proxy** [sim signatures]:
- for **social comparison and intensive-parenting norms**, which raise the felt cost of each child, especially a second;
- and for **anxiety and pessimism**;
- not for less dating, which would spare non-marital regimes, yet the Philippines fell 33%.

The Philippines may be its own story: an earlier break, a teen-birth fall, and the 2012 Reproductive Health Law (untested).

## 5. Can it bounce back?

- **[sim]** In uniform, peer-driven societies a temporary shock can lock in low fertility, and undoing it costs about 8 times what preventing it would have (`PAGE_FINDINGS.md`).
- **[data]** Japan and Hong Kong show a pull back toward their path, and Japan recovered from 1.26 to 1.45 between 2005 and 2015. Korea and China show none.
- **[data]** The momentum test did not confirm a clean tipping cliff (`ROUND_KATE2_MOMENTUM_FINDINGS.md`).

## What policy can do

[sim] (`CREATIVE_FINDINGS.md`, `IVF_POLICY_FINDINGS.md`)

| Policy | Effect |
|---|---|
| Accepting births outside marriage | +0.37 |
| Second-birth support | +0.13 |
| Ever married +10 points | +0.12 |
| Cash +30% | +0.08 |
| Marriage two years earlier | +0.04 |
| Full IVF | +0.02 |
| Best four combined | +0.35 |

Even the best four combined leave Korea far below replacement.

## Ruled out along the way

- A 15–20 year education lag
- An age-29 trap below 1.3 (Japan is a counterexample)
- National enrolment ratios as evidence for the marriage jam (placebo failed)
- Competition within marriage as Korea's main driver before 2015
- Educated Chinese women wanting fewer children
- Diet and stress as a major factor
- Microplastics as the main cause
- Local phone adoption as the trigger

## The one-paragraph version

Survival brings every society down to about 1.4. Mass education turns children into expensive projects and marriage into a credential match. Where births need marriage, that jams the marriage market and pushes weddings into the 30s, where the biological clock turns delay into permanent loss. That is why East Asia fell furthest. Then, from about 2015, a shared shift in how people feel about having children, not about whether they date, pushed every place lower at once: social comparison, intensive-parenting norms and pessimism, perhaps carried by phones and media. COVID later added a marriage collapse. Money alone cannot reverse this. What helps most is decoupling births from marriage, helping people marry, and supporting second children, ideally before a fall rather than after.

## Data that would settle the open questions

- Census tables of who stays unmarried, by sex and education
- Births per married woman by marriage duration since 2015
- Ideal versus intended family size since 2015
- Second-birth rates by income
- Youth mental-health and time-use surveys
- A global version of Fernández-Villaverde's chart using child survival and girls' schooling instead of income

**No website deployment is authorised by this package.**
