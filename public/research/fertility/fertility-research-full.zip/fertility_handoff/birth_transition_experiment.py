"""Exploratory event timing and birth-order counterfactuals."""
import json
import numpy as np
from scipy.optimize import brentq
from scipy.special import expit, logit, ndtr

panel = json.load(open("asia_panel_data.json"))
for country, candidate in (("KOR", 2015), ("PHL", 2017)):
    rates = panel["tfr_" + country]["values"]
    print(country, {year: rates[str(year)] for year in range(2013, 2025)})
    years = np.arange(2009, 2025)
    actual = np.array([rates[str(year)] for year in years])
    train = years <= 2021
    for break_year in (None, candidate, 2020):
        features = np.column_stack([np.ones(len(years)), years - 2009])
        if break_year is not None:
            features = np.column_stack([features, np.maximum(0, years - break_year)])
        coeff = np.linalg.lstsq(features[train], actual[train], rcond=None)[0]
        print("Timing", country, break_year, "test MAE",
              round(np.abs(features[~train] @ coeff - actual[~train]).mean(), 3),
              "2024", round(features[-1] @ coeff, 3))

# A synthetic population generates annual rates by age and order. A first
# birth requires both willingness and sufficient time. Subsequent births
# follow at fixed intervals with conditional progression probabilities.
ages = np.arange(15, 45)
years = np.arange(1980, 2080)
baseline_progression = np.array([0.715, 0.61, 0.18, 0.10])
baseline_age = 30.5
baseline_spread = 3.6
starting_tfr = 1.239
ending_tfr = 0.721
shock = np.clip((years[:, None] - 2015) / 8, 0, 1)

def rates(progress, age, spread, spacing):
    births = []
    for order in range(4):
        first_age = ages - spacing * order
        mass = ndtr((first_age + 0.5 - age) / spread) - ndtr((first_age - 0.5 - age) / spread)
        births.append((progress[..., :order+1].prod(axis=-1) * mass).sum(axis=-1))
    return np.stack(births, axis=-1)

def scenario(strength, weights, delay, progress, age, spread, spacing):
    progression = expit(logit(progress)[None, None, :] - strength * shock[..., None] * weights)
    # Delay moves the calendar-year birth-age schedule for first births.
    # A cohort receives the schedule faced at each age, including the
    # per-year reduction in intensity while the schedule moves to later ages.
    mean_age = age + delay * strength * shock
    speed = np.diff(mean_age, axis=0, prepend=mean_age[[0]])
    births = rates(progression, mean_age, spread, spacing)
    return births * np.maximum(0, 1 - speed)

scenarios = {
    "first-birth barrier": (np.array([1, 0, 0, 0]), 0),
    "higher later-child costs": (np.array([0, 1, 1.5, 2]), 0),
    "timing delay": (np.zeros(4), 1),
    "combined": (np.array([1, .45, .65, .8]), 0.75),
}
start, end, recovery = [np.flatnonzero(years == year)[0] for year in (2015, 2023, 2033)]

def compare(weights, delay, progress, age, spread, spacing):
    def run(s):
        raw = scenario(s, weights, delay, progress, age, spread, spacing)
        return raw * (starting_tfr / raw[start].sum())
    if run(12)[end].sum() > ending_tfr:
        return None
    strength = brentq(lambda s: run(s)[end].sum() - ending_tfr, 0, 12)
    raw = run(strength)
    share = (raw[start, 0] - raw[end, 0]) / (starting_tfr - ending_tfr)
    return [strength, share, raw[recovery].sum(), delay * strength]

for name, (weights, delay) in scenarios.items():
    print("Signature", name, compare(weights, delay, baseline_progression, baseline_age, baseline_spread, 3))

rng = np.random.default_rng(893)
results = {name: [] for name in scenarios}
for _ in range(400):
    progression = np.clip(baseline_progression + rng.normal(0, [.06, .09, .04, .025]), .025, .95)
    age = rng.uniform(29.5, 31.5)
    spread = rng.uniform(3, 4.2)
    spacing = rng.uniform(2.5, 3.8)
    for name, (weights, delay) in scenarios.items():
        outcome = compare(weights, delay, progression, age, spread, spacing)
        if outcome is not None:
            results[name].append(outcome)
for name, draws in results.items():
    print("Sensitivity", name, len(draws), np.round(np.quantile(draws, [.05, .5, .95], axis=0).T, 3))
