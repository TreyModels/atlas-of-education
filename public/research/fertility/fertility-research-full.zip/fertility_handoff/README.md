# Fertility research handoff

Prepared 10 November 2026. This archive continues an exploratory research conversation with Trey. The objective is to build and test interpretable fertility models for the Philippines, South Korea, Japan, Hong Kong, China, and Thailand, ideally from the 1950s or 1960s through the present with a modest projection. The final atlas section should eventually allow users to vary evidence-based mechanisms. Trey explicitly instructed us not to update or publish the website. No website deployment is authorized by this handoff.

## Start here

1. Read RESULTS_AND_RESEARCH.md for the findings, failures, user's theory, open questions, and source links.
2. Run scripts from this directory, not from the repository root. Captured outputs are in results/.
3. Read each script before interpreting numbers. Several are exploratory illustrations using invented parameters, and some reconstruct published models with unresolved problems.
4. The provided manuscript is reference/Massification_and_Its_Mechanisms.md. It is Trey's working paper with Bjørn Nordtveit. Preserve its authorship, qualifications, and distinction between relational credential floors and positional competition.
5. Reproducibility uses Python 3 with numpy, scipy, scikit-learn, and openpyxl. The original runtime was Python 3.12. Scripts use fixed random seeds. A full rerun may take a few minutes.

Example:
    python stone_fertility_tests.py
    python credential_cohort_tests.py

## Files

- asia_panel_data.json: fertility, constant GDP per capita, and infant mortality series from World Bank via FRED, six economies. Keys contain retrieval reference IDs which are internal search session identifiers. Cite the public URLs given in RESULTS_AND_RESEARCH.md rather than those IDs.
- life_asia.json: World Bank life expectancy via FRED.
- education_ratio.json: female-to-male tertiary enrollment ratio. This is a gender ratio, not the level of female attainment or a direct measure of credential competition. Data are sparse.
- country-results.json: earlier exploratory outputs. Read its description and assumptions before use.
- stone_stat_jm4h0u: OECD Figure 2.5 workbook, intentionally retains original extensionless name because scripts open it in binary mode. Contains Korean age-specific fertility in 2002, 2012, and 2022.
- earlier_ui/: initial and updated fertility-only prototype files extracted from earlier deployment bundles, including their original results. They are historical snapshots, not the full atlas.
- reference/: user's supplied manuscript and publicly accessible research materials that informed the results. Source PDFs remain attributed to their authors.
- results/: rerun output or failure trace for each included script, as captured at packaging time. Inspect failed commands instead of treating these as completed results.
- *_experiment.py, *_tests.py and related Python files: the scripts listed below. Scripts contain embedded assumptions and a few manually transcribed source values.

| Script | Main purpose |
| --- | --- |
| exploratory_tests.py | Early illustrative professional-composition and timing examples |
| hk_japan_explore.py | Hong Kong marriage decomposition, Japan age breakdown, early trend tests |
| fertility_reconstruction.py | Tentative reconstruction of de Silva and Tenreyro equations; unresolved country conventions |
| asia_fertility_test.py | Pooled five-year fertility hindcasts, GDP, mortality, leave-one-country-out |
| fertility_trend_experiments.py | Recursive 2010–2024 country-path trend tests and country bootstrap |
| fertility_mechanism_test.py | Mechanism-forced changes based on GDP and life expectancy, with no autonomous change |
| kin_credential_experiment.py | Smooth versus imposed-threshold simplified household model, country bootstrap |
| birth_transition_experiment.py | Synthetic first-birth, later-birth, timing, and combined scenarios |
| stone_fertility_tests.py | Philippine union-history and Korean parity/age arithmetic |
| credential_cohort_tests.py | Philippine and Korean age-pattern trend diagnostics, Monte Carlo rounding check |

## Integrity and interpretation

All historical exercises use period total fertility rates unless clearly labeled otherwise. Period TFR is sensitive to timing and is not the average completed fertility of a single cohort. A good 2024 endpoint can conceal a poor path. Annual overlapping observations do not provide independent replications. Cross-country correlations, model knockouts, calibration, rounding simulations, and country bootstrap draws do not by themselves establish causal effects.

The threshold model uses GDP per capita as a broad development proxy. Its threshold is imposed, not an observed credential floor, and old-age support, credential pressure, and individualism are not independently identified. The sex enrollment ratio is not female education. The birth-transition toy was tuned to the Korean 2015 and 2023 TFR and is not validated against recent first-birth exposures. The Coale–Trussell Amish estimates are descriptive relative to a natural-fertility benchmark and not a universal model for all Stone's work.

Source extracts, model outputs, and manuscript content are available for research handoff. Citation provenance for each public item appears in RESULTS_AND_RESEARCH.md. The requested transfer does not include the original website archive or deployment bundles, which may contain unrelated information and are not needed to reproduce these experiments.


## Update, 11 November 2026: start with STORY.md

STORY.md tells the whole story so far, labelling what is real data, what is simulation and what was ruled out, and points to the findings file for each part. The findings files, in the order the work was done:

- SUITE_FINDINGS.md
- MECHANISMS_FINDINGS.md
- ASSORTATIVE_FINDINGS.md
- CROSS_COUNTRY_FIT.md
- CREATIVE_FINDINGS.md
- UNIFIED_FINDINGS.md
- PAGE_FINDINGS.md
- MODERNITY_FINDINGS.md
- MICROPLASTICS_FINDINGS.md
- FECUNDITY_AGE_FINDINGS.md
- FECUNDITY_COUNTRIES_FINDINGS.md
- IVF_POLICY_FINDINGS.md
- KATE_FINDINGS.md
- ROUND_KATE2_MOMENTUM_FINDINGS.md
- SHOCK_FINDINGS.md

Each has a matching script, and its output is in results/. RESULTS_AND_RESEARCH.md keeps a running log of every round.
