"""Late marriage x the biological clock.

A monthly reproductive microsimulation: per-cycle conception chance that varies between women and falls
with age; permanent sterility that arrives at an individual age; miscarriage risk that rises with age;
9 months of pregnancy, then a wait before trying again. Couples try until they reach their intended
number of children, or until sterility or age 50.

A1  Calibrate the biology to Habbema et al. (2015, Human Reproduction), natural conception (no IVF):
      90% chance of 1 child if trying starts by 32, 2 children by 27, 3 children by 23;
      about 50% chance of 1 child when starting at 41, and of 3 children when starting at 35.
A2  Korea: women's mean age at first marriage 25.3 (1995) -> 31.6 (2024) (Statistics Korea).
    Married couples who intend two children start trying 1 year after marriage. How many children do
    they end up with under each schedule? How much of Korea's TFR fall can the biological clock explain?
A3  The signature: does the clock cut second births more than first births (Korea's fact S3)?
A4  What if couples intend 2 but start at 33, 35, 37 (later marriage still)?

Calibration targets are from the published model, not from Korean clinical data. Miscarriage risk by
age and the wait between births are approximate. IVF is not modelled, so results are an upper bound on
the biological cost (IVF moves the 90% thresholds about 3-4 years later in Habbema et al.).
"""
import itertools, json, os
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "results")
LINES, RES = [], {}


def say(s=""):
    print(s, flush=True); LINES.append(s)


MISC_AGE = np.array([20, 25, 30, 35, 40, 45, 50])
MISC_P = np.array([0.10, 0.10, 0.12, 0.18, 0.35, 0.60, 0.80])     # approximate pregnancy-loss risk by age
WAIT = 15                                                          # months from conception to trying again after a birth


def simulate(start_age, target, P, n=20000, seed=1, start_sd=0.0):
    """Returns array of children achieved (capped at target) for n couples starting at start_age."""
    p0, a0, r, mu, s, f0 = P
    rng = np.random.default_rng(seed)
    het = rng.gamma(3.0, 1 / 3.0, n)                                # between-couple fecundability spread
    u = np.clip(rng.random(n), 1e-9, 1 - 1e-9)
    ster = mu + s * np.log(u / (1 - u))                             # logistic age at permanent sterility
    ster[rng.random(n) < f0] = 0.0                                  # couples infertile from the start
    start = start_age + (rng.normal(0, start_sd, n) if start_sd else np.zeros(n))
    age = start.copy()
    kids = np.zeros(n, int)
    wait = np.zeros(n)                                              # months until trying resumes
    active = np.ones(n, bool)
    while active.any():
        age += 1 / 12
        wait = np.maximum(wait - 1, 0)
        active &= (age < 50) & (age < ster) & (kids < target)
        trying = active & (wait == 0)
        if not trying.any():
            if not active.any():
                break
            continue
        d = np.where(age <= a0, 1.0, np.exp(-r * (age - a0)))
        pc = np.clip(p0 * het * d, 0, 0.95)
        conceive = trying & (rng.random(n) < pc)
        loss = conceive & (rng.random(n) < np.interp(age, MISC_AGE, MISC_P))
        wait[loss] = 3
        born = conceive & ~loss
        kids += born
        wait[born] = WAIT
    return kids


TARGETS = [((32, 1), 0.90), ((27, 2), 0.90), ((23, 3), 0.90), ((41, 1), 0.50), ((35, 3), 0.50)]


def calib_err(P, n=6000):
    return sum((np.mean(simulate(a, k, P, n=n) >= k) - t) ** 2 for (a, k), t in TARGETS)


say("A1. CALIBRATING THE BIOLOGY TO HABBEMA ET AL. (2015), NATURAL CONCEPTION")
best = None
for p0, a0, r, mu, s, f0 in itertools.product((0.20, 0.25), (27, 30, 33), (0.08, 0.12, 0.18), (39, 41, 43), (2.0, 3.0), (0.0, 0.03, 0.06)):
    e = calib_err((p0, a0, r, mu, s, f0))
    if best is None or e < best[0]:
        best = (e, (p0, a0, r, mu, s, f0))
# local refinement
e0, P = best
for it in range(2):
    for i, step in enumerate((0.02, 1.0, 0.02, 0.5, 0.25, 0.01)):
        for sgn in (-1, 1):
            Q = list(P); Q[i] = Q[i] + sgn * step
            e = calib_err(tuple(Q))
            if e < e0:
                e0, P = e, tuple(Q)
P = tuple(float(x) for x in P)
say(f"  Fitted: base monthly conception chance {P[0]:.2f}, decline starts {P[1]:.0f}, decline rate {P[2]:.2f}/yr, "
    f"median sterility age {P[3]:.1f} (spread {P[4]:.2f}); infertile from the start {P[5]:.0%}")
cal = []
for (a, k), t in TARGETS:
    got = float(np.mean(simulate(a, k, P) >= k))
    cal.append(dict(start=a, children=k, target=t, model=got))
    say(f"  Start at {a}, want {k}: published {t:.0%}, model {got:.0%}")
RES["A1"] = dict(params=P, calibration=cal)

# ================================================================ A2
say("\nA2. KOREA: MARRIAGE AT 25.3 (1995) vs 31.6 (2024); COUPLES INTEND TWO, TRY FROM 1 YEAR AFTER MARRIAGE")
SD = 3.5      # assumed spread of women's first-marriage age (years)
out = {}
for label, m in (("1995", 25.3), ("2024", 31.6)):
    k = simulate(m + 1.0, 2, P, n=40000, start_sd=SD, seed=3)
    out[label] = dict(mean_children=float(k.mean()), childless=float(np.mean(k == 0)), one=float(np.mean(k == 1)),
                      two=float(np.mean(k == 2)), p2_given_1=float(np.mean(k >= 2) / max(np.mean(k >= 1), 1e-9)))
    say(f"  {label} (marriage {m}): children per married woman {k.mean():.2f} of 2 intended; "
        f"involuntarily childless {np.mean(k==0):.1%}; stop at one {np.mean(k==1):.1%}; "
        f"P(2nd | 1st) {out[label]['p2_given_1']:.2f}")
loss = out["1995"]["mean_children"] - out["2024"]["mean_children"]
say(f"  Biological cost of the later marriage: {loss:.2f} children per married woman "
    f"({loss/out['1995']['mean_children']:.0%} of what 1995-age couples achieve)")
# scale to TFR: Korea TFR 1.63 (1995) -> 0.72 (2024) in our panel; ever-married share held fixed here
tfr95, tfr24 = 1.634, 0.72
share = loss / out["1995"]["mean_children"]
say(f"  If nothing else changed, that cuts TFR by {share:.0%}: 1.63 -> {tfr95*(1-share):.2f}. "
    f"Observed 2024: {tfr24}. The clock alone explains {tfr95*share/(tfr95-tfr24):.0%} of the fall.")
RES["A2"] = dict(by_year=out, loss_per_married=loss, share_of_tfr_fall=float(tfr95 * share / (tfr95 - tfr24)))

# ================================================================ A3
say("\nA3. SIGNATURE: DOES THE CLOCK CUT SECOND BIRTHS MORE THAN FIRST?")
f1 = 1 - out["2024"]["childless"]; f1b = 1 - out["1995"]["childless"]
say(f"  Reaching a first birth: {f1b:.2f} -> {f1:.2f} ({f1-f1b:+.2f}); second given first: "
    f"{out['1995']['p2_given_1']:.2f} -> {out['2024']['p2_given_1']:.2f} ({out['2024']['p2_given_1']-out['1995']['p2_given_1']:+.2f})")
say("  Korea (OECD progressions, from MECHANISMS_FINDINGS): first 0.92 -> 0.87 (-0.05); second 0.71 -> 0.54 (-0.17).")
RES["A3"] = dict(first=(f1b, f1), second=(out["1995"]["p2_given_1"], out["2024"]["p2_given_1"]))

# ================================================================ A4
say("\nA4. THE CLIFF: INTENDING TWO, BY AGE TRYING STARTS (no spread)")
a4 = []
for a in (25, 28, 30, 32, 33, 35, 37, 39, 41):
    k = simulate(a, 2, P, n=20000, seed=5)
    a4.append(dict(start=a, mean=float(k.mean()), none=float(np.mean(k == 0)), both=float(np.mean(k == 2))))
    say(f"  Start at {a}: {k.mean():.2f} children; get both {np.mean(k==2):.0%}; none {np.mean(k==0):.0%}")
RES["A4"] = a4

with open(os.path.join(OUT, "fecundity_age_model.txt"), "w") as f:
    f.write("\n".join(LINES) + "\n")
json.dump(RES, open(os.path.join(OUT, "fecundity_age_model.json"), "w"), indent=1, default=float)
