# Page suite: many-model experiments

Script: `page_suite.py` (about 90 seconds). Results: `results/page_suite.txt` and `results/page_suite.json`.

## P1. Many models, one crowd: our models are not diverse

- Eight held-out models: calendar, income, survival, income+survival, two lagged versions, matching and common shock.
- **Diversity prediction theorem:** crowd error 0.453 = average model error 0.644 − diversity 0.191.
- The crowd beats the average model but loses badly to the best single model, survival (0.257).
- **Effective number of models: 1.33 of 8.** The models' errors are highly correlated (mean correlation 0.83).
  They are mostly the same model wearing different clothes, because nearly all of them sit on top of the survival curve.
- **Honest sub-crowd** (models chosen on five places, scored on the sixth): best single model 0.330,
  chosen sub-crowd 0.448, all eight 0.453.
- **Page lesson:** a crowd helps only when its members make *different* mistakes. Adding the weak models
  (calendar, income) adds error, not diversity. To gain from many models, we need ones built on different
  logic and different data: micro data on marriage by education, a cohort model, a model using survey ideals.

## P2. Tipping points: when does a temporary shock leave permanent damage?

This is a threshold (Granovetter) model. People adopt a "small family, no rush to marry" life script once
the social pressure is high enough. Part of that pressure comes from how many peers already have.

| Peer feedback | Spread of thresholds | Development levels where a temporary shock causes a permanent drop | Fastest yearly fall |
|---|---|---|---|
| None (memoryless) | any | none | 0.06–0.42 |
| Moderate | 0.05 (homogeneous) | 0.045 wide | 0.65 |
| Moderate | 0.10 | 0.015 wide | 0.35 |
| Moderate | 0.20+ (diverse) | none | ≤0.12 |
| Strong | 0.05 | 0.045 wide | 0.81 |
| Strong | 0.10 | 0.045 wide | 0.58 |
| Strong | 0.20 | 0.030 wide | 0.26 |
| Strong | 0.35 | none | 0.08 |

- **Traps need two ingredients:** peer feedback and a fairly homogeneous society. Without peer feedback,
  fertility always returns once the shock ends.
- In a diverse society, the same shock produces a gentle slope that reverses.
- In a homogeneous, tightly linked society, it produces a cliff that stays.
- **Data comparison (fastest five-year fall):**
  - China: 0.197/yr from 1987 (policy era)
  - Philippines: 0.151/yr from 2015
  - Hong Kong: 0.087/yr from 2016
  - Korea: 0.080/yr from 2015
  - Thailand: 0.077/yr from 1985
  - Japan: 0.044/yr from 1985

  Four of six places had their fastest recent fall starting in 2015–16, which fits a shock hitting
  feedback-prone societies. Japan's slow, steady fall looks like the no-feedback case.

## P3. Path dependence: prevention is far cheaper than cure

Inside the trap zone, this measures how much counter-pressure policy needs to get back to the no-shock path.
The original shock was 0.05.

| Society | Fertility: before → trapped | Push to prevent (start before shock) | Push to undo (start after shock) |
|---|---|---|---|
| Moderate feedback, spread 0.10 | 1.85 → 1.05 | 0.010 | 0.010 |
| **Strong feedback, spread 0.10** | **1.97 → 0.90** | **0.025** | **0.205 (about 8× more)** |
| Strong feedback, spread 0.20 | 1.84 → 1.05 | 0.015 | 0.025 |

With strong peer feedback, undoing a collapse costs about four times the original shock and eight times
what prevention would have cost. This is Page's point about history-dependent processes: unlike a Markov
process, the past does not wash out. This may explain why big spending in Korea after the fall has barely
moved anything. That is an inference, not tested here.

## P4. Robustness: do the cohort-model conclusions survive 400 random parameter draws?

| Conclusion | Share of draws where it holds |
|---|---|
| Matching squeeze is at least 1.5× larger where births need marriage | 100% |
| Credential race is about the same size in both regimes | 100% |
| Matching squeeze beats the coupling recession and kin loss in a marriage-bound world | 86% |
| Credential race is the biggest channel where births outside marriage are common | 98% |

Median effects (marriage-bound | births outside marriage common):
- matching −0.39 | −0.11
- credential race −0.40 | −0.42
- coupling −0.16 | −0.07
- kin −0.16 | −0.17

**Caveat:** robustness to parameter values is not proof of the model's structure. The first two rows are
close to built in by how the channels were coded. What P4 shows is that the rankings do not hinge on any
lucky parameter choice.

## What this adds to the story

1. Our model set is not yet a real crowd. Survival alone is the best predictor, and diversity needs new kinds of data.
2. Collapse can be a tipping process. Homogeneous societies with strong peer influence can fall off a cliff
   after a temporary shock and stay down. Diverse societies bend and recover.
3. Timing matters for policy. Preventing a tip costs a fraction of reversing one.
