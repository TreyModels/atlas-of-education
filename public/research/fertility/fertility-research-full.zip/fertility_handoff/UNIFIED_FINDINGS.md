# Unified suite: is low fertility one epidemic with local severity?

Script: `unified_suite.py` (about 35 seconds). Results: `results/unified_suite.txt` and `results/unified_suite.json`.
With only six places, U1–U3 are weak tests by design. U4 is synthetic, with invented parameters.

## U1. Placebo: the women-overtaking signal does not survive

- I reassigned enrolment histories across places in all 719 other ways and refitted each time.
- The real assignment ranked 224th of 720. About 31% of the shuffled assignments fit as well as or better than the real one.
- In the change-on-change test, the correlation came out +0.11 (p ≈ 0.10). That is the wrong sign for the theory.
- **Conclusion:** the X1b improvement came from adding a flexible downward term, not from each country's own
  enrolment history. National tertiary-enrolment ratios cannot test the mechanism. Testing it needs micro
  data: who stays unmarried, by sex and education.

## U2. Synchrony: a common post-2015 drop

Co-movement of yearly TFR changes barely changed across periods. The mean pairwise correlation was
+0.26, +0.29 and +0.32 for 1975–94, 1995–2009 and 2010–24.

Every place fell further below its development path between 2015 and 2024:

| Place | Gap 2015 | Gap 2024 | Change |
|---|---|---|---|
| Philippines | +0.52 | −0.33 | −0.85 |
| China | +0.23 | −0.35 | −0.58 |
| Korea | −0.02 | −0.47 | −0.45 |
| Hong Kong | −0.13 | −0.48 | −0.35 |
| Japan | +0.38 | +0.09 | −0.29 |
| Thailand | −0.03 | −0.28 | −0.25 |

The average drop was about 0.46. Six places at very different levels of development all shifted down at
the same time. That is the clearest "epidemic" signature in the data. The early "break years" (1975) for
Thailand, Korea and China are artefacts of the crude break detector during the first fast fall; ignore them.

## U3. Three-layer model: a common shock beats country-to-country spread

- **Common-channel onset profile:** error is flat (0.359) for onsets from 1990 to 2010, then falls to 0.349 for
  onsets in 2015 and 2020. The data can't separate 2015 from 2020, so smartphones and COVID are both still candidates.
- **Mean held-out error:**
  - development alone: 0.403
  - + matching: 0.401
  - + common channel: **0.390**
  - + spillover from other places: 0.430
- The common channel helps Korea, Hong Kong and China a little. It doesn't fix Japan or the Philippines.
- Spillover fits were set to zero in five of six folds. These six places show no sign of one country's
  decline driving another's. What they share looks like a shock hitting everyone at once.

## U4. Which channel matters? (synthetic cohort, 1990-like → 2020-like world)

Effect of switching on each channel alone:

| Channel | Marriage-bound | Births outside marriage common | Main route |
|---|---|---|---|
| Women overtake men | −0.42 | −0.12 | fewer marriages |
| Credential race (costlier children) | −0.39 | −0.41 | fewer births per married woman |
| Kin dissolution | −0.15 | −0.17 | fewer births per married woman |
| Coupling recession | −0.15 | −0.07 | fewer marriages |
| All together | −0.96 | −0.74 | |

- **The credential race is the universal channel.** It hits about equally under both regimes, because it raises the cost of each child.
- **The matching squeeze is the local amplifier.** It is large where births need marriage, and shrinks by
  about 70% where they don't. That is the "same disease, different immune systems" structure the council proposed.

## Revised picture

1. **Susceptibility:** development, survival in particular, brings all places down to about 1.3–1.5.
2. **Common shock since about 2015:** every place in the panel dropped below its path at once. The cause is
   undetermined: smartphones, COVID and economic shocks all fit the timing.
3. **Universal channel (model-based):** the credential race raises the cost per child everywhere.
4. **Local amplifier (model-based):** matching under marriage-bound childbearing. It is real in the simulation
   but **not detectable in national enrolment data** (U1). It needs micro data.

## Next tests that would decide things

- Data on who is unmarried by sex and education (census tables), to test the amplifier.
- Births per married woman vs marriage rates since 2015 in each place: does the common shock run through coupling or through cost?
- Out-of-sample places with different smartphone and COVID timing (Taiwan, Singapore, Vietnam, Malaysia), to separate 2015 from 2020.
