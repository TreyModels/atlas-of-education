import random, math, statistics
r=random.Random(42)
def quant(a,p): a=sorted(a);return a[int((len(a)-1)*p)]
n=50000
m_eff=[];r_eff=[];nonmar=[];frac=[];presult=[];jyoung=[];jold=[];jtotal=[]
for i in range(n):
 m0=r.uniform(.685,.695);m1=r.uniform(.415,.425);f0=r.uniform(152.95,153.05);f1=r.uniform(58.15,58.25);q0=r.uniform(.90,1);q1=r.uniform(.90,1)
 b0=f0*q0;b1=f1*q1;rate0=b0/m0;rate1=b1/m1
 cm=(m1-m0)*(rate0+rate1)/2;cr=(rate1-rate0)*(m1+m0)/2;non=f1*(1-q1)-f0*(1-q0)
 m_eff.append(cm);r_eff.append(cr);nonmar.append(non);frac.append(cm/(f1-f0))
 # +1 unit of an invented family pressure index, no data identify its effect
 beta=r.uniform(-.5,.5);p=.42;pnew=1/(1+math.exp(-(math.log(p/(1-p))+beta)));presult.append(pnew)
 # Independent rounding intervals around Japanese published values in births per woman
 old=[.52,1.05,.43,.10,.01];new=[.09,.35,.47,.27,.06]
 o=[x+r.uniform(-.005,.005) for x in old];k=[x+r.uniform(-.005,.005) for x in new]
 young=sum(k[j]-o[j] for j in (0,1));older=sum(k[j]-o[j] for j in (2,3,4))
 jyoung.append(young);jold.append(older);jtotal.append(young+older)
def show(name,a):print(name,'p05',round(quant(a,.05),4),'median',round(quant(a,.5),4),'p95',round(quant(a,.95),4))
for k,a in [('HK marriage component per 1000',m_eff),('HK birth-rate married component',r_eff),('HK nonmarital residual',nonmar),('HK marriage share of total decline',frac),('hypothetical cultural scenario',presult),('Japan 20–29 age contribution',jyoung),('Japan 30–44 age contribution',jold),('Japan combined',jtotal)]:show(k,a)
print('pressure positive frequency',sum(x>.42 for x in presult)/n)
# historical slope extrapolation, four decadal observations 1960-90; validate 2000,2010,2020
for name,ys,tests in [('HK',[5.085,3.386,2.047,1.272],[1.032,1.127,.883]),('Japan',[2.,2.13,1.75,1.54],[1.36,1.39,1.33])]:
 xs=[0,10,20,30];xm=15;ym=sum(ys)/4;slope=sum((x-xm)*(y-ym) for x,y in zip(xs,ys))/sum((x-xm)**2 for x in xs);intercept=ym-slope*xm
 pred=[intercept+slope*x for x in [40,50,60]];naive=[ys[-1]]*3
 print(name,'linear',[round(x,3) for x in pred],'observed',tests,'MAE linear',round(sum(abs(x-y) for x,y in zip(pred,tests))/3,3),'flat',round(sum(abs(x-y) for x,y in zip(naive,tests))/3,3))
