# Modernity suite: testing Fernández-Villaverde's "the curve fell" on our six places

Script: `modernity_suite.py`. Results: `results/modernity_suite.txt` and `results/modernity_suite.json`.
The infant mortality series has no Hong Kong data and starts in 1969 for China.

## F1. Which yardstick gives the same curve before and after 1985?

| Yardstick | Gap between the 1961–85 and 1986–2024 curves | Low end | High end |
|---|---|---|---|
| Income (log GDP) | 1.50 children | −1.82 | −0.70 |
| Life expectancy | 0.88 | +1.12 | −1.16 |
| Infant mortality | **0.54** | −0.16 | −0.55 |

- The income curve moved the most, mostly at the poor end, as in his chart.
- Child survival is the steadiest yardstick.

## F2. Does a curve that drifts over time predict held-out places better?

| Model | Mean held-out error |
|---|---|
| Income, fixed curve | 1.09 |
| Income + drift over time | 0.86 |
| **Life expectancy, fixed curve** | **0.61** |
| Life expectancy + drift | 0.71 |

- Against income, the curve really did shift, so letting it drift helps.
- Against survival, no drift is needed, and adding it hurts.
- In these six places, income stopped tracking "modernity" but survival did not.

## F3. Replacement at lower income over time

| Place | Year below 2.1 for good | GDP per capita (constant US$) | Life expectancy |
|---|---|---|---|
| Japan | 1974 | 16,279 | 73.7 |
| Hong Kong | 1980 | 12,553 | 74.7 |
| Korea | 1983 | 5,228 | 67.5 |
| Thailand | 1990 | 2,632 | 68.9 |
| China | 1991 | 990 | 68.6 |
| Philippines | 2020 | 3,199 | 70.1 |

- The income at which each place reached replacement fell about 28% for every decade it came later, a 16.5-fold range.
- Life expectancy at crossing stayed within 67.5–74.7 years.
- Replacement fertility arrives at a survival threshold, not an income threshold.
- China's crossing was partly forced by state birth limits.

## F4. New shock, or old drift continuing?

- From 2000 to 2014, the gap below the development path was *closing* in five of six places, with fertility drifting back toward the path.
- Extrapolating that trend predicts 2024 gaps of +0.10 to +0.87. Every place came in well below its prediction.

| Place | 2000–14 trend | Predicted 2024 gap | Observed | Surprise |
|---|---|---|---|---|
| China | +0.53 per decade | +0.87 | −0.35 | −1.22 |
| Philippines | −0.31 | +0.40 | −0.33 | −0.73 |
| Thailand | +0.37 | +0.43 | −0.28 | −0.71 |
| Hong Kong | +0.24 | +0.14 | −0.48 | −0.61 |
| Korea | +0.15 | +0.10 | −0.47 | −0.58 |
| Japan | +0.13 | +0.47 | +0.09 | −0.38 |

- All six fell below their own earlier trend, by 0.71 on average.
- The post-2015 drop is a break, not the old drift continuing.
- Its cause is still open: COVID, smartphones and economic shocks all fit the timing.

## Reading with his argument

1. **He is right that income stopped being the yardstick.** Our six places reached replacement at incomes 16 times apart. Survival did not stop being the yardstick: the survival curve still holds without drift.
2. **His "modernity" looks measurable as survival plus schooling.** Among our yardsticks, the most stable curve is child survival.
3. **His warning against phones is about 1985–95.** In our places the post-2015 fall is a separate break on top of that.
