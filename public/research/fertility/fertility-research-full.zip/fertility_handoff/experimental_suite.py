"""Experimental suite: what explains fertility below the development path?

Uses only data already in this package (no Human Fertility Database):
  - period TFR, GDP per capita and life expectancy, six places, 1961-2024 (asia_panel_data.json, life_asia.json)
  - Korea age-specific fertility 2002, 2012, 2022, Statistics Korea via OECD (stone_stat_jm4h0u)
  - Philippines age-specific fertility 2013, 2017, 2022, DHS (as transcribed in credential_cohort_tests.py)
  - Korea synthetic period parity progressions, OECD Table 2.3 (as transcribed in stone_fertility_tests.py)

Experiments
  E1  When does the gap below the development path open?  (residual of the leave-one-out survival model)
  E2  How much of the low TFR is postponement?             (Bongaarts-Feeney tempo adjustment)
  E3  Which mechanism leaves the observed age fingerprint? (one-parameter mechanisms fitted to TFR only,
                                                            scored on the held-out age pattern)
  E4  Parity check, Korea                                   (first vs second vs higher births)
  E5  Scenarios to 2035, Korea                              (what each surviving mechanism implies next)
Deterministic; numpy/scipy/openpyxl; no network. Period rates throughout; ages are not parities.
"""
import io
import json
import os
import runpy
import contextlib

import numpy as np
from openpyxl import load_workbook
from scipy.optimize import brentq, least_squares

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "results")
os.makedirs(OUT, exist_ok=True)
LINES, RESULTS = [], {}


def say(s=""):
    print(s)
    LINES.append(s)


# ------------------------------------------------------------------ data
with contextlib.redirect_stdout(io.StringIO()):
    TD = runpy.run_path(os.path.join(HERE, "timing_depth_test.py"))
TFR, ZE, PLACES, YEARS = TD["TFR"], TD["ZE"], TD["PLACES"], TD["YEARS"]

wb = load_workbook(io.BytesIO(open(os.path.join(HERE, "stone_stat_jm4h0u"), "rb").read()), data_only=True)
rows = [r for r in wb["Fig_2_5"].iter_rows(values_only=True) if isinstance(r[0], str) and r[0][:2].isdigit()]
KOR = {y: np.array([float(r[i]) for r in rows]) for i, y in [(1, 2002), (2, 2012), (3, 2022)]}
PHL = {2013: np.array([57, 148, 146, 127, 84, 37, 7], float),
       2017: np.array([47, 131, 135, 114, 75, 29, 2], float),
       2022: np.array([25, 84, 105, 95, 58, 21, 2], float)}
MID = np.arange(17.5, 50, 5.0)          # 15-19 ... 45-49
GROUPS = ["15-19", "20-24", "25-29", "30-34", "35-39", "40-44", "45-49"]
tfr_of = lambda f: float(f.sum() * 5 / 1000)
mean_age = lambda f: float((f * MID).sum() / f.sum())

# fine age grid: piecewise-linear schedule through group midpoints, zero at 12.5 and 52.5
AG = np.arange(12.5, 52.51, 0.05)


def to_fine(f):
    return np.interp(AG, np.r_[12.5, MID, 52.5], np.r_[0, f, 0])


def to_groups(g):
    return np.array([g[(AG >= lo) & (AG < lo + 5)].mean() for lo in range(15, 50, 5)])


# ------------------------------------------------------------------ E1 gap opening
say("E1. WHEN DOES THE GAP BELOW THE DEVELOPMENT PATH OPEN?")
say("Residual = observed TFR minus the leave-one-out survival model (logistic and log-linear curves).")
say("Break year = best single kink in a flat-then-sloped line fitted to the residual, 1975-2024.")


def loglin_paths():
    out = {}
    for c in PLACES:
        tr = [x for x in PLACES if x != c]
        b, a = np.polyfit(np.concatenate([ZE[x] for x in tr]), np.log(np.concatenate([TFR[x] for x in tr])), 1)
        out[c] = np.exp(a + b * ZE[c])
    return out


resid_models = {"logistic": TD["paths"]["M2 survival"], "log-linear": loglin_paths()}
E1 = {}
mask = YEARS >= 1975
t = YEARS[mask].astype(float)
for c in PLACES:
    E1[c] = {}
    parts = []
    for nm, pm in resid_models.items():
        r = (TFR[c] - pm[c])[mask]
        best = None
        for tau in range(1980, 2019):
            X = np.column_stack([np.ones_like(t), np.maximum(0, t - tau)])
            b, *_ = np.linalg.lstsq(X, r, rcond=None)
            sse = float(((r - X @ b) ** 2).sum())
            if best is None or sse < best[0]:
                best = (sse, tau, b)
        _, tau, b = best
        snap = {y: round(float(TFR[c][YEARS == y][0] - pm[c][YEARS == y][0]), 2) for y in (1995, 2005, 2015, 2024)}
        E1[c][nm] = dict(break_year=tau, slope_after_per_decade=round(float(b[1] * 10), 2), residual=snap)
        parts.append(f"{nm}: break {tau}, slope after {b[1]*10:+.2f}/decade, gap 1995 {snap[1995]:+.2f} 2005 {snap[2005]:+.2f} 2015 {snap[2015]:+.2f} 2024 {snap[2024]:+.2f}")
    say(f"  {c}  " + "\n       ".join(parts))
RESULTS["E1_gap_opening"] = E1

# ------------------------------------------------------------------ E2 tempo
say("\nE2. HOW MUCH OF THE LOW TFR IS POSTPONEMENT? (Bongaarts-Feeney)")
say("Adjusted TFR = TFR / (1 - r), r = average annual rise in the mean age at childbearing over the interval.")
E2 = []
for name, S, pairs in [("Korea", KOR, [(2002, 2012), (2012, 2022)]), ("Philippines", PHL, [(2013, 2017), (2017, 2022), (2013, 2022)])]:
    for a, b in pairs:
        r = (mean_age(S[b]) - mean_age(S[a])) / (b - a)
        adj = tfr_of(S[b]) / (1 - r)
        E2.append(dict(place=name, interval=f"{a}-{b}", tfr_end=round(tfr_of(S[b]), 3), mean_age_start=round(mean_age(S[a]), 2),
                       mean_age_end=round(mean_age(S[b]), 2), r_per_year=round(r, 3), tempo_adjusted_tfr=round(adj, 3),
                       postponement_share_of_gap_to_adjusted=round((adj - tfr_of(S[b])) / adj, 3)))
        say(f"  {name} {a}-{b}: mean age {mean_age(S[a]):.2f} -> {mean_age(S[b]):.2f} (r = {r:+.3f}/yr); "
            f"TFR {tfr_of(S[b]):.3f}, tempo-adjusted {adj:.3f}")
RESULTS["E2_tempo"] = E2

# ------------------------------------------------------------------ E3 age fingerprints
say("\nE3. WHICH MECHANISM LEAVES THE OBSERVED AGE FINGERPRINT?")
say("Each mechanism is applied to the start-year schedule with ONE parameter, solved so the end-year TFR")
say("matches exactly. The test is the end-year age pattern, which no mechanism was fitted to.")
say("Score = mean absolute error across the seven age groups, births per 1,000 women (lower is better).")


def w_young(a):
    return 1 / (1 + np.exp((a - 28) / 2.0))


MECH = {
    "Q  quantum: same proportional fall at every age": lambda g, p: g * p,
    "T  tempo: schedule shifts older (Bongaarts-Feeney)": None,   # handled specially
    "Y  young barrier: fall concentrated under ~28": lambda g, p: g * (1 - p * w_young(AG)),
    "O  older stopping: fall concentrated over ~28": lambda g, p: g * (1 - p * (1 - w_young(AG))),
}


def tempo(g, shift, years):
    r = shift / years
    return (1 - r) * np.interp(AG - shift, AG, g, left=0, right=0)


def fit_mech(name, f0, f1, years):
    g0, target = to_fine(f0), tfr_of(f1)
    rep = to_groups(g0)   # the start schedule as represented on the fine grid
    if name.startswith("T"):
        fn = lambda s: tfr_of(to_groups(tempo(g0, s, years))) - target
        lo, hi = -years * 0.9, years * 0.9
        if fn(lo) * fn(hi) > 0:
            return None, None
        p = brentq(fn, lo, hi)
        pred = to_groups(tempo(g0, p, years))
    else:
        f = MECH[name]
        fn = lambda p: tfr_of(to_groups(f(g0, p))) - target
        lo, hi = (0.01, 3.0) if name.startswith("Q") else (-3.0, 1.0)
        if fn(lo) * fn(hi) > 0:
            return None, None
        p = brentq(fn, lo, hi)
        pred = to_groups(f(g0, p))
    if pred.min() < -1e-9:
        return p, None
    pred = pred * (f0.sum() / rep.sum())   # remove fine-grid representation error
    return p, pred


def fit_tq(f0, f1, years):
    """Two-parameter tempo + quantum, fitted to end TFR AND end mean age; tested on the remaining shape."""
    g0 = to_fine(f0)
    rep = to_groups(g0)

    def res(x):
        s, q = x
        g = q * tempo(g0, s, years)
        pr = to_groups(g) * (f0.sum() / rep.sum())
        return [tfr_of(pr) - tfr_of(f1), mean_age(pr) - mean_age(f1)]
    x = least_squares(res, [1.0, 0.8], bounds=([-years * .9, 0.05], [years * .9, 3])).x
    pr = to_groups(x[1] * tempo(g0, x[0], years)) * (f0.sum() / rep.sum())
    return x, pr


E3 = []
cases = [("Korea", KOR, 2002, 2012), ("Korea", KOR, 2012, 2022), ("Philippines", PHL, 2013, 2017),
         ("Philippines", PHL, 2017, 2022), ("Philippines", PHL, 2013, 2022)]
for place, S, a, b in cases:
    f0, f1 = S[a], S[b]
    say(f"\n  {place} {a} -> {b}: TFR {tfr_of(f0):.3f} -> {tfr_of(f1):.3f}; observed by age {f1.tolist()}")
    scores = {}
    for name in MECH:
        p, pred = fit_mech(name, f0, f1, b - a)
        if pred is None:
            say(f"    {name:52s} cannot reach the end TFR with a valid schedule")
            continue
        mae = float(np.abs(pred - f1).mean())
        scores[name[:1]] = mae
        E3.append(dict(case=f"{place} {a}-{b}", mechanism=name, parameter=round(float(p), 3), age_mae=round(mae, 2),
                       predicted=np.round(pred, 1).tolist(), observed=f1.tolist()))
        say(f"    {name:52s} param {p:+.3f}  age MAE {mae:6.2f}   predicted {np.round(pred,1).tolist()}")
    x, pr = fit_tq(f0, f1, b - a)
    mae = float(np.abs(pr - f1).mean())
    scores["TQ"] = mae
    E3.append(dict(case=f"{place} {a}-{b}", mechanism="TQ tempo + quantum (2 params: TFR and mean age)",
                   parameter=[round(float(v), 3) for v in x], age_mae=round(mae, 2),
                   predicted=np.round(pr, 1).tolist(), observed=f1.tolist()))
    say(f"    {'TQ tempo + quantum (fitted to TFR and mean age)':52s} shift {x[0]:+.2f}y q {x[1]:.3f}  age MAE {mae:6.2f}   predicted {np.round(pr,1).tolist()}")
    best = min((k for k in scores if k != "TQ"), key=scores.get)
    say(f"    -> best one-parameter mechanism: {best} (age MAE {scores[best]:.2f}); two-parameter TQ {scores['TQ']:.2f}")
RESULTS["E3_age_fingerprints"] = E3

# diversity of the one-parameter mechanisms' predictions (Page)
errs = {}
for e in E3:
    k = e["mechanism"][:2].strip()
    errs.setdefault(k, []).extend(np.array(e["predicted"]) - np.array(e["observed"]))
ks = [k for k in ["Q", "T", "Y", "O"] if k in errs and len(errs[k]) == len(errs["Q"])]
C = np.corrcoef(np.array([errs[k] for k in ks]))
lam = np.linalg.eigvalsh(C)
eff = float(lam.sum() ** 2 / (lam ** 2).sum())
say(f"\n  Diversity across one-parameter mechanisms ({', '.join(ks)}): mean error correlation "
    f"{C[~np.eye(len(ks), dtype=bool)].mean():.2f}, effective number {eff:.2f}")
RESULTS["E3_effective_mechanisms"] = round(eff, 2)

# ------------------------------------------------------------------ E4 parity
say("\nE4. PARITY CHECK, KOREA (OECD synthetic period parity progressions)")
kor_par = {"1965-1983": [.966, .932, .614, .493, .412, .356, .314],
           "1984-1997": [.920, .711, .128, .095, .080, .071, .065],
           "1998-2014": [.866, .543, .111, .081, .065, .056, .049]}
fam = lambda p: float(np.cumprod(p).sum())
E4 = []
names = list(kor_par)
for i in range(len(names) - 1):
    o, n = kor_par[names[i]], kor_par[names[i + 1]]
    base, new = fam(o), fam(n)
    # Shapley-style: average contribution of switching each block (first, second, higher) over all orders
    blocks = [[0], [1], list(range(2, 7))]
    contrib = np.zeros(3)
    import itertools
    perms = list(itertools.permutations(range(3)))
    for perm in perms:
        cur = list(o)
        prev = fam(cur)
        for j in perm:
            for k in blocks[j]:
                cur[k] = n[k]
            v = fam(cur)
            contrib[j] += v - prev
            prev = v
    contrib /= len(perms)
    E4.append(dict(change=f"{names[i]} to {names[i+1]}", family_size=[round(base, 3), round(new, 3)],
                   first=round(contrib[0], 3), second=round(contrib[1], 3), higher=round(contrib[2], 3)))
    say(f"  {names[i]} -> {names[i+1]}: synthetic family size {base:.3f} -> {new:.3f}; "
        f"first births {contrib[0]:+.3f}, second {contrib[1]:+.3f}, third and higher {contrib[2]:+.3f}")
RESULTS["E4_parity"] = E4

# ------------------------------------------------------------------ E5 scenarios
say("\nE5. KOREA TO 2035: WHAT EACH SURVIVING ACCOUNT IMPLIES (scenarios, not forecasts)")
k24 = float(TFR["KOR"][-1])
r_recent = [e for e in E2 if e["place"] == "Korea" and e["interval"] == "2012-2022"][0]
adj = r_recent["tempo_adjusted_tfr"]
yrs = np.arange(2025, 2036)
sc = {
    "Quantum only (level persists)": np.full(len(yrs), k24),
    "Tempo ends by 2030 (TFR rises to the 2012-22 tempo-adjusted level)": k24 + (adj - k24) * np.clip((yrs - 2024) / 6, 0, 1),
    "Tempo + quantum (half the postponement gap recovers)": k24 + 0.5 * (adj - k24) * np.clip((yrs - 2024) / 6, 0, 1),
    "Momentum (2014-2024 linear trend, floored at 0.5)": np.maximum(0.5, k24 + np.polyfit(np.arange(2014, 2025), TFR["KOR"][-11:], 1)[0] * (yrs - 2024)),
}
E5 = {}
for nm, path in sc.items():
    E5[nm] = {int(y): round(float(v), 2) for y, v in zip(yrs, path)}
    say(f"  {nm:70s} 2030 {path[yrs == 2030][0]:.2f}  2035 {path[-1]:.2f}")
say(f"  Observed: 2023 {TFR['KOR'][-2]:.2f}, 2024 {k24:.2f} (first rise since 2015).")
RESULTS["E5_scenarios"] = E5

with open(os.path.join(OUT, "experimental_suite.txt"), "w") as f:
    f.write("\n".join(LINES) + "\n")
json.dump(RESULTS, open(os.path.join(OUT, "experimental_suite.json"), "w"), indent=1, default=str)
