"""Sensitivity for Kate's model: how strong must each channel be to matter?"""
import os, runpy, contextlib, io, json
import numpy as np
with contextlib.redirect_stdout(io.StringIO()):
    K = runpy.run_path(os.path.join(os.path.dirname(os.path.abspath(__file__)), "kate_model.py"))
cohort, NOW, births, TABLE, AGES, sim, P = K["cohort"], K["NOW"], K["births"], K["TABLE"], K["AGES"], K["sim_births"], K["P"]
lines = []
def say(s): print(s); lines.append(s)
ref = cohort(*NOW, True, True, False, False)
say(f"Reference: education expanded with career start and partner standard on: marriage age {ref['mean_marriage_age']:.1f}, CF {ref['cf']:.2f}")
# diet/stress: completed births for a couple wanting two who marry at 28 (China 2020) or 31.6 (Korea 2024)
for f in (1.0, 0.85, 0.7, 0.5):
    Pf = (P[0] * f,) + P[1:]
    a = sim(29.0, 2, Pf, n=6000, seed=2).mean(); b = sim(32.6, 2, Pf, n=6000, seed=2).mean()
    say(f"  Conception chance x{f:.2f}: couple wanting two, marrying at 28 -> {a:.2f}; at 31.6 -> {b:.2f}")
say("  Career start: years establishing work before seeking a partner (tertiary graduates):")
src = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "kate_model.py")).read()
for est in (1, 3, 5, 7):
    g = dict(K); code = src.split("THEN = (0.10")[0].replace("est = 3.0 if K1 else 1.0", f"est = {float(est)} if K1 else 1.0")
    exec(code, g)
    r = g["cohort"](*NOW, True, True, False, False)
    say(f"    {est} years: marriage age {r['mean_marriage_age']:.1f}; ever married {r['ever_married']:.0%}; CF {r['cf']:.2f}")
open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "results", "kate_sensitivity.txt"), "w").write("\n".join(lines) + "\n")
