"""IVF, decomposition and policy levers on top of the Habbema-calibrated clock (fecundity_age_model.py).

I1  Add IVF. Couples who have tried naturally for 12 months (6 from age 35) may start IVF: up to 4 cycles,
    3 months each, live-birth chance per cycle falling with age (shape approximate: 1.0 under 35, 0.75 at
    35-37, 0.5 at 38-40, 0.25 at 41-42, 0.1 at 43-44; nothing from 45), times one scale fitted to Habbema et
    al.'s IVF thresholds: 90% chance of 1 child if trying starts by 35, 2 children by 31, 3 children by 28.
I2  Validation: with what IVF uptake does the Korean 2024 marriage schedule produce Korea's observed share
    of births from infertility treatment (15.1% in 2024, Health Insurance Review and Assessment Service)?
    Note that the 15.1% includes artificial insemination as well as IVF.
I3  How much of the late-marriage clock cost does IVF give back, at that uptake and at full uptake?
I4  Korea decomposition, 2000 -> 2024, completed-family terms:
      TFR (tempo-adjusted) = ever-married share x births per married woman (clock x intentions).
    Tempo adjustment uses the rise in mean age at first birth (about 0.2 years a year in both periods), so it
    divides both years by 0.8 and cancels in the ratio. Ever-married share: 98% (women in their 40s, 2000);
    for 2024 two scenarios: 88% (women in their 40s, 2020) and 75% (a projection for today's young cohorts,
    given 56% of 30-34 year olds unmarried in 2020). Intentions are solved for as the residual.
I5  Policy levers (2024 world, 75% scenario): marriage 2 years earlier; ever-married +10 points; full IVF
    uptake; second-birth support (+0.2 in intentions); and combinations.

Approximate and partly assumed; see the findings file.
"""
import json, os
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "results")
LINES, RES = [], {}


def say(s=""):
    print(s, flush=True); LINES.append(s)


P = tuple(json.load(open(os.path.join(OUT, "fecundity_age_model.json")))["A1"]["params"])
MISC_AGE = np.array([20, 25, 30, 35, 40, 45, 50]); MISC_P = np.array([0.10, 0.10, 0.12, 0.18, 0.35, 0.60, 0.80])
IVF_AGE = np.array([20, 34.99, 35, 37.99, 38, 40.99, 41, 42.99, 43, 44.99, 45, 50])
IVF_SHAPE = np.array([1, 1, .75, .75, .5, .5, .25, .25, .1, .1, 0, 0])


def simulate(start_age, target, ivf_scale=0.0, uptake=0.0, n=20000, seed=1, start_sd=0.0, target_mix=None):
    """target: int, or target_mix=(lo, p_hi) meaning each couple wants lo or lo+1 children (prob p_hi)."""
    p0, a0, r, mu, s, f0 = P
    rng = np.random.default_rng(seed)
    het = rng.gamma(3.0, 1 / 3.0, n)
    u = np.clip(rng.random(n), 1e-9, 1 - 1e-9)
    ster = mu + s * np.log(u / (1 - u)); ster[rng.random(n) < f0] = 0.0
    tgt = np.full(n, target) if target_mix is None else target_mix[0] + (rng.random(n) < target_mix[1])
    age = start_age + (rng.normal(0, start_sd, n) if start_sd else np.zeros(n))
    accept = rng.random(n) < uptake
    kids = np.zeros(n, int); ivf_kids = np.zeros(n, int); wait = np.zeros(n); tried = np.zeros(n)
    cycles = np.zeros(n, int)
    active = np.ones(n, bool)
    while active.any():
        age += 1 / 12
        wait = np.maximum(wait - 1, 0)
        active &= (age < 50) & (kids < tgt)
        nat_ok = active & (age < ster)
        trying = active & (wait == 0)
        if not trying.any():
            continue
        # natural conception
        d = np.where(age <= a0, 1.0, np.exp(-r * (age - a0)))
        pc = np.clip(p0 * het * d, 0, 0.95)
        conceive = trying & nat_ok & (rng.random(n) < pc)
        tried += trying & ~conceive
        # IVF: after 12 months (6 from 35) without conception, up to 4 cycles per child sought
        limit = np.where(age >= 35, 6, 12)
        go_ivf = trying & ~conceive & accept & (tried >= limit) & (cycles < 4) & (age < 45) & (ivf_scale > 0)
        pivf = np.clip(ivf_scale * np.interp(age, IVF_AGE, IVF_SHAPE), 0, 0.9)
        ivf_success = go_ivf & (rng.random(n) < pivf)
        cycles += go_ivf
        wait[go_ivf & ~ivf_success] = 3
        preg = conceive | ivf_success
        loss = conceive & (rng.random(n) < np.interp(age, MISC_AGE, MISC_P))     # IVF rate is already live births
        wait[loss] = 3
        born = preg & ~loss
        kids += born; ivf_kids += ivf_success
        wait[born] = 15; tried[born] = 0; cycles[born] = 0
    return kids, ivf_kids


# ================================================================ I1
say("I1. CALIBRATING IVF TO HABBEMA ET AL. (2015): 90% FOR 1 CHILD BY 35, 2 BY 31, 3 BY 28 (full uptake)")
best = None
for sc in np.arange(0.20, 0.61, 0.05):
    e = sum((np.mean(simulate(a, k, sc, 1.0, n=6000)[0] >= k) - 0.9) ** 2 for a, k in ((35, 1), (31, 2), (28, 3)))
    if best is None or e < best[0]:
        best = (e, sc)
SC = float(best[1])
say(f"  Fitted live-birth chance per IVF cycle under 35: {SC:.2f}")
cal = []
for a, k in ((35, 1), (31, 2), (28, 3)):
    v = float(np.mean(simulate(a, k, SC, 1.0)[0] >= k)); cal.append(dict(start=a, children=k, model=v))
    say(f"  Start {a}, want {k}: published 90% with IVF; model {v:.0%}")
RES["I1"] = dict(scale=SC, calibration=cal)

# ================================================================ I2
say("\nI2. VALIDATION: IVF UPTAKE THAT REPRODUCES KOREA'S 15.1% OF BIRTHS FROM INFERTILITY TREATMENT (2024)")
up_rows = []
for upt in (0.2, 0.4, 0.6, 0.8, 1.0):
    k, iv = simulate(31.6 + 1, 2, SC, upt, n=30000, start_sd=3.5, seed=3)
    share = iv.sum() / max(k.sum(), 1)
    up_rows.append(dict(uptake=upt, art_share=float(share), per_married=float(k.mean())))
    say(f"  Uptake {upt:.0%}: treatment share of births {share:.1%}; children per married woman {k.mean():.2f}")
ups = np.array([r["uptake"] for r in up_rows]); shs = np.array([r["art_share"] for r in up_rows])
U = float(np.interp(0.151, shs, ups)) if shs.max() >= 0.151 else 1.0
say(f"  Uptake matching 15.1%: about {U:.0%}" + ("" if shs.max() >= 0.151 else " (model cannot reach 15.1% even at full uptake)"))
RES["I2"] = dict(rows=up_rows, matched_uptake=U)

# ================================================================ I3
say("\nI3. HOW MUCH OF THE CLOCK COST DOES IVF GIVE BACK? (Korea, want two)")
i3 = {}
for lab, upt in (("no IVF", 0.0), (f"uptake {U:.0%}", U), ("full uptake", 1.0)):
    k95 = simulate(25.3 + 1, 2, SC, upt, n=30000, start_sd=3.5, seed=3)[0].mean()
    k24 = simulate(31.6 + 1, 2, SC, upt, n=30000, start_sd=3.5, seed=3)[0].mean()
    i3[lab] = dict(m1995=float(k95), m2024=float(k24), cost=float(k95 - k24))
    say(f"  {lab:14s}: 1995 schedule {k95:.2f}, 2024 schedule {k24:.2f}; clock cost {k95-k24:.2f}")
rec = (i3["no IVF"]["cost"] - i3[f"uptake {U:.0%}"]["cost"]) / i3["no IVF"]["cost"]
say(f"  At Korea's current uptake IVF gives back about {rec:.0%} of the clock cost; at full uptake "
    f"{(i3['no IVF']['cost']-i3['full uptake']['cost'])/i3['no IVF']['cost']:.0%}")
RES["I3"] = i3

# ================================================================ I4
say("\nI4. KOREA 2000 -> 2024 DECOMPOSITION (tempo-adjusted, completed-family terms)")
TEMPO = 0.8
tfr00, tfr24 = 1.48, 0.75


def per_married(mean_intent, marriage_age, ivf_up):
    lo = int(np.floor(mean_intent)); ph = mean_intent - lo
    k, _ = simulate(marriage_age + 1, None, SC, ivf_up, n=20000, start_sd=3.5, seed=7, target_mix=(lo, ph))
    return float(k.mean())


def solve_intent(target_pm, marriage_age, ivf_up):
    lo_i, hi_i = 0.5, 3.5
    for _ in range(14):
        mid = (lo_i + hi_i) / 2
        if per_married(mid, marriage_age, ivf_up) < target_pm:
            lo_i = mid
        else:
            hi_i = mid
    return (lo_i + hi_i) / 2


EM00 = 0.98
pm00 = tfr00 / TEMPO / EM00
I00 = solve_intent(pm00, 26.5, 0.05)
say(f"  2000: TFR {tfr00} -> tempo-adjusted {tfr00/TEMPO:.2f}; ever married {EM00:.0%}; births per married {pm00:.2f}; "
    f"implied mean intention {I00:.2f}")
dec = {}
for EM24 in (0.88, 0.75):
    pm24 = tfr24 / TEMPO / EM24
    I24 = solve_intent(pm24, 31.55, U)
    clock_only = per_married(I00, 31.55, U)          # 2000 intentions, 2024 marriage age and IVF
    total = np.log(tfr24 / tfr00)
    parts = dict(marriage_share=np.log(EM24 / EM00), clock_net_of_ivf=np.log(clock_only / pm00),
                 intentions=np.log(pm24 / clock_only))
    dec[str(EM24)] = dict(pm24=pm24, intention24=I24, shares={k: float(v / total) for k, v in parts.items()})
    say(f"  2024 with {EM24:.0%} ever married: births per married {pm24:.2f}; implied intention {I24:.2f} (from {I00:.2f}).")
    say("     Share of the fall: " + ", ".join(f"{k.replace('_',' ')} {v/total:.0%}" for k, v in parts.items()))
RES["I4"] = dict(intent2000=I00, scenarios=dec)

# ================================================================ I5
say("\nI5. POLICY LEVERS, 2024 KOREA (75% ever-married scenario), completed fertility per woman (tempo-adjusted)")
I24 = dec["0.75"]["intention24"]
base = 0.75 * per_married(I24, 31.55, U)


def lever(em=0.75, age=31.55, up=U, intent=I24):
    return em * per_married(intent, age, up)


levers = [("Marriage 2 years earlier", dict(age=29.55)), ("Ever-married +10 points", dict(em=0.85)),
          ("Full IVF uptake", dict(up=1.0)), ("Second-birth support (+0.2 intention)", dict(intent=I24 + 0.2)),
          ("Earlier marriage + more marriage", dict(age=29.55, em=0.85)),
          ("All four", dict(age=29.55, em=0.85, up=1.0, intent=I24 + 0.2))]
i5 = []
say(f"  Baseline {base:.2f} children per woman (tempo-adjusted)")
for nm, kw in levers:
    v = lever(**kw)
    i5.append(dict(lever=nm, value=float(v), change=float(v - base)))
    say(f"  {nm:40s} {v:.2f} ({v-base:+.2f})")
RES["I5"] = dict(baseline=float(base), levers=i5)

with open(os.path.join(OUT, "ivf_policy_suite.txt"), "w") as f:
    f.write("\n".join(LINES) + "\n")
json.dump(RES, open(os.path.join(OUT, "ivf_policy_suite.json"), "w"), indent=1, default=float)
