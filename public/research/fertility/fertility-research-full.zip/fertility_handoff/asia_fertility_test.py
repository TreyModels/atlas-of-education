"""Five-year conditional fertility hindcasts, using World Bank series via FRED.

All predictors are measured five years before the outcome. A country mean
bootstrap treats countries, not overlapping annual observations, as units.
"""
import json
import numpy as np
from sklearn.linear_model import LinearRegression

data=json.load(open('asia_panel_data.json'))
countries=['PHL','THA','KOR','JPN','HKG','CHN']
rows=[]
for c in countries:
    f=data['tfr_'+c]['values']; g=data['gdp_'+c]['values']
    for t in range(1965,2025):
        a,b=str(t-5),str(t)
        if a in f and b in f and a in g and g[a]>0:
            rows.append((c,t,f[a],np.log(g[a]),f[b]))

def features(r,model):
    c,t,lag,lgdp,y=r
    v=[lag]
    if 'gdp' in model:v.append(lgdp)
    if 'country' in model:v += [int(c==name) for name in countries[1:]]
    return v

def predict(train,test,model):
    if model=='persistence':return np.array([r[2] for r in test])
    m=LinearRegression().fit([features(r,model) for r in train],[r[4] for r in train])
    return m.predict([features(r,model) for r in test])

train=[r for r in rows if r[1]<=2009]
test=[r for r in rows if r[1]>=2010]
print('train',len(train),'test',len(test),'years',min(r[1] for r in test),max(r[1] for r in test))
models=['persistence','lag','lag_gdp','lag_country','lag_gdp_country']
country_err={}
for model in models:
    pred=predict(train,test,model)
    errs=np.abs(pred-np.array([r[4] for r in test]))
    means=np.array([np.mean([e for r,e in zip(test,errs) if r[0]==c]) for c in countries])
    country_err[model]=means
    print(model,'overall',round(errs.mean(),3),'countries',dict(zip(countries,np.round(means,3))))
    print('2024',dict((r[0],(round(p,2),round(r[4],2))) for r,p in zip(test,pred) if r[1]==2024))
for model in ['lag','lag_gdp']:
    diffs=[]
    for c in countries:
        tr=[r for r in train if r[0]!=c]; te=[r for r in test if r[0]==c]
        p=predict(tr,te,model); diffs.append(np.mean(np.abs(p-np.array([r[4] for r in te]))))
    print('leave-country-out',model,dict(zip(countries,np.round(diffs,3))),'mean',round(np.mean(diffs),3))

rng=np.random.default_rng(825)
diff=country_err['lag_gdp']-country_err['lag']
bootstrap=diff[rng.integers(0,6,size=(10000,6))].mean(axis=1)
print('lag+gdp minus lag country-bootstrap MAE change',round(diff.mean(),3),'90% quantiles',np.round(np.quantile(bootstrap,[.05,.95]),3))

# The WDI series for Hong Kong infant mortality is unavailable in this extract.
# Compare on the same observations for the remaining five places.
sub=[]
for r in rows:
    c,t,lag,lgdp,y=r
    mort=data['mortality_'+c]['values'].get(str(t-5))
    if mort and mort>0: sub.append((r,np.log(mort)))
tr=[x for x in sub if x[0][1]<=2009]; te=[x for x in sub if x[0][1]>=2010]
for typ in ['lag','lag_mortality']:
    def xx(q):return [q[0][2]]+([q[1]] if typ=='lag_mortality' else [])
    m=LinearRegression().fit([xx(q) for q in tr],[q[0][4] for q in tr])
    p=m.predict([xx(q) for q in te]); e=abs(p-np.array([q[0][4] for q in te]))
    print('mortality matched',typ,'train',len(tr),'test',len(te),'MAE',round(e.mean(),3),'country', {c:round(np.mean([x for q,x in zip(te,e) if q[0][0]==c]),3) for c in countries if c!='HKG'})
