# Angkor Institution Laboratory v0.1

**Status: exploratory, uncalibrated mechanism prototype. NOT historical estimates.**

Run: `python model.py --out scenarios.json` ; tests: `python -m unittest -v`.

The simulation represents 24 temple-linked communities, each with a local patron identity, population, land, stored rice, canal condition, household trust, and a share of land held by local families. It distinguishes rice transferred to households, temple stores, patrons, and a central court. It compares communal/elite-oriented levies and relief behavior under a synthetic 8-year drought.

## Preliminary output (same random seed)

- communal: maximum annual unmet food 0 kg; final population 15,499.5
- elite extraction: maximum annual unmet food 287,877 kg; final population 10,957.6
- communal + drought: maximum annual unmet food 416,834 kg; final population 14,917.6
- elite extraction + drought: maximum annual unmet food 1,869,822 kg; final population 5,263.6

All four scenarios initialize with 9,600 people. All values are **synthetic**.

## Research questions and current limitations

- Land share is currently a tracked institutional state, **not yet causally linked** to yield, tenure security, or migration. Hence the model does not yet demonstrate dispossession-driven relocation.
- Patron identity switches stochastically, not via inheritance/succession, lawsuit, kinship bargaining, or conquest.
- Patron wealth and court grain accumulate without spent obligations, redistributive rules or military costs. Court famine relief has not yet been implemented, to avoid crediting relief to populations before it reaches households.
- Maintenance is a rice-budget proxy, not physical labor hours; canals are local scalar stocks rather than an actual graph with sediment routing.
- Households are aggregated within community; explicit heterogeneous families and bounded relations have not yet been added.
- This is a discrete-year mechanism demo and is **not integrated into the earlier Atlas Angkor model**; no claim of historical fit or comparative validation.
- Next: two-pass household allocation with entitlement constraints and auditable grain conservation, land acquisition and succession events, then network-level hydraulic flows and archaeological calibrations.

## Historical provenance

- Eileen and Terry Lustig, *Losing ground: Decline of Angkor's middle-level officials*, Journal of Southeast Asian Studies (2019): named lower and higher elite actors, land acquisitions and religious foundation transactions.
- Eileen Lustig, *Power and Pragmatism in the Political Economy of Angkor* (2009): regional elites, decentralized relationships and temple networks.
- Sarah Klassen et al., *Provisioning an Early City* (2022): temple-community organization, settlement and agricultural output proxy; the linked evidence in the conversation is the uploaded article.

Frameworks for testing, not verified Angkor-specific mechanisms: Amartya Sen (entitlements); James C. Scott (moral economy and state legibility); Tainter (complexity maintenance); comparative late Roman Britain institutional restructuring.
