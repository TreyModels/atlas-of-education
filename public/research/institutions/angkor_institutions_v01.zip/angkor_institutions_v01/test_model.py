import unittest
from model import Settings,run
class SmokeTests(unittest.TestCase):
    def test_outputs(self):
        a=run(Settings(years=20,seed=13))
        self.assertEqual(len(a),20)
        for x in a:
            self.assertGreater(x['population'],0)
            self.assertGreaterEqual(x['court_treasury'],0)
            self.assertGreaterEqual(x['temple_stocks'],0)
            self.assertTrue(0<=x['avg_household_land_share']<=1)
    def test_reproducibility(self):
        self.assertEqual(run(Settings(years=5)),run(Settings(years=5)))
    def test_shock_direction(self):
        a=run(Settings(climate_crisis=False))
        b=run(Settings(climate_crisis=True))
        self.assertLess(sum(x['harvest'] for x in b[70:78]),sum(x['harvest'] for x in a[70:78]))
if __name__=='__main__':unittest.main()
