"""Illustrative Angkor institutional-political economy mechanism laboratory v0.1.
NOT a calibrated reconstruction. kg rice-equiv, ha, yearly time step.
Models hereditary elite patronage, land-tenure shifts, temple relief, infrastructure maintenance.
"""
from dataclasses import dataclass
from typing import List
import random, json, argparse

@dataclass
class Community:
    id: int
    population: float = 400.
    cultivated_ha: float = 110.
    family_land_share: float = .65
    food_store: float = 15000.
    canal: float = .9
    trust: float = .75
    patron_id: int = 0
    patron_wealth: float = 0.
    emigrated: float = 0.

@dataclass
class Settings:
    years: int = 120
    communities: int = 24
    yield_kg_ha: float = 2200.
    need_kg_person: float = 280.
    seed_rate: float = 65.
    spoilage: float = .06
    court_tax: float = .13
    temple_levy: float = .12
    patron_levy: float = .07
    relief_fraction: float = .65
    maintenance_fraction: float = .32
    appropriation_rate: float = .006
    patron_competition: float = .02
    climate_crisis: bool = False
    seed: int = 3

def run(s: Settings):
    rng=random.Random(s.seed)
    C=[Community(id=i,patron_id=i//4) for i in range(s.communities)]
    treasury=0.
    results=[]
    for year in range(s.years):
        shock = (0.45 if s.climate_crisis and 70 <= year < 78 else 1.0) * rng.uniform(.91,1.09)
        court_collect=0.; court_relief=0.; total_harvest=0.; total_need=0.; total_famine=0.; total_migration=0.; total_maintenance=0.; total_surplus=0.
        for c in C:
            # Local temple and elite strata are institutionally linked, not identical.
            c.family_land_share=max(.08,c.family_land_share - s.appropriation_rate*(1+.3*(1-c.trust)))
            yield_total=c.cultivated_ha*s.yield_kg_ha*shock*(.45+.55*c.canal)
            seed_need=c.cultivated_ha*s.seed_rate
            harvest=max(0.,yield_total-seed_need)
            court=s.court_tax*harvest; temple=s.temple_levy*harvest; patron=s.patron_levy*harvest
            # Explicit transfer: household own harvest, temple fund, patrons and court.
            household=harvest-court-temple-patron
            local_levy_store=temple
            c.patron_wealth+=patron
            court_collect+=court
            total_harvest+=harvest
            need=c.population*s.need_kg_person
            total_need+=need
            # Deposits and previous year's stocks. Spoilage and repairs are tracked.
            stocks_before=c.food_store*(1-s.spoilage)
            maintenance_paid=local_levy_store*s.maintenance_fraction
            total_maintenance+=maintenance_paid
            local_available=stocks_before + local_levy_store-maintenance_paid
            subsistence_short=max(0.,need-household)
            relief=min(subsistence_short,local_available*s.relief_fraction)
            local_available-=relief
            unmet=max(0.,need-household-relief)
            c.food_store=local_available + max(0.,household-need)
            # Capacity and maintenance are independent of granary resources.
            repaired=min(.065,maintenance_paid/(c.cultivated_ha*3000))
            c.canal=max(.2,min(1.,c.canal-.018 + repaired - (.1 if s.climate_crisis and year in (71,75) else 0)))
            # Nutritional deficit affects mortality, mobility, social contract.
            deprivation=min(1.,unmet/max(1,need))
            mortality=(.017+.24*deprivation)*c.population
            births=.021*c.population*(1-deprivation)
            flight=c.population*max(0.,(deprivation-.07))*.18
            c.population=max(1.,c.population + births-mortality-flight)
            c.emigrated+=flight
            total_famine+=unmet
            total_migration+=flight
            c.trust=max(0.,min(1.,c.trust+.02*(relief/max(1,subsistence_short)) if subsistence_short>0 else c.trust+.002)) if deprivation==0 else max(0.,c.trust-.08*deprivation)
            # Patrons may switch via succession/competition; family relations persist locally.
            if rng.random()<s.patron_competition*(1-c.trust):
                c.patron_id=rng.randrange(max(1,s.communities//4))
            total_surplus+=max(0,household-need)
        treasury+=court_collect
        # Court stores accumulate; state relief is reserved for a later two-pass
        # allocation model so that relief can affect household mortality consistently.
        court_relief=0.0
        results.append(dict(year=year,population=round(sum(c.population for c in C),1),harvest=round(total_harvest),needs=round(total_need),unmet_food=round(total_famine),migration=round(total_migration,1),temple_stocks=round(sum(c.food_store for c in C)),patron_wealth=round(sum(c.patron_wealth for c in C)),court_treasury=round(treasury),avg_canal=round(sum(c.canal for c in C)/len(C),3),avg_household_land_share=round(sum(c.family_land_share for c in C)/len(C),3),avg_trust=round(sum(c.trust for c in C)/len(C),3),court_relief=round(court_relief)))
    return results

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--out',default='results.json');args=ap.parse_args()
    scenarios={'communal':Settings(relief_fraction=.95,temple_levy=.18,patron_levy=.02,appropriation_rate=.001), 'elite_extraction':Settings(relief_fraction=.25,temple_levy=.08,patron_levy=.19,appropriation_rate=.012), 'communal_drought':Settings(relief_fraction=.95,temple_levy=.18,patron_levy=.02,appropriation_rate=.001,climate_crisis=True), 'elite_drought':Settings(relief_fraction=.25,temple_levy=.08,patron_levy=.19,appropriation_rate=.012,climate_crisis=True)}
    data={name:run(settings) for name,settings in scenarios.items()}
    with open(args.out,'w') as f:json.dump({'status':'hypothetical mechanism tests, not Angkor estimates','scenarios':data},f,indent=2)
    for name,rows in data.items():
        print(name,'peak_food_shortfall',max(r['unmet_food'] for r in rows),'final_pop',rows[-1]['population'],'final_canal',rows[-1]['avg_canal'],'final_family_land_share',rows[-1]['avg_household_land_share'])
