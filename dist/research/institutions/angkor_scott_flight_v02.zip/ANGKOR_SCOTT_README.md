# Angkor Scott migration/fortification v0.2

**Status**: original exploratory implementation, uncalibrated; not an archaeological reconstruction or reproduction of James C. Scott's source code.

Run `python angkor_scott_flight_v02.py --seeds 40` to recreate the 160-run drought experiment. `angkor_scott_climate_defense_comparison.csv` includes both drought and no-drought cases, 320 runs total. Code runs 110 annual steps with 24 aggregate temple communities starting at 400 people each and one refuge population.

## Model mechanisms
- Rice harvest depends on land, weather, local canal condition and the labor diverted to defenses.
- Separate court, temple, elite, and household harvest allocations; actual temple stores fund emergency relief.
- Malnutrition influences annual mortality and births.
- Households flee in response to nutrition deficits, extraction grievances, and trust, subject to an exit cost. The refuge has finite carrying capacity and births/deaths.
- Recapture transfers people from refuge back into communities. Population is conserved exactly aside from births/deaths (asserted each year).
- Fortress work reduces farm labor and higher exit costs and recapture rates reduce outward migration.

## Restrictions
- No explicit walls, gates, canal graph, real mountain locations, military combat, or household networks yet. All defenses and exit costs are abstract parameters. The runoff/monsoon shock is a fictional 9-year 64% crop-supply reduction in years 65 to 73, not the historical Buckley dataset.
- Refuge subsistence is represented by a population-capacity penalty, not an independently tracked grain harvest. Court grain accumulates instead of being spent in real spending sectors. Total *modeled population* is accounted for, but the model is **not** a fully closed food economy.
- The isolated 'relief fraction' mechanism is insufficiently identified because harvested food can cover most ordinary-year needs in all scenarios. Some counterintuitive relationships in results reflect the artificial parameter choices and require further checks.
- Results are model implications at arbitrary parameters, not evidence that Ayutthayan siegeworks trapped peasants, that Angkor's walls caused famine, or that temple relief worked in a historically specified fashion.
