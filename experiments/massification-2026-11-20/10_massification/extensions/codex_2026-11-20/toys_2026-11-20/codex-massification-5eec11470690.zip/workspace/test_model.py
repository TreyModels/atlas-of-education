"""Run with python3 -m unittest discover -s outputs/toy."""
import unittest
from itertools import product

from model import JOBS, POPULATION, PRIVATE_CAPACITY, run


class AdmissionsTests(unittest.TestCase):
    def test_market_accounting(self):
        settings = product(("human_capital", "signaling"), (0, 30, 50, POPULATION),
                           (1.0, 2.0, 2.75, 5.0), (0, 0.5, 1))
        for mechanism, seats, fee, visibility in settings:
            with self.subTest(mechanism=mechanism, seats=seats, fee=fee, visibility=visibility):
                r = run(mechanism, seats, fee, visibility)
                self.assertEqual(r["applications"], r["admissions"] + r["unmet"])
                self.assertEqual(r["admissions"], r["public_admissions"] + r["private_admissions"])
                self.assertEqual(r["public_admissions"], min(seats, r["applications"]))
                self.assertGreaterEqual(r["unmet"], 0)
                self.assertLessEqual(r["private_admissions"], PRIVATE_CAPACITY)
                self.assertEqual(r["private_entry"], r["private_admissions"] > 0)
                self.assertEqual(r["hires"], JOBS)
                self.assertLessEqual(r["graduate_hires"], min(JOBS, r["admissions"]))

    def test_baseline_equivalence_and_skill_difference(self):
        h, s = run("human_capital"), run("signaling")
        self.assertGreater(s["private_admissions"], 0)
        for key in ("applications", "admissions", "private_admissions", "graduate_hires"):
            self.assertEqual(h[key], s[key])
        self.assertAlmostEqual(h["mean_skill"] - s["mean_skill"], h["admissions"] / POPULATION,
                               places=5)

    def test_visibility_changes_demand_by_mechanism(self):
        self.assertEqual(run("human_capital")["applications"],
                         run("human_capital", visibility=1)["applications"])
        self.assertGreater(run("signaling")["applications"], 0)
        self.assertEqual(run("signaling", visibility=1)["applications"], 0)

    def test_extra_public_seats_displace_private_and_expand_total(self):
        old, new = run("signaling"), run("signaling", public_seats=50)
        self.assertLess(new["private_admissions"], old["private_admissions"])
        self.assertGreater(new["admissions"], old["admissions"])
        self.assertLess(new["admissions"] - old["admissions"], 20)

    def test_private_entry_requires_demand_and_margin(self):
        for fee in (1, 5):
            with self.subTest(fee=fee):
                r = run("human_capital", public_seats=0, tuition=fee)
                self.assertGreater(r["applications"], 0)
                self.assertFalse(r["private_entry"])
                self.assertEqual(r["admissions"], 0)

    def test_invalid_settings(self):
        for options in ({"public_seats": -1}, {"public_seats": 2.5}, {"tuition": 0},
                        {"tuition": float("nan")}, {"visibility": 1.5}):
            with self.subTest(options=options), self.assertRaises(ValueError):
                run("human_capital", **options)
        with self.assertRaises(ValueError):
            run("unknown")


if __name__ == "__main__":
    unittest.main()
