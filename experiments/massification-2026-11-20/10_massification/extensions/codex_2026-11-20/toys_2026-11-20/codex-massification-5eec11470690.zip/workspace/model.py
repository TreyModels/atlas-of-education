"""A one-cohort admissions market. Run with Python 3; no dependencies."""
import csv
import math
import random
import sys

POPULATION = 100
JOBS = 40
PUBLIC_FEE = 1.0
PRIVATE_CAPACITY = 30
PRIVATE_FIXED_COST = 12
PRIVATE_SEAT_COST = 1.0


def run(mechanism, public_seats=30, tuition=2.0, visibility=0.0):
    """Public applicants use a common lottery. A private entrant serves overflow.

    Budget (1.5 or 4) constrains cash fees. Each person's subjective value of a
    degree before fees is 4 minus their opportunity cost. Under signaling, the
    gross credential premium of 4 shrinks with employer skill visibility.
    The premium is imposed, not an equilibrium wage derived from the hiring step.
    """
    if mechanism not in ("human_capital", "signaling"):
        raise ValueError("unknown mechanism")
    if type(public_seats) is not int or public_seats < 0:
        raise ValueError("public_seats must be a nonnegative integer")
    if not math.isfinite(tuition) or tuition < PUBLIC_FEE:
        raise ValueError("private tuition must be finite and at least the public fee")
    if not 0 <= visibility <= 1:
        raise ValueError("visibility must lie between 0 and 1")

    rng = random.Random(41)
    budgets = [1.5, 4.0] * (POPULATION // 2)
    base_skill = [rng.random() for _ in budgets]
    costs = [3.5 * rng.random() for _ in budgets]
    lottery = list(range(POPULATION))
    rng.shuffle(lottery)
    signal_weight = 1 - visibility
    premium = 4.0 if mechanism == "human_capital" else 4.0 * signal_weight
    applicants = [i for i in lottery if premium - costs[i] >= PUBLIC_FEE]
    public = applicants[:public_seats]
    waiting = applicants[public_seats:]
    customers = [i for i in waiting if tuition <= budgets[i] and premium - costs[i] >= tuition]
    potential_sales = min(PRIVATE_CAPACITY, len(customers))
    enters = potential_sales * (tuition - PRIVATE_SEAT_COST) >= PRIVATE_FIXED_COST
    private = customers[:potential_sales] if enters else []
    graduates = set(public + private)
    skill = [s + (i in graduates and mechanism == "human_capital") for i, s in enumerate(base_skill)]
    # Employers infer a unit premium from a credential when skill is hidden.
    # As skill becomes visible, they rank applicants by measured productivity.
    score = [visibility * s + signal_weight * (i in graduates) for i, s in enumerate(skill)]
    hired = sorted(lottery, key=score.__getitem__, reverse=True)[:JOBS]
    return dict(applications=len(applicants), public_admissions=len(public),
                private_admissions=len(private), admissions=len(graduates),
                unmet=len(waiting) - len(private), private_entry=enters,
                mean_skill=round(sum(skill) / POPULATION, 6), hires=len(hired),
                graduate_hires=sum(i in graduates for i in hired))


if __name__ == "__main__":
    scenarios = {"baseline": {}, "more public seats": {"public_seats": 50},
                 "higher private fee": {"tuition": 2.75},
                 "skill fully visible": {"visibility": 1}}
    writer = csv.DictWriter(sys.stdout, ["scenario", "mechanism", *run("signaling")])
    writer.writeheader()
    for scenario, changes in scenarios.items():
        for mechanism in ("human_capital", "signaling"):
            writer.writerow(dict(scenario=scenario, mechanism=mechanism, **run(mechanism, **changes)))
