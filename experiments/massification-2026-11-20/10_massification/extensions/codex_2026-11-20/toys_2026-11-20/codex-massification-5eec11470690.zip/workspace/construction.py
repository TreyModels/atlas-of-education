"""Matched policy comparisons, with the first 30 seeds shared with diffusion.csv."""
import csv
from itertools import product
from pathlib import Path
from statistics import mean
from diffusion import run

def main():
    with Path(__file__).with_suffix('.csv').open('w', newline='') as report:
        writer = csv.writer(report)
        writer.writerow('rural_cost reserve cohort district level outcome with_fee no_tuition paired_delta seeds_lower seeds_equal seeds_higher'.split())
        for cost, reserve in product((1, 2), (False, True)):
            values = {}
            for seed in range(100):
                options = dict(rural_cost=cost, reserve=reserve, periods=60)
                for a,b in zip(run(seed, **options), run(seed, fee=0, **options), strict=True):
                    assert a[:3] == b[:3]
                    if a[0] not in (10, 30, 60):
                        continue
                    metrics = [('seats',3), ('applications',4), ('completions',5), ('low_income_completions',6)]
                    if a[2]=='primary':
                        metrics += [('formal_jobs',7), ('output',8)]
                    for label,i in metrics:
                        values.setdefault((*a[:3], label), []).append((a[i],b[i]))
            for key,pairs in values.items():
                old,new = zip(*pairs)
                diff = [y-x for x,y in pairs]
                writer.writerow([cost,reserve,*key,round(mean(old),3),round(mean(new),3),round(mean(diff),3),
                                 sum(x<0 for x in diff),diff.count(0),sum(x>0 for x in diff)])

if __name__=='__main__':
    main()
