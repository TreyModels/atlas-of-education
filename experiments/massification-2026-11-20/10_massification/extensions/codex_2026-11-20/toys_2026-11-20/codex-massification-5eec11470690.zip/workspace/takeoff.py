"""Successive cohorts of 120, three sequential credentials. Stylized units.
Each cohort passes the gates within one step, then enters the labor market.
Parents observe last cohort's jobs and screening practice. Administrative
demand for basic literacy seeds schooling. Cash and foregone work constrain it.
Seat construction has one cohort of delay. Installed places persist.
"""
import csv
import random
from pathlib import Path

N = 120
LEVELS = ('primary', 'secondary', 'tertiary')
SCENARIOS = {
    'baseline': {}, 'costly_youth_work': {'work': 2},
    'weak_state': {'build_limit': 2}, 'no_complement': {'capital': 0},
    'mandate_only': {'mandate': True}, 'funded_push': {'push': True},
    'apprenticeship_only': {'schools': False, 'craft': True},
    'no_skill_route': {'schools': False},
}


def simulate(seed, work=1, build_limit=12, capital=1, mandate=False,
             push=False, schools=True, craft=False):
    seats = [18 if schools else 0, 0, 0]
    formal_share, readers, skill_stock = .10, .05, 0.
    for t in range(30):
        rng = random.Random(seed * 100 + t)
        # Paired potential cohorts, equal numbers in each resource group.
        group = [i % 3 for i in range(N)]
        cash = [(.24, .62, 1.05)[g] + rng.uniform(0, .5) for g in group]
        home_work = [(.65, .42, .25)[g] * rng.uniform(.45, 1.55) for g in group]
        aptitude = [rng.random() for _ in group]
        lottery = list(range(N))
        rng.shuffle(lottery)
        stage = [0] * N
        skill = [0.] * N
        rows, backlog = [], []
        previous_jobs = formal_share
        for k, level in enumerate(LEVELS):
            compelled = k == 0 and (mandate or (push and t < 4))
            # A funded four-cohort intervention builds permanent primary rooms.
            if push and t == 0 and k == 0:
                seats[0] = N
            fee = (.20, .36, .55)[k]
            eligible = [i for i in lottery if stage[i] == k]
            applicants = []
            for i in eligible:
                cost = home_work[i] * (.85, 1.35, 1.8)[k] * work
                skill_payoff = (.65, .51, .42)[k] * (.7 + aptitude[i])
                # Existing civil/market readers give the first credential a use.
                access = (.14, .90, .30)[k] * (1 if k == 0 else readers * previous_jobs * 5)
                rank = (.05, .20, .65)[k] * readers * previous_jobs * 4
                if cash[i] >= fee and (compelled or skill_payoff + access + rank >= fee + cost):
                    applicants.append(i)
            admitted = applicants[:seats[k]]
            for i in admitted:
                stage[i] += 1
                skill[i] += (.25, .40, .60)[k]
            backlog.append(len(applicants) - len(admitted))
            rows.append(dict(cohort=t+1, level=level, eligible=len(eligible),
                             seats=seats[k], applications=len(applicants), completions=len(admitted),
                             poor=sum(group[i]==0 for i in admitted),
                             middle=sum(group[i]==1 for i in admitted),
                             affluent=sum(group[i]==2 for i in admitted)))
            assert len(admitted) <= min(seats[k], len(applicants)) <= len(eligible)
        if craft:
            for i in lottery[:30]:
                skill[i] += .75
        # 20% workforce turnover. Formal capital employs skilled workers,
        # including apprentices. Skill mismatches can leave some posts vacant.
        skill_stock = .80 * skill_stock + .20 * sum(skill) / N
        posts = min(N, round(N * (.10 + .52 * capital * skill_stock)))
        readers = .05 + .85 * sum(s >= 2 for s in stage) / N
        gated = round(posts * readers)
        ranked = sorted(lottery, key=lambda i: stage[i], reverse=True)
        credential_hires = [i for i in ranked if stage[i] >= 2][:gated]
        open_pool = sorted(set(lottery) - set(credential_hires), key=lambda i: aptitude[i])
        hires = set(credential_hires + open_pool[::-1][:posts-gated])
        formal_share = len(hires) / N
        output = sum(1 + .18 * s + (i in hires) * capital * (.45 + .85*s)
                     for i,s in enumerate(skill))
        for r in rows:
            r.update(formal_hires=len(hires), output=round(output, 2))
            yield r
        # Ration the common state construction budget by outstanding demand.
        budget = min(build_limit, 3 + int(len(hires)*.16)) if schools else 0
        for _ in range(budget):
            k = max(range(3), key=backlog.__getitem__)
            if not backlog[k]:
                break
            seats[k] += 1
            backlog[k] -= 1


if __name__ == '__main__':
    path = Path(__file__).with_name('takeoff.csv')
    with path.open('w', newline='') as f:
        writer = None
        for name, options in SCENARIOS.items():
            for seed in range(20):
                for result in simulate(seed, **options):
                    row = dict(scenario=name, seed=seed, **result)
                    if writer is None:
                        writer = csv.DictWriter(f, fieldnames=row)
                        writer.writeheader()
                    writer.writerow(row)
