"""Standalone extensions for the toy admissions model (stdlib only).

Run from the repository root: python3 outputs/toy/experiments.py
Writes outputs/toy/experiments.csv. Does not modify model.py.

Assumptions: cohorts have 100 people, paired across counterfactuals using
identical latent draws. A public seat is free in addition to the model's $1
public fee. Public admission uses a lottery among applicants. Private tuition
is $2; households can pay only up to budget and enroll only when gross value
minus opportunity cost covers tuition. Fixed-cost supply incurs $1 variable
cost and $12 fixed cost, with break-even tested in integer cents; divisible
supply has no fixed cost and serves every eligible overflow customer up to 30.
For repeated cohorts, the same latent cohort is exposed repeatedly, so rates
are within-cohort changes from accumulated skills, not fresh population
sampling. The human-capital treatment adds one skill unit per graduate each
period; signaling adds none. Exogenous willingness to apply is held at baseline
common demand, independent of mechanism and accumulated skill. The prep policy
adds no seats: it reallocates public lottery priority to advantaged applicants.
It is a pure selection treatment with no learning effect by construction.
"""
import csv
import random
from pathlib import Path

N = 100
PUBLIC_FEE_CENTS = 100
TUITION_CENTS = 200
VARIABLE_COST_CENTS = 100
FIXED_COST_CENTS = 1200
PRIVATE_CAPACITY = 30
SEED = 20261120
REPS = 500


def cohort(seed):
    rng = random.Random(seed)
    # Even budget split as in model.py; opportunity cost uniform on [0, 3.5).
    budgets = [1.5, 4.0] * (N // 2)
    rng.shuffle(budgets)
    costs = [3.5 * rng.random() for _ in range(N)]
    lottery = list(range(N))
    rng.shuffle(lottery)
    return budgets, costs, lottery


def demand(costs, premium=4.0):
    return [i for i, c in enumerate(costs) if premium - c >= 1.0]


def allocate(budgets, costs, lottery, seats, supply):
    applicants = demand(costs)
    public = [i for i in lottery if i in set(applicants)][:seats]
    waiting = [i for i in lottery if i in set(applicants)][len(public):]
    customers = [i for i in waiting if budgets[i] >= 2.0 and 4.0 - costs[i] >= 2.0]
    qty = min(PRIVATE_CAPACITY, len(customers))
    if supply == "fixed":
        # Integer cents eliminate the floating-point break-even ambiguity.
        enters = qty * (TUITION_CENTS - VARIABLE_COST_CENTS) >= FIXED_COST_CENTS
        private = customers[:qty] if enters else []
    elif supply == "divisible":
        private = customers[:qty]
    else:
        raise ValueError(supply)
    return applicants, public, private


def experiment_exit():
    losses = []
    loss_events = 0
    pair_count = 0
    for rep in range(REPS):
        b, c, l = cohort(SEED + rep)
        for seats in range(0, 61, 2):
            _, _, fixed = allocate(b, c, l, seats, "fixed")
            _, _, divisible = allocate(b, c, l, seats, "divisible")
            loss = len(divisible) - len(fixed)
            pair_count += 1
            loss_events += loss > 0
            losses.append(loss)
    return [
        row("exit_vs_divisible", "fixed_cost_exit", "all seat points x 500 paired cohorts",
            "admissions_loss_event_rate", loss_events, pair_count, loss_events / pair_count,
            "Denominator: 500 cohorts x 31 public-seat values; event means divisible admissions > fixed-cost admissions."),
        row("exit_vs_divisible", "fixed_cost_exit", "all seat points x 500 paired cohorts",
            "mean_admissions_loss", sum(losses), pair_count, sum(losses) / pair_count,
            "Admitted persons lost per paired cohort-seat observation; zero-loss observations included."),
        row("exit_vs_divisible", "fixed_cost_exit", "conditional on loss event",
            "mean_loss_when_positive", sum(losses), loss_events, sum(losses) / loss_events,
            "Admitted persons, conditional on a positive loss; denominator is positive-loss observations."),
    ]


def experiment_expansion():
    rows = []
    seats_series = [20, 22, 24, 26, 28, 30]
    for mechanism in ("human_capital", "signaling"):
        b, c, l = cohort(SEED + 50000)
        applicants = demand(c)  # common imposed demand, fixed across both mechanisms
        current_skill = [0.0] * N
        for t, seats in enumerate(seats_series, 1):
            order = [i for i in l if i in set(applicants)]
            public = order[:seats]
            private = [i for i in order[seats:] if b[i] >= 2 and 4 - c[i] >= 2][:PRIVATE_CAPACITY]
            enrolled = set(public + private)
            if mechanism == "human_capital":
                current_skill = [s + (i in enrolled) for i, s in enumerate(current_skill)]
            rows.append(row("slow_public_expansion", mechanism, f"period {t}; seats={seats}",
                            "imposed_public_seats", seats, 1, seats,
                            "Exogenous seat input; public admissions cannot exceed this count."))
            rows.append(row("slow_public_expansion", mechanism, f"period {t}; seats={seats}",
                            "imposed_common_demand", len(applicants), 1, len(applicants),
                            "Fixed applicant pool reused under both mechanisms; not inferred from enrolment."))
            rows.append(row("slow_public_expansion", mechanism, f"period {t}; seats={seats}",
                            "emergent_enrolment", len(enrolled), 1, len(enrolled),
                            "Realized public plus private admissions after eligibility, budget and capacity constraints."))
            rows.append(row("slow_public_expansion", mechanism, f"period {t}; seats={seats}",
                            "mean_skill", sum(current_skill), N, sum(current_skill) / N,
                            "Cumulative skill per person; only human-capital graduates gain one unit per period."))
    return rows


def experiment_prep():
    total_delta = low_delta = access_events = 0
    for rep in range(REPS):
        b, c, l = cohort(SEED + 100000 + rep)
        applicants = demand(c)
        adv = {i for i in range(N) if b[i] == 4.0}
        applicant_set = set(applicants)
        # Capacity-neutral priority applies only to public seats. Allocate
        # private admissions from each policy's own waiting list.
        no_prep_order = [i for i in l if i in applicant_set]
        prep_order = [i for i in sorted(l, key=lambda i: (i not in adv, l.index(i)))
                      if i in applicant_set]
        no_prep = no_prep_order[:30]
        prep = prep_order[:30]
        no_prep_wait = no_prep_order[len(no_prep):]
        prep_wait = prep_order[len(prep):]
        def private(wait):
            customers = [i for i in wait if b[i] >= 2.0 and 4.0 - c[i] >= 2.0]
            qty = min(PRIVATE_CAPACITY, len(customers))
            # Same provider and cents-based break-even rule as exit experiment.
            enters = qty * (TUITION_CENTS - VARIABLE_COST_CENTS) >= FIXED_COST_CENTS
            return customers[:qty] if enters else []
        no_prep_private, prep_private = private(no_prep_wait), private(prep_wait)
        no_prep_total = len(set(no_prep + no_prep_private))
        prep_total = len(set(prep + prep_private))
        assert len(no_prep) + len(no_prep_private) == no_prep_total
        assert len(prep) + len(prep_private) == prep_total
        low = {i for i in range(N) if b[i] == 1.5}
        total_delta += prep_total - no_prep_total
        low_delta += len(set(prep) & low) - len(set(no_prep) & low)
        access_events += len(set(prep) & low) < len(set(no_prep) & low)
    return [
        row("capacity_neutral_prep", "advantaged_priority", "30 public seats; 500 paired cohorts",
            "mean_total_admissions_delta", total_delta, REPS, total_delta / REPS,
            "Prep minus no-prep total public plus private admissions; 30 public seats; no learning effect."),
        row("capacity_neutral_prep", "advantaged_priority", "30 public seats; 500 paired cohorts",
            "mean_low_budget_access_delta", low_delta, REPS, low_delta / REPS,
            "Prep minus no-prep low-budget public admissions; low budget is $1.50."),
        row("capacity_neutral_prep", "advantaged_priority", "30 public seats; 500 paired cohorts",
            "low_budget_access_loss_rate", access_events, REPS, access_events / REPS,
            "Denominator: 500 paired cohorts; share where low-budget public admissions fall under prep."),
    ]


def row(experiment, treatment, scope, metric, numerator, denominator, value, definition):
    return dict(experiment=experiment, treatment=treatment, scope=scope, metric=metric,
                numerator=numerator, denominator=denominator, value=f"{value:.6f}", definition=definition)


def validate(rows):
    assert all(int(r["denominator"]) > 0 for r in rows)
    assert all(float(r["value"]) >= 0 for r in rows if "delta" not in r["metric"])
    assert REPS >= 100
    # Exact fee arithmetic invariant: 12 seats at $1 contribution break even.
    assert 12 * (TUITION_CENTS - VARIABLE_COST_CENTS) == FIXED_COST_CENTS


def main():
    rows = experiment_exit() + experiment_expansion() + experiment_prep()
    validate(rows)
    path = Path(__file__).with_name("experiments.csv")
    with path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    print(f"wrote {path} ({len(rows)} result rows)")


if __name__ == "__main__":
    main()
