"""Boundary and comparative-static tests for the seeded admissions model."""
import unittest

from model import run


class AdmissionsBoundaryTests(unittest.TestCase):
    def test_provider_exit_is_seat_by_seat_when_revenue_crosses_fixed_cost(self):
        baseline = run("signaling", public_seats=30, tuition=2)
        just_before_exit = run("signaling", public_seats=38, tuition=2)
        at_exit = run("signaling", public_seats=39, tuition=2)
        self.assertTrue(baseline["private_entry"])
        self.assertEqual(baseline["private_admissions"], 15)
        self.assertEqual(just_before_exit["private_admissions"], 12)
        self.assertTrue(just_before_exit["private_entry"])
        self.assertFalse(at_exit["private_entry"])
        self.assertEqual(at_exit["private_admissions"], 0)
        self.assertEqual(at_exit["admissions"], 39)

    @unittest.expectedFailure
    def test_decimal_break_even_should_allow_entry(self):
        # With 30 sales the decimal margin at 1.40 covers the fixed cost.
        # Binary floating-point rounds the contribution just below 12.
        above = run("human_capital", public_seats=0, tuition=1.41)
        self.assertEqual(above["private_admissions"], 30)
        exact = run("human_capital", public_seats=0, tuition=1.40)
        self.assertTrue(exact["private_entry"])

    def test_tuition_customer_cutoff_changes_admissions_in_steps(self):
        lower = run("signaling", public_seats=0, tuition=2.1)
        upper = run("signaling", public_seats=0, tuition=2.2)
        self.assertEqual(lower["private_admissions"], 24)
        self.assertEqual(upper["private_admissions"], 23)
        self.assertTrue(lower["private_entry"] and upper["private_entry"])

    def test_signaling_demand_never_rises_with_visibility(self):
        visibilities = (0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1)
        applications = [run("signaling", visibility=v)["applications"]
                        for v in visibilities]
        self.assertEqual(applications, [89, 72, 57, 46, 36, 27, 14, 5, 0, 0, 0])
        self.assertTrue(all(a >= b for a, b in zip(applications, applications[1:])))

    def test_human_capital_hiring_is_invariant_to_partial_visibility(self):
        # All graduates rank ahead of non-graduates for every visibility here:
        # skill gains offset the visible-skill term, so the top 40 hires remain
        # graduates even though the scoring rule changes.
        for visibility in (0, 0.25, 0.5, 0.75, 1):
            with self.subTest(visibility=visibility):
                r = run("human_capital", visibility=visibility)
                self.assertEqual(r["admissions"], 45)
                self.assertEqual(r["hires"], 40)
                self.assertEqual(r["graduate_hires"], 40)

    def test_signaling_hiring_changes_at_visibility_cutoff(self):
        hidden = run("signaling", visibility=0)
        partly_visible = run("signaling", visibility=0.25)
        self.assertEqual(hidden["graduate_hires"], 40)
        self.assertEqual(partly_visible["graduate_hires"], 30)
        self.assertEqual(partly_visible["admissions"], 30)

    def test_all_public_seats_admit_only_applicants_and_eliminate_private_market(self):
        all_seats = run("signaling", public_seats=100)
        self.assertEqual(all_seats["public_admissions"], all_seats["applications"])
        self.assertEqual(all_seats["unmet"], 0)
        self.assertFalse(all_seats["private_entry"])
        self.assertEqual(all_seats["private_admissions"], 0)

    def test_zero_value_fee_boundary_has_no_applicants_under_signaling(self):
        # With full employer visibility the signaling premium is zero, below
        # the public fee, so no applicant receives a positive net value.
        r = run("signaling", visibility=1)
        self.assertEqual(r["applications"], 0)
        self.assertEqual(r["admissions"], 0)
        self.assertEqual(r["graduate_hires"], 0)


if __name__ == "__main__":
    unittest.main()
