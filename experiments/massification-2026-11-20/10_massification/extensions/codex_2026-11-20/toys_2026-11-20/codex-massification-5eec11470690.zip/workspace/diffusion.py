"""Urban elite schooling and geographic diffusion. Python 3, no dependencies.
Each district has 60 children per entering cohort, 20 per resource tier.
Costs and output are illustrative units. Completion follows admission.
Adult jobs are local; portability of the urban credential informs rural choices.
Schools persist. Unserved applicants compete for the state's common building
budget. A rural seat costs twice as much to build. No dated seat schedule.
"""
import csv
import random
from pathlib import Path

ARMS = {'baseline': {}, 'tuition_free': {'fee': 0}, 'cash_costs_covered': {'fee': 0, 'cover': True},
        'frozen_capacity': {'freeze': True}, 'no_investment': {'capital': 0},
        'frozen_no_investment': {'freeze': True, 'capital': 0},
        'no_urban_information': {'spill': 0}}


def run(seed, fee=.19, cover=False, freeze=False, capital=1, spill=.5,
        rural_cost=2, reserve=False, periods=30):
    seats = [16, 6, 2, 0, 0, 0]
    jobs = [.23, .08]
    educated = [.2, .02]
    workforce_skill = [.22, .08]
    for t in range(periods):
        rng = random.Random(seed * 100 + t)
        gap = []
        metrics = []
        for d in range(2):
            ids = list(range(60))
            rng.shuffle(ids)
            skill = [0.] * 60
            aptitude = [rng.random() for _ in ids]
            cash = [.25 + .34*(i % 3) + .28*rng.random() for i in range(60)]
            work = [(.64 - .16*(i % 3))*(.5 + rng.random())*(1 + .35*d) for i in range(60)]
            prior = ids
            signal = jobs[d] + d*spill*max(0, jobs[0]-jobs[1])
            snapshot = []
            for k in range(3):
                j = 3*d + k
                # A new nearby school lowers travel costs; a founding queue can
                # include families willing to travel until provision is local.
                travel = (.06 + .23*d)/(1 + seats[j]/15)
                cost = fee + (0 if cover else .10 + travel)
                applicants = []
                for i in prior:
                    productivity = (.43 + .33*aptitude[i]) * (1 + .35*capital)
                    eligibility = (.18, .5, .26)[k] * (signal + educated[d])
                    rank = (.04, .15, .58)[k] * educated[d]
                    value = productivity + eligibility + rank
                    if cash[i] >= cost and value >= cost + work[i]*(.72, 1.1, 1.6)[k]:
                        applicants.append(i)
                # Inherited elite tracks initially privilege affluent candidates.
                # Existing exclusive places retain priority; new seats use lottery.
                legacy = (16, 6, 2)[k] if not d else 0
                elite = [i for i in applicants if i % 3 == 2][:legacy]
                remaining = [i for i in applicants if i not in elite]
                admitted = elite + remaining[:seats[j]-len(elite)]
                assert len(admitted) <= min(len(applicants), seats[j])
                gap.append(len(applicants)-len(admitted))
                snapshot.append((len(applicants), len(admitted), sum(i%3==0 for i in admitted)))
                for i in admitted:
                    skill[i] += (.24, .38, .60)[k]
                prior = admitted
            metrics.append((snapshot, sum(skill)/60))
        # Use old workforce stocks for current output. New cohorts enter next period.
        total_hires = 0
        for d, (snapshot, new_skill) in enumerate(metrics):
            hires = min(60, round(60*jobs[d]))
            total_hires += hires
            output = 60*(1+.20*workforce_skill[d]) + hires*capital*(.5+.9*workforce_skill[d])
            for k,(apps,n,poor) in enumerate(snapshot):
                yield (t+1, ('urban','rural')[d], ('primary','secondary','tertiary')[k],
                       seats[3*d+k],apps,n,poor,hires,round(output,3))
            workforce_skill[d] = .8*workforce_skill[d] + .2*new_skill
            educated[d] = .8*educated[d] + .2*snapshot[1][1]/60
            jobs[d] = min(1, (.18,.06)[d] + capital*(.08+.55*workforce_skill[d]))
        budget = 0 if freeze else 4 + total_hires//10
        costs = [1] * 3 + [rural_cost] * 3
        # First claim on the existing budget: one requested rural secondary seat.
        if reserve and gap[4] and budget >= rural_cost:
            seats[4] += 1
            gap[4] -= 1
            budget -= rural_cost
        while budget:
            feasible = [j for j in range(6) if gap[j] and budget >= costs[j]]
            if not feasible:
                break
            j = max(feasible, key=lambda j: gap[j]/costs[j])
            seats[j] += 1
            gap[j] -= 1
            budget -= costs[j]


if __name__ == '__main__':
    with Path(__file__).with_suffix('.csv').open('w', newline='') as f:
        w = csv.writer(f)
        w.writerow('scenario seed cohort district level seats applications completions lowest_income_completions formal_jobs output'.split())
        for name, opts in ARMS.items():
            for seed in range(30):
                for row in run(seed, **opts):
                    w.writerow((name, seed, *row))
