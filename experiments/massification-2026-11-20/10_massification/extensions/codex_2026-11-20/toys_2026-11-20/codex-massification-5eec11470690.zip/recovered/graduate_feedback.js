function simulate(seed,pulse,visible,enterprise){
let s=seed;function rand(){s=(Math.imul(1664525,s)+1013904223)>>>0;return s/4294967296}
const n=60, ids=Array.from({length:n},(_,i)=>i);
const cost=ids.map(i=>.27+.15*(2-i%3)+(rand()-.5)*.34), cash=ids.map(i=>.25+.18*(i%3)+(rand()-.5)*.28);
let seats=10, belief=.18, stock=0, result=[];
for(let t=1;t<=20;t++){
 let draw=ids.map(()=>rand()),merit=ids.map(()=>rand()),shock=ids.map(()=>.2*(rand()-.5));
 let apps=ids.filter(i=>cash[i]>=.22&&.28+belief+shock[i]>=cost[i]).sort((a,b)=>draw[a]-draw[b]);
 let g=new Set(apps.slice(0,seats)), jobs=8+(enterprise?Math.min(12,Math.floor(stock/2)):0);
 let reserved=pulse&&t===1?[...g].sort((a,b)=>merit[b]-merit[a]).slice(0,4):[];
 let rank=i=>merit[i]+.18*g.has(i);
 let hired=reserved.concat(ids.filter(i=>!reserved.includes(i)).sort((a,b)=>rank(b)-rank(a)).slice(0,jobs-reserved.length));
 let gh=hired.filter(i=>g.has(i)).length;
 if(hired.length!==jobs||new Set(hired).size!==jobs||g.size>seats)throw Error('accounting');
 result.push([apps.length,apps.filter(i=>i%3===0).length,g.size,gh,jobs-gh,jobs,60+.75*jobs+.16*g.size+.35*gh]);
 let gap=(gh+1)/(g.size+2)-(jobs-gh+1)/(60-g.size+2);
 if(visible)belief=.55*belief+.45*gap;
 stock=.8*stock+.2*g.size;seats=Math.min(60,seats+Math.min(3,Math.floor((apps.length-g.size)/3)));
}return result}
for(const v of [0,1])for(const e of [0,1])for(const p of [0,1]){const sums=Array.from({length:20},()=>Array(7).fill(0));for(let seed=1;seed<=200;seed++)simulate(seed,p,v,e).forEach((r,t)=>r.forEach((x,j)=>sums[t][j]+=x));sums.forEach((r,t)=>console.log([v,e,p,t+1,...r.map(x=>x/200)].join(',')))}
