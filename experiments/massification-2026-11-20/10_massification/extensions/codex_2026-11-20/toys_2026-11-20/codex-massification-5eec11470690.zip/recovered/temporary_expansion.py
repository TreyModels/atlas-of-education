"""Run with Python 3. Differences are pulse minus control per entering cohort."""
import random
from statistics import mean

def run(seed, theory, pulse):
    rng = random.Random(seed)
    belief = 0.40
    skills = 10.0
    results = []
    for cohort in range(1, 21):
        active = pulse and 2 <= cohort <= 4
        # Same temporary fee waiver + twelve leased seats in every theory.
        seats = 12 + 12 * active
        fees = 0 if active else 0.18
        expected = 0.65 + (belief - 0.40 if theory != "supply" else 0)
        costs = [rng.random() for _ in range(60)]
        apps = sum(expected >= c + fees for c in costs)
        enrolled = min(seats, apps)
        posts = 6 if theory != "enterprise" else max(0, round(6 + .55*(skills-10)))
        hires = min(posts,enrolled)
        assert 0 <= hires <= min(posts,enrolled) and enrolled <= min(seats,apps)
        results.append((apps,enrolled,posts,hires))
        # Learn from placement probability among graduates with a weak prior.
        belief = .6*belief + .4*(hires+1)/(enrolled+2)
        skills = .75*skills + .25*enrolled
    return results

for theory in ("supply","learning","enterprise"):
    pairs = [(run(s,theory,True),run(s,theory,False)) for s in range(200)]
    for start,end in ((2,4),(5,7),(8,12),(16,20)):
        diff = [mean(a[t][i]-b[t][i] for a,b in pairs for t in range(start-1,end)) for i in range(4)]
        print(theory,start,end,*[round(x,3) for x in diff])
