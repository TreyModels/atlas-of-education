#!/usr/bin/env python3
"""Four seeded, mechanism-focused education policy simulations; standard library only."""
import csv, random
from pathlib import Path

OUT = Path(__file__).with_suffix('.csv')
RNG = random.Random(601206)


def pct(n, d):
    return 100.0 * n / d if d else 0.0


def fee_abolition():
    """Matched applicant cohorts and a school-level fee/replacement ledger."""
    rows=[]; schools=24; pupils=100; fee=20; costs=1500
    # Common underlying willingness and fee-barrier draws across all policies.
    people=[]
    for school in range(schools):
        cohort=[]
        for _ in range(pupils):
            wealth=RNG.random(); willing_draw=RNG.random(); barrier_draw=RNG.random(); quality=RNG.random(); att=RNG.random(); comp=RNG.random()
            cohort.append((wealth,willing_draw,barrier_draw,quality,att,comp))
        people.append(cohort)
    arms=[('fees_retained',1.0,True),('abolished_full_replacement',1.0,False),
          ('abolished_delayed_replacement',.5,False),('abolished_zero_replacement',0.0,False)]
    baseline_receipts=[]
    for school, cohort in enumerate(people):
        count=sum(wd < (.78 if w<.35 else .96) and not (w<.35 and bd<.46) for w,wd,bd,*_ in cohort)
        baseline_receipts.append(fee*count*.70)
    common_base_grant=costs-sum(baseline_receipts)/schools
    for arm,repl,fees_on in arms:
        applied=poor_apps=admitted=attend=complete=lost=shortfall=0; cash_total=fee_total=grant_total=0
        for si,cohort in enumerate(people):
            eligible=[]
            for w,wd,bd,q,ad,cd in cohort:
                willing=wd < (.78 if w<.35 else .96)
                barrier=fees_on and w<.35 and bd<.46
                if willing and not barrier:
                    applied+=1; poor_apps+=w<.35; eligible.append((w,q,ad,cd))
            fees=baseline_receipts[si] if fees_on else 0.0
            # Actual fee receipts lost are replaced per school at full/delayed/none rate;
            # common grant is policy invariant, so retained-fee arm receives it too.
            lost_receipts=baseline_receipts[si] if not fees_on else 0.0
            replacement=lost_receipts*repl
            grant=common_base_grant
            cash=fees+replacement+grant
            fee_total+=fees; grant_total+=replacement+grant; cash_total+=cash
            gap=max(0,costs-cash); shortfall+=gap
            instructors=max(0,round(6*(1-min(1,gap/costs)))); lost+=6-instructors
            ratio=instructors/6
            for w,q,ad,cd in eligible:
                admitted+=1
                p_att=.83+(.05 if not fees_on and w<.35 else 0)
                if ad<p_att*ratio:
                    attend+=1
                    if cd<.72*ratio: complete+=1
        rows.append(dict(experiment='1_fee_ledger',arm=arm,schools=schools,applications=applied,
            cash_poor_applications=poor_apps,instructors_lost=lost,
            attendance_rate_pct=round(pct(attend,admitted),1),completion_rate_pct=round(pct(complete,admitted),1),
            mean_school_shortfall=round(shortfall/schools,1),usable_seats='',learning='',
            fee_receipts=round(fee_total,1),replacement_and_base_grants=round(grant_total,1),
            total_program_cash=round(cash_total,1),baseline_fee_receipts=round(sum(baseline_receipts),1),
            lost_receipts_replaced=round(sum(baseline_receipts)*repl if not fees_on else 0,1)))
    return rows


def child_work_calendar():
    rows=[]; n=2400; unit_cost=100
    households=[]
    for i in range(n):
        resource=RNG.random(); baseline=RNG.random(); time_value=RNG.random(); later=RNG.random()
        households.append((resource,baseline,time_value,later))
    # Equal program budgets: each policy gets 2400 budget units. The calendar's
    # cost is rescheduling instruction; cash uses the same budget as transfers.
    for arm in ('rigid_terms','flexible_terms','equal_cost_cash_transfer'):
        peak=outside=returned=0; poor_peak=poor_n=rich_peak=rich_n=0
        budget=2400*unit_cost; spent=budget
        for resource,draw,time_value,later in households:
            poor=resource<.40
            liquidity=.18 if poor else .06
            if arm=='equal_cost_cash_transfer': liquidity=max(0,liquidity-.14)
            missed_prob=min(.88,.12+.52*time_value+liquidity+(.12 if poor else 0))
            if arm=='equal_cost_cash_transfer': missed_prob=min(.88,missed_prob+.13*time_value)
            missed=draw<missed_prob
            shifted=False
            if arm=='flexible_terms' and missed:
                shifted=later < .70
                missed=not shifted
            if not missed: peak+=1
            outside+=shifted
            ret_prob=.70+(.12 if arm=='flexible_terms' else 0)+(.10 if arm=='equal_cost_cash_transfer' and poor else 0)
            returned += (not missed) or (later<ret_prob)
            if poor: poor_n+=1; poor_peak+=not missed
            else: rich_n+=1; rich_peak+=not missed
        rows.append(dict(experiment='2_child_work_calendar',arm=arm,households=n,applications='',
            cash_poor_attendance_including_makeup_pct=round(pct(poor_peak,poor_n),1),cash_rich_attendance_including_makeup_pct=round(pct(rich_peak,rich_n),1),
            attendance_including_makeup_pct=round(pct(peak,n),1),later_return_pct=round(pct(returned,n),1),
            outside_harvest_attendance_pct=round(pct(outside,n),1),program_budget=budget,program_spending=spent,
            instructors_lost='',mean_school_shortfall='',usable_seats='',learning=''))
    return rows


def alumni_information():
    """Existing completers seek jobs; the following cohort seeks school places."""
    rng = random.Random(6003)
    graduates = 600
    families = [(rng.random(), rng.random(), rng.random()) for _ in range(3000)]
    rows = []
    for info, opening, name in ((0,0,'control'),(1,0,'truthful_information_only'),
                                (0,1,'employer_opening_only'),(1,1,'information_plus_opening')):
        posts = 360 + 120*opening
        hires = min(posts, graduates)
        apps = [0,0,0]
        for distance, reach_draw, cost in families:
            group = 0 if distance < .2 else (1 if distance < .6 else 2)
            reached = info and reach_draw < (.95,.65,.25)[group]
            belief = hires/graduates if reached else .40
            apps[group] += cost < .10 + .60*belief
        seats = 900
        total = sum(apps)
        rows.append(dict(experiment='3_alumni_vs_opportunity', arm=name, families=len(families),
                         applications=total, rejected_pupils=max(0,total-seats), available_seats=seats,
                         placements=hires, vacancies=posts-hires, net_new_jobs=120*opening,
                         sibling_applications=apps[0],neighbor_applications=apps[1],distant_applications=apps[2]))
        assert hires <= posts and hires <= graduates and seats == 900
    return rows


def classrooms_teachers():
    rows=[]; districts=30; students=1200; budget=120
    # Every arm spends exactly 120 units. Mixed option allocates the same total
    # equally between rooms and annual salaries (60 each).
    plans=[('buildings_only',120,0,.55),('teacher_salaries_only',0,120,.55),
           ('buildings_and_salaries',60,60,.55),('buildings_and_salaries_high_rural_retention',60,60,.85)]
    for arm,room_spend,salary_spend,retention in plans:
        seat_sum=attend=learning=teachers=0
        for d in range(districts):
            rural=d<15
            new_rooms=room_spend//20
            hired=salary_spend//10
            retained=round(hired*(retention if rural else .90)); teachers+=retained
            physical_seats=300+new_rooms*30
            usable=min(students,physical_seats)
            seat_sum+=usable
            taught=min(usable,retained*30+180)
            for j in range(students):
                enrolled=j<usable; served=enrolled and j<taught
                if served and RNG.random()<(.78 if rural else .84):
                    attend+=1
                    if RNG.random()<(.58+.20*min(1,retained/12)): learning+=1
        rows.append(dict(experiment='4_classrooms_vs_teachers',arm=arm,districts=districts,
            applications='',cash_poor_applications='',attendance_rate_pct=round(pct(attend,students*districts),1),
            completion_rate_pct='',instructors_lost='',mean_school_shortfall='',usable_seats=seat_sum,
            retained_teachers=teachers,students_meeting_learning_threshold=learning,
            learning_rate_pct=round(pct(learning,students*districts),1),program_budget=budget,
            room_spending=room_spend,salary_spending=salary_spend,total_spending=room_spend+salary_spend,
            staffed_usable_seats=sum(min(students,300+(room_spend//20)*30, round((salary_spend//10)*(retention if d<15 else .90))*30+180) for d in range(districts))))
    return rows

def main():
    rows=fee_abolition()+child_work_calendar()+alumni_information()+classrooms_teachers()
    fields=['experiment','arm','schools','districts','households','families','applications','cash_poor_applications',
            'instructors_lost','attendance_rate_pct','attendance_including_makeup_pct','cash_poor_attendance_including_makeup_pct','cash_rich_attendance_including_makeup_pct',
            'completion_rate_pct','later_return_pct','mean_school_shortfall','usable_seats','retained_teachers',
            'students_meeting_learning_threshold','learning_rate_pct','rejected_pupils','placements','net_new_jobs',
            'neighbor_applications','distant_families','learning','fee_receipts','replacement_and_base_grants','total_program_cash','baseline_fee_receipts','lost_receipts_replaced','outside_harvest_attendance_pct','program_budget','program_spending','sibling_applications','distant_applications','available_seats','vacancies','room_spending','salary_spending','total_spending','staffed_usable_seats']
    with OUT.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(rows)
    # Structural sanity checks: arms, ranges, fixed jobs and capacity bounds.
    assert len(rows)==15
    e1=[r for r in rows if r['experiment']=='1_fee_ledger']
    assert len({r['applications'] for r in e1})>1 and all(r['cash_poor_applications']<=r['applications'] for r in e1)
    assert all(abs(r['total_program_cash']-r['fee_receipts']-r['replacement_and_base_grants'])<.11 for r in e1)
    e2=[r for r in rows if r['experiment']=='2_child_work_calendar']
    assert len({r['program_spending'] for r in e2})==1
    e4=[r for r in rows if r['experiment']=='4_classrooms_vs_teachers']
    assert all(r['total_spending']==r['program_budget'] for r in e4)
    assert all(r['staffed_usable_seats']<=r['usable_seats'] for r in e4)
    assert all(0<=float(r.get('attendance_rate_pct') or 0)<=100 for r in rows)
    assert all(int(r.get('usable_seats') or 0)<=36000 for r in rows)
    info=next(r for r in rows if r['arm']=='truthful_information_only')
    assert info['net_new_jobs']==0 and info['placements']<=360
    assert len({r['arm'] for r in rows if r['experiment']=='1_fee_ledger'})==4
    print(f'wrote {OUT} rows={len(rows)}')
    for r in rows:
        print(r['experiment'],r['arm'],{k:v for k,v in r.items() if k in ('applications','cash_poor_applications','instructors_lost','attendance_rate_pct','completion_rate_pct','later_return_pct','mean_school_shortfall','usable_seats','retained_teachers','learning_rate_pct','rejected_pupils','placements','net_new_jobs') and v!=''})
    print('sanity_checks=PASS')

if __name__=='__main__': main()
