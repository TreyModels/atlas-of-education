#!/usr/bin/env python3
"""Structural toy implementations for experiments 12–14 (synthetic, not a fit)."""
import csv
import math
import random
from collections import defaultdict
from pathlib import Path

OUT = Path(__file__).with_suffix('.csv')
SEED = 412
REPS = 400


def mean(xs):
    return sum(xs) / len(xs) if xs else 0.0


def sigmoid(x):
    return 1 / (1 + math.exp(-max(-30, min(30, x))))


def cohort(rng):
    """Fixed people and characteristics shared by all factorial arms."""
    people = []
    for pid in range(500):
        diploma = rng.random() < .34
        older = rng.random() < .27
        skill = rng.gauss(.55 + .26*diploma - .10*older, .22)
        people.append(dict(id=pid, diploma=diploma, older_diploma=older and diploma,
                           skill=skill, reservation=rng.uniform(72,112) + 6*older))
    return people


def labor_market(people, campus, capital, demand, rng):
    """Heterogeneous firms enter at expected-profit thresholds; jobs are rationed."""
    firms = []
    for fid in range(34):
        productivity = rng.uniform(.75, 1.55) + .13*demand + .08*campus
        fixed_cost, capital_cost = rng.uniform(28,100), rng.uniform(12,42)
        diploma_need = rng.random() < .43
        expected_revenue = productivity*(1+.30*capital)*(1+.48*demand)*280
        expected_wage_cost = 5*(58+7*demand)
        if expected_revenue-expected_wage_cost-fixed_cost-capital_cost*(1-capital) > 0:
            firms.append(dict(id=fid, productivity=productivity, diploma_need=diploma_need,
                              slots=rng.randint(3,10)))
    # Iterative clearing: excess labor demand raises wages, which rations posts.
    wage = 78 + 16*demand
    candidates = []
    for firm in firms:
        for p in people:
            cutoff = .68 if firm['diploma_need'] else .32
            # Campus expands credential access and skill; capital raises feasible capacity.
            if p['skill']+.32*campus >= cutoff:
                bid = 65+48*firm['productivity']*(p['skill']+.22*campus)+12*capital+9*demand
                candidates.append((bid, firm['id'], p))
    candidates.sort(key=lambda x: (x[0],-x[1],-x[2]['id']), reverse=True)
    desired = sum(f['slots'] for f in firms)
    labor_supply = len(people)
    wage = max(70,min(145,wage + 18*(desired-labor_supply*.30)/max(1,labor_supply*.30)))
    firm_by_id = {f['id']:f for f in firms}
    hired, counts = {}, defaultdict(int)
    # At a given wage, firms hire the highest-value eligible workers up to capacity.
    for bid, fid, p in candidates:
        if p['id'] in hired or bid < max(wage,p['reservation']):
            continue
        if counts[fid] < firm_by_id[fid]['slots']:
            hired[p['id']] = (fid,bid)
            counts[fid] += 1
    output = sum(firm_by_id[fid]['productivity']*(1+.3*capital)*(1+.2*campus)*wage for fid,_ in hired.values())
    tax = output*.11
    older_pop = sum(p['older_diploma'] for p in people)
    older_hired = sum(people[pid]['older_diploma'] for pid in hired)
    return dict(active_firms=len(firms), staffed_jobs=len(hired), output=output, tax=tax,
                wage=wage, older_diploma_employed=older_hired,
                older_diploma_employment_rate=older_hired/max(1,older_pop),
                older_diploma_population=older_pop)


def experiment12():
    arms={'baseline':(0,0,0),'campus_only':(1,0,0),'capital_only':(0,1,0),'demand_only':(0,0,1),
          'campus_capital':(1,1,0),'campus_demand':(1,0,1),'capital_demand':(0,1,1),
          'campus_capital_demand':(1,1,1)}
    samples=defaultdict(list)
    for rep in range(REPS):
        draw=random.Random(SEED+rep)
        people=cohort(draw)
        firm_seed=SEED*1000+rep
        for arm,(campus,capital,demand) in arms.items():
            samples[arm].append(labor_market(people,campus,capital,demand,random.Random(firm_seed)))
    return arms,samples


def district_panel(rng, allocation):
    districts=[]
    for _ in range(24):
        districts.append(dict(base=rng.uniform(55,155),growth=rng.uniform(.006,.035),
            pneed=rng.uniform(.25,1),sneed=rng.uniform(.10,.75),
            pcost=rng.uniform(10,28),scost=rng.uniform(18,42)))
    # Fixed annual district investment pool. Local retention assigns shares
    # by own receipts; central pooling by unmet need; outside grant per district.
    n=len(districts)
    balances=[0.0]*n
    primary=[None]*n
    secondary=[None]*n
    tax_gain=capital_cost=0.0
    annual_pool=84.0
    for year in range(1,16):
        baseline=[d['base']*(1+d['growth'])**year*.075 for d in districts]
        gain=[.075*(5.5*(py is not None)+12*(sy is not None))
              for py,sy in zip(primary,secondary)]
        receipts=[x+y for x,y in zip(baseline,gain)]
        tax_gain+=sum(gain)/1.04**year
        weights={'equal':[1.0]*n,'tax_match':receipts,
                 'need_weighted':[d['pneed']*(py is None)+d['sneed']*(sy is None)+.1
                                  for d,py,sy in zip(districts,primary,secondary)]}[allocation]
        shares=[annual_pool*w/sum(weights) for w in weights]
        assert abs(sum(shares)-annual_pool)<1e-8
        for i,d in enumerate(districts):
            balances[i]+=shares[i]
            if primary[i] is None and balances[i]>=d['pcost']:
                balances[i]-=d['pcost']; capital_cost+=d['pcost']/1.04**year; primary[i]=year
            if primary[i] is not None and secondary[i] is None and balances[i]>=d['scost']:
                balances[i]-=d['scost']; capital_cost+=d['scost']/1.04**year; secondary[i]=year
    return dict(transfer_budget=annual_pool*15,district_funds=annual_pool*15,
                primary_open=sum(x is not None for x in primary),secondary_open=sum(x is not None for x in secondary),
                actual_baseline_tax=mean(baseline),discounted_incremental_own_tax=tax_gain,
                discounted_construction_cost=capital_cost,discounted_net_vs_no_build=tax_gain-capital_cost)


def experiment13():
    arms=('equal','need_weighted','tax_match'); samples=defaultdict(list)
    for rep in range(REPS):
        for arm in arms:
            samples[arm].append(district_panel(random.Random(SEED*10+rep),arm))
    return arms,samples


def education_draw(rng,distance,fee,further):
    applicants=[]; feeders=[]; completers=[]
    for pid in range(600):
        income=rng.lognormvariate(3.7,.48)
        aptitude=rng.gauss(0,1)
        travel=rng.uniform(.1,1.6)*distance
        u1,u2,u3,u4=[rng.random() for _ in range(4)]
        if u1>=sigmoid(1.3+.38*aptitude-.72*travel-.045*fee): continue
        applicants.append(pid)
        if u2>=max(.05,min(.95,.79-.18*travel-.0025*fee)): continue
        if u3>=max(.02,min(.95,.61-.16*travel+.25*further)): continue
        feeders.append(pid)
        if u4<max(.01,min(.90,.24-.09*travel+.42*further)): completers.append(pid)
    return dict(applicants=len(applicants),feeder_progressors=len(feeders),observed_completers=len(completers))


def experiment14():
    arms={'baseline':(2,18,0),'distance_reduced':(.8,18,0),'fee_reduced':(2,3,0),
          'further_options_added':(2,18,.55),'combined':(.8,3,.55)}
    samples=defaultdict(list)
    for rep in range(REPS):
        for arm,(distance,fee,further) in arms.items():
            samples[arm].append(education_draw(random.Random(SEED*100+rep),distance,fee,further))
    # Per-rep costs and completers are paired against the same-seed baseline.
    costs={'distance_reduced':7.0,'fee_reduced':5.0,'further_options_added':10.0,'combined':22.0}
    for arm in arms:
        if arm=='baseline':
            samples[arm]=[dict(x,incremental_actual_cost=0.0,incremental_completers=0) for x in samples[arm]]
        else:
            samples[arm]=[dict(x,incremental_actual_cost=costs[arm],
                incremental_completers=x['observed_completers']-b['observed_completers'])
                for x,b in zip(samples[arm],samples['baseline'])]
    return arms,samples


def aggregate(exp,arms,samples,contrasts):
    rows=[]
    for arm in arms:
        for metric in samples[arm][0]:
            rows.append(dict(experiment=exp,arm=arm,metric=metric,
                             mean=round(mean([x[metric] for x in samples[arm]]),4),replications=REPS))
    for label,a,b in contrasts:
        metrics=sorted(set(samples[a][0])&set(samples[b][0]))
        for metric in metrics:
            if exp==14 and metric in ('incremental_actual_cost','incremental_completers'): continue
            delta=mean([x[metric]-y[metric] for x,y in zip(samples[a],samples[b])])
            rows.append(dict(experiment=exp,arm=label,metric='delta_'+metric,mean=round(delta,4),replications=REPS))
    if exp==14:
        for arm in arms:
            if arm=='baseline': continue
            cost=sum(x['incremental_actual_cost'] for x in samples[arm])
            extra=sum(x['incremental_completers'] for x in samples[arm])
            rows.append(dict(experiment=14,arm=arm,metric='cost_per_extra_observed_completer',
                             mean=round(cost/extra,4) if extra>0 else 'NA',replications=REPS))
    return rows


def main():
    rows=[]
    a12,s12=experiment12(); c12=[(f'{a}_vs_baseline',a,'baseline') for a in a12 if a!='baseline']
    rows+=aggregate(12,a12,s12,c12)
    a13,s13=experiment13(); c13=[(f'{a}_vs_equal',a,'equal') for a in a13 if a!='equal']
    rows+=aggregate(13,a13,s13,c13)
    a14,s14=experiment14(); c14=[(f'{a}_vs_baseline',a,'baseline') for a in a14 if a!='baseline']
    rows+=aggregate(14,a14,s14,c14)
    fields=['experiment','arm','metric','mean','replications']
    with OUT.open('w',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f,fieldnames=fields); writer.writeheader(); writer.writerows(rows)
    print(f'Wrote aggregate CSV: {OUT} ({len(rows)} rows; {REPS} matched replications; seed={SEED})')
    for exp,samples,contrasts in ((12,s12,c12),(13,s13,c13),(14,s14,c14)):
        print(f'\nEXPERIMENT {exp} contrasts (treated minus matched control):')
        for label,a,b in contrasts:
            for metric in sorted(set(samples[a][0])&set(samples[b][0])):
                if exp==14 and metric in ('incremental_actual_cost','incremental_completers'): continue
                delta=mean([x[metric]-y[metric] for x,y in zip(samples[a],samples[b])])
                print(f'  {label}: {metric}={delta:.3f}')
        if exp==14:
            for arm in a14:
                if arm=='baseline': continue
                cost=sum(x['incremental_actual_cost'] for x in samples[arm])
                extra=sum(x['incremental_completers'] for x in samples[arm])
                result=f'{cost/extra:.3f}' if extra>0 else 'NA'
                print(f'  {arm}: paired incremental cost={cost:.1f}, incremental completers={extra}, cost/extra={result}')
    print('\nSynthetic structural scenarios only; no historical fit is claimed.')


if __name__=='__main__': main()
