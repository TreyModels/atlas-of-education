"""Atlas 15 (Luna): preregister, then score an independent coarse holdout proxy.
Run: python3 -B outputs/toy/luna_batch5.py
No outcomes are used to choose predictions. Source rows are PIDS tabulations
held outside the model; this is a partial proxy, not a district history panel.
"""
import csv
from pathlib import Path

SRC = Path(__file__).with_name('pids_proxy_inputs.csv')
OUT = Path(__file__).with_suffix('.csv')

def load_proxy():
    rows=[]
    with SRC.open(newline='') as f:
        for r in csv.DictReader(f):
            if (r['indicator']=='mean_years_of_schooling' and r['period'] in ('cohort 1960-1964','cohort 1990-1994')
                and r['status']=='observed' and r['region'] in ('NCR','ARMM')):
                rows.append(r)
    # collapse sexes equally; published source values only
    out={}
    for reg in ('NCR','ARMM'):
        vals={p:[] for p in ('cohort 1960-1964','cohort 1990-1994')}
        for r in rows:
            if r['region']==reg: vals[r['period']].append(float(r['value']))
        out[reg]={p:sum(v)/len(v) for p,v in vals.items() if v}
    if any(len(out[r])!=2 for r in out): raise ValueError('proxy coverage incomplete')
    return out

def main():
    # Opening order cannot be scored using a change in mean schooling years.
    observed = load_proxy()
    with OUT.open('w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['region', 'mean_1960_64', 'mean_1990_94', 'change_years', 'opening_order_identified'])
        for region, periods in observed.items():
            early, late = periods['cohort 1960-1964'], periods['cohort 1990-1994']
            writer.writerow([region, round(early, 3), round(late, 3), round(late-early, 3), False])

if __name__ == '__main__':
    main()
