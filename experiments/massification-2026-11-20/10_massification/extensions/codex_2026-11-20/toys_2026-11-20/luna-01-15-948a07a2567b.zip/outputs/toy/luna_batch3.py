#!/usr/bin/env python3
"""Atlas toy simulations, batch 3 (IDs 9-11). Standard library only."""
import csv, math, random
from pathlib import Path

OUT = Path(__file__).with_suffix('.csv')
SEED = 6032026
REPS = 240
VILLAGES = 48


def sigmoid(x):
    return 1.0 / (1.0 + math.exp(-max(-30.0, min(30.0, x))))


def mean(xs):
    return sum(xs) / len(xs) if xs else 0.0


def add(rows, exp, intervention, control, outcomes, assumptions, checks):
    for metric, arm_values in outcomes.items():
        a, c = arm_values
        rows.append(dict(experiment=exp, intervention=intervention, matched_control=control,
                         metric=metric, intervention_mean=f'{mean(a):.4f}',
                         control_mean=f'{mean(c):.4f}',
                         effect=f'{mean(a)-mean(c):.4f}',
                         assumptions=assumptions, sanity_checks=checks))


def run9(rng, rows):
    # 48 matched village pairs per replication. Three independently assigned binary inputs.
    # Applications depend on own access, teacher supply, prestige diffusion, and kin network.
    for factor, (settings, control_label) in {
        'prestigious_neighbor': (dict(p=1, road=0, teachers=0), 'same village, prestige=0 road=0 teachers=0'),
        'road_access': (dict(p=0, road=1, teachers=0), 'same village, prestige=0 road=0 teachers=0'),
        'teacher_supply': (dict(p=0, road=0, teachers=1), 'same village, prestige=0 road=0 teachers=0'),
        'all_three': (dict(p=1, road=1, teachers=1), 'same village, all inputs=0'),
    }.items():
        # per replication matched settings on each village's common baseline attributes
        orders, local_apps, distant_apps, local_apps_c, distant_apps_c = [], [], [], [], []
        for _ in range(REPS * VILLAGES):
            distance = rng.random()  # continuous remoteness
            kin = rng.random() < 0.45
            ability = rng.gauss(0, 1)
            baseline = -0.55 - 0.8 * distance + 0.25 * ability
            # Neighbor prestige induces a network spillover, strongest for distant kin-linked villages.
            spill = settings['p'] * (0.25 + (0.6 if kin else 0.0) * distance)
            road_gain = settings['road'] * (0.95 * distance + 0.05)
            teacher_gain = settings['teachers'] * 0.75
            p_t = sigmoid(baseline + spill + road_gain + teacher_gain)
            p_c = sigmoid(baseline)
            n = 22
            app_t = sum(rng.random() < p_t for _ in range(n))
            app_c = sum(rng.random() < p_c for _ in range(n))
            # Opening order: local school opens earlier when expected demand and staffed access suffice.
            delay_t = max(0, round(4.5 - 1.8*p_t - 1.3*settings['teachers'] - 1.0*settings['road']))
            delay_c = max(0, round(4.5 - 1.8*p_c))
            orders.append((delay_t, delay_c))
            if distance > .65:
                (distant_apps if kin else local_apps).append(app_t)
                (distant_apps_c if kin else local_apps_c).append(app_c)
            else:
                local_apps.append(app_t); local_apps_c.append(app_c)
        label = factor
        out = {'applications_per_22_households': ([x for x in local_apps+distant_apps], [x for x in local_apps_c+distant_apps_c]),
               'opening_delay_years': ([x[0] for x in orders], [x[1] for x in orders]),
               'applications_distant_kin_villages': (distant_apps, distant_apps_c),
               'applications_other_villages': (local_apps, local_apps_c)}
        checks = 'applications in [0,22]; delay >=0; distant-kin and other strata partition simulated village observations'
        assumptions = 'Synthetic 22-household villages; logit application propensity; prestige spillover reaches kin-linked distant villages; roads reduce remoteness cost; staffing improves capacity/readiness; rounded demand-based opening delay.'
        add(rows, 9, label, control_label, out, assumptions, checks)
    # Factorial contrast for opening sequence among equal base villages, using actual fixed deterministic rule.


def run10(rng, rows):
    fields = ('targeted', 'placebo')
    # paired markets under demand shock vs no shock; providers have heterogeneous entry lags and fixed costs.
    for treatment in ('demand_shock', 'short_entry_delay', 'low_fixed_cost'):
        measures = {f'{f}_{m}': ([], []) for f in fields for m in ('applications','seats','licensed_completers','vacancies')}
        for _ in range(REPS * 36):
            base = rng.uniform(0.35, 0.75)
            field_scale = {'targeted': 1.0, 'placebo': 0.72}
            for field in fields:
                scale = field_scale[field]
                demand0 = 100 * base * scale
                shock = treatment == 'demand_shock' and field == 'targeted'
                demand_t = demand0 * (1.55 if shock else 1.0)
                demand_c = demand0
                delay_t = rng.randint(1, 4) if treatment == 'short_entry_delay' else rng.randint(3, 7)
                delay_c = rng.randint(3, 7)
                fixed_t = rng.uniform(18, 35) if treatment == 'low_fixed_cost' else rng.uniform(35, 60)
                fixed_c = rng.uniform(35, 60)
                # A provider enters when present value proxy of demand covers fixed cost.
                entry_t = max(0, round((demand_t * .55 - fixed_t) / 18)) if delay_t <= 4 else max(0, round((demand_t * .38 - fixed_t) / 24))
                entry_c = max(0, round((demand_c * .55 - fixed_c) / 18)) if delay_c <= 4 else max(0, round((demand_c * .38 - fixed_c) / 24))
                seats_t = max(0, entry_t) * 24
                seats_c = max(0, entry_c) * 24
                apps_t = max(0, round(demand_t * rng.uniform(.62,.82)))
                apps_c = max(0, round(demand_c * rng.uniform(.62,.82)))
                complete_t = min(seats_t, apps_t) * rng.uniform(.72,.88)
                complete_c = min(seats_c, apps_c) * rng.uniform(.72,.88)
                vac_t = max(0, round(demand_t - complete_t))
                vac_c = max(0, round(demand_c - complete_c))
                for m, v_t, v_c in [('applications',apps_t,apps_c),('seats',seats_t,seats_c),('licensed_completers',complete_t,complete_c),('vacancies',vac_t,vac_c)]:
                    measures[f'{field}_{m}'][0].append(v_t); measures[f'{field}_{m}'][1].append(v_c)
        add(rows, 10, treatment, 'matched occupation-market pair without this intervention', measures,
            'Synthetic paired occupation markets; target demand shock +55%; provider entry depends on expected enrollment relative to fixed cost and delay; seats=24 per entrant; completion=72–88% of filled seats; vacancy proxy=demand less completers.',
            'seats/completers/vacancies nonnegative; completers <= applications and seats; placebo field receives no targeted demand shock')


def run11(rng, rows):
    # Fixed cohort sizes and paired schools. Instruction improves latent skill; rank prep changes selection only.
    for selectivity in ('open', 'selective'):
        cutoff = 0.0 if selectivity == 'open' else 0.9
        for intervention in ('instructional_tutoring', 'rank_only_prep', 'both'):
            stats = {k:([],[]) for k in ('group_A_access_pct','group_B_access_pct','skills_rejected','skills_admitted','household_spend')}
            for _ in range(REPS * 40):
                people = []
                for i in range(80):
                    group_b = i >= 40
                    baseline = rng.gauss(0, 1) - (0.12 if group_b else 0)
                    instruction = intervention in ('instructional_tutoring','both') and rng.random() < (.55 if not group_b else .35)
                    rankprep = intervention in ('rank_only_prep','both') and rng.random() < (.60 if not group_b else .30)
                    skill = baseline + (0.75 if instruction else 0) + rng.gauss(0,.12)
                    rank = skill + (0.65 if rankprep else 0) + rng.gauss(0,.30)
                    spend = (30 if instruction else 0) + (24 if rankprep else 0)
                    people.append((group_b, skill, rank, spend))
                # matched control sampled from same baseline distribution and same selectivity
                controls = []
                for i in range(80):
                    group_b = i >= 40
                    skill = rng.gauss(0,1) - (0.12 if group_b else 0) + rng.gauss(0,.12)
                    controls.append((group_b,skill,skill+rng.gauss(0,.30),0))
                # capacity is 55% cohort at open gate, 30% at selective gate; ranking uses noisy score.
                cap = 44 if selectivity == 'open' else 24
                for dataset, slot in ((people,0),(controls,1)):
                    chosen = set(sorted(range(80), key=lambda j: dataset[j][2], reverse=True)[:cap])
                    rejected = [x for j,x in enumerate(dataset) if j not in chosen]
                    admitted = [x for j,x in enumerate(dataset) if j in chosen]
                    for g, key in ((False,'group_A_access_pct'),(True,'group_B_access_pct')):
                        n=sum(x[0]==g for x in dataset); got=sum(dataset[j][0]==g for j in chosen)
                        stats[key][slot].append(100*got/n)
                    stats['skills_rejected'][slot].append(mean([x[1] for x in rejected]))
                    stats['skills_admitted'][slot].append(mean([x[1] for x in admitted]))
                    stats['household_spend'][slot].append(mean([x[3] for x in dataset]))
            add(rows, 11, f'{intervention}; {selectivity} gate', 'matched cohort, no tutoring or rank preparation; same gate', stats,
                'Synthetic 80-person cohorts balanced by group; group B starts 0.12 skill SD lower; instructional tutoring adds 0.75 skill for participants; rank prep adds 0.65 to selection score only; participation rates differ by group; gate admits top 55%/30%.',
                'access percentages in [0,100]; admitted count fixed by gate; rank-only prep leaves latent skills unchanged except sampling noise; expenditure nonnegative')


def main():
    rng = random.Random(SEED)
    rows=[]
    run9(rng, rows); run10(rng, rows); run11(rng, rows)
    fields=['experiment','intervention','matched_control','metric','intervention_mean','control_mean','effect','assumptions','sanity_checks']
    with OUT.open('w', newline='', encoding='utf-8') as f:
        w=csv.DictWriter(f, fieldnames=fields); w.writeheader(); w.writerows(rows)
    print(f'wrote {OUT} rows={len(rows)} seed={SEED} replications={REPS}')
    for exp in (9,10,11):
        subset=[r for r in rows if int(r['experiment'])==exp]
        print(f'ID {exp}: {len(subset)} outcome contrasts')
        for r in subset:
            print(f"  {r['intervention']} | {r['metric']}: {r['intervention_mean']} vs {r['control_mean']} (effect {r['effect']})")

if __name__ == '__main__': main()
