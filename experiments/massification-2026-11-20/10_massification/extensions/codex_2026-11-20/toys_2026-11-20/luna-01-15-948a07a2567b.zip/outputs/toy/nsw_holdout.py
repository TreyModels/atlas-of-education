#!/usr/bin/env python3
"""Frozen historical opening-order subtest 15 (Luna worker).

Source: NSW Government Schools Register, supplied snapshot `work/nsw-schools.csv`.
Public register landing page: https://nswgovschoolhistory.azurewebsites.net/

Coding is exact normalized place name plus explicit `High School` classification.
For name coding, a school name may be the place followed by a High suffix, or may
include a gender suffix (e.g. Bathurst Boys High); recorded aliases allow a
renamed campus to match its place where its alias is explicitly `Place High`.
The event year is the earliest recorded start of an explicit High School class,
not the beginning of secondary instruction or Intermediate High School.
Frozen regional/companion pairs are not replaced. A known regional date wins
only when companion is missing; that pair is retained as censored and excluded
from hit/tie counts. A hit means regional starts >=5 years earlier; difference
of 0-4 is a tie; companion earlier by >=5 years is a miss.

Run: python3 outputs/toy/nsw_holdout.py [register.csv] [output.csv]
The output embeds exact candidate source rows as JSON for audit/reproduction if
the supplied register is unavailable later.
"""
from __future__ import annotations

import csv
import json
import re
import sys
from pathlib import Path

PAIRS = [
    ("Bathurst", "Kelso"),
    ("Goulburn", "Marulan"),
    ("Maitland", "Morpeth"),
    ("Dubbo", "Wellington"),
    ("Orange", "Millthorpe"),
    ("Tamworth", "Manilla"),
]
FIELDS = ["school_name", "other_names", "location_note", "county_name",
          "classification_desc", "start_month", "start_year", "end_month",
          "end_year", "transferred_to", "half_time_partner_school_id",
          "half_time_partner_school_name"]


def norm(s: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", s.casefold()).strip()


def candidate(place: str, row: dict[str, str]) -> bool:
    """Exact normalized place-name tokens, optionally followed by High etc."""
    p = norm(place)
    name = norm(row["school_name"])
    # Permit place, place high, place boys/girls high, and a recorded alias
    # exactly matching place + high (e.g. Dubbo High).
    acceptable = {p, p + " high", p + " boys high", p + " girls high"}
    if name in acceptable:
        return True
    for alias in re.split(r"[;*]+", row.get("other_names", "")):
        alias = norm(re.sub(r"\buntil\b.*$", "", alias).strip())
        if alias in {p + " high", p + " boys high", p + " girls high"}:
            return True
    return False


def year(row: dict[str, str]) -> int:
    return int(row["start_year"])


def main() -> None:
    source = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("work/nsw-schools.csv")
    output = Path(sys.argv[2]) if len(sys.argv) > 2 else Path("outputs/toy/nsw_holdout.csv")
    with source.open(encoding="utf-8-sig", newline="") as f:
        rows = list(csv.DictReader(f))
    results = []
    hits = ties = misses = missing = 0
    for regional, companion in PAIRS:
        found = {}
        for place in (regional, companion):
            found[place] = [r for r in rows
                            if norm(r["classification_desc"]) == "high school"
                            and candidate(place, r)]
        dates = {place: min((year(r) for r in found[place]), default=None)
                 for place in (regional, companion)}
        if dates[regional] is None or dates[companion] is None:
            outcome = "missing"
            missing += 1
        else:
            delta = dates[companion] - dates[regional]
            if delta >= 5:
                outcome = "hit"
                hits += 1
            elif delta >= 0:
                outcome = "tie"
                ties += 1
            else:
                outcome = "miss"
                misses += 1
        for place in (regional, companion):
            if not found[place]:
                # Add adjacent same-name records as transparent mismatch evidence
                # (not used as classified candidate and never used for date).
                adjacent = [r for r in rows if norm(r["school_name"]) in
                            {norm(place), norm(place + " high")}]
            else:
                adjacent = []
            results.append({
                "regional_centre": regional, "companion": companion,
                "place": place, "role": "regional" if place == regional else "companion",
                "first_explicit_high_school_year": dates[place],
                "candidate_record_count": len(found[place]),
                "candidate_source_records_json": json.dumps(found[place], ensure_ascii=False, separators=(",", ":")),
                "name_mismatch_records_json": json.dumps(adjacent, ensure_ascii=False, separators=(",", ":")),
                "pair_outcome": outcome,
            })
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(results[0]))
        w.writeheader()
        w.writerows(results)
    print(f"pairs={len(PAIRS)} hit={hits} tie={ties} miss={misses} missing/censored={missing}")
    for i in range(0, len(results), 2):
        a, b = results[i:i+2]
        print(f"{a['regional_centre']} ({a['first_explicit_high_school_year']}) vs "
              f"{b['companion']} ({b['first_explicit_high_school_year']}): {a['pair_outcome']}")
    print(f"wrote {output}")


if __name__ == "__main__":
    main()
