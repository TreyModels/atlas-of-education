#!/usr/bin/env python3
"""Luna batch 2: illustrative, paired synthetic counterfactuals, not forecasts."""
import csv
import math
import random
from pathlib import Path

SEED = 620251
N = 12000
OUT = Path(__file__).with_suffix('.csv')


def mean(xs):
    return sum(xs) / len(xs) if xs else 0.0


def run(seed=SEED):
    rng = random.Random(seed)
    rows = []

    def emit(exp, arm, control, metrics):
        for measure, value in metrics.items():
            rows.append(dict(experiment=exp, arm=arm, matched_control=control,
                             measure=measure, value=round(value, 4), n=N,
                             seed=seed, units='rate_or_index'))

    # Shared candidate characteristics and all offer-stage random numbers. A
    # compliant employer has no credential gate after repeal; waiver and
    # noncompliance remain explicit, separate processes before repeal.
    people = []
    for _ in range(N):
        skill = rng.gauss(0, 1)
        cred = int(skill + rng.gauss(0, 1) > .25)
        school = int(rng.random() < (.30 + .30 * cred))
        apply_draw, waiver_draw, compliance_draw, cb_draw, offer_draw = [rng.random() for _ in range(5)]
        noise = rng.gauss(0, .75)
        people.append((skill, cred, school, apply_draw, waiver_draw, compliance_draw,
                       cb_draw, offer_draw, noise))
    for repeal in (0, 1):
      for blind in (0, 1):
        callbacks = offers = apps = offered_school = app_school = 0
        uncred_apps = uncred_cb = uncred_offers = 0
        for skill, cred, school, ad, wd, cd, cbd, od, noise in people:
            if ad >= min(.95, max(.15, .55 + .12 * skill + .12 * repeal)):
                continue
            apps += 1; app_school += school
            uncred_apps += not cred
            waiver = (not cred and wd < .04)
            noncompliant = (not cred and not waiver and cd < .18)
            eligible = bool(cred) or repeal or waiver or noncompliant
            if not eligible: continue
            score = skill + (0 if blind else .32 * cred) + noise
            if cbd < 1 / (1 + math.exp(-score)):
                callbacks += 1; uncred_cb += not cred
                if od < 1 / (1 + math.exp(-(.25 * skill + .5))):
                    offers += 1; offered_school += school; uncred_offers += not cred
        emit('5', f'repeal={repeal};blind={blind}', f'repeal={1-repeal};blind={blind}', {
            'applications_per_100_people': apps/N*100,
            'callback_rate_per_application': callbacks/max(apps,1),
            'offer_rate_per_application': offers/max(apps,1),
            'offer_rate_schooling_siblings': offered_school/max(offers,1),
            'applicant_schooling_share': app_school/max(apps,1),
            'uncredentialed_applications_per_100_people': uncred_apps/N*100,
            'uncredentialed_callback_rate_per_application': uncred_cb/max(uncred_apps,1),
            'uncredentialed_offer_rate_per_application': uncred_offers/max(uncred_apps,1),
            'waiver_share_uncredentialed_applicants': sum(1 for p in people if (not p[1] and p[3] < min(.95,max(.15,.55+.12*p[0]+.12*repeal)) and p[5] < .04))/max(uncred_apps,1),
            'noncompliance_share_uncredentialed_applicants': sum(1 for p in people if (not p[1] and p[3] < min(.95,max(.15,.55+.12*p[0]+.12*repeal)) and p[5] >= .04 and p[6] < .18))/max(uncred_apps,1),
        })

    # Migration route is available to qualified workers preferentially. Origin
    # output counts only resident production; remittances are transfers. The
    # prospective sibling's schooling choice is distinct from past schooling.
    origins=[]
    for _ in range(N):
        sch = int(rng.random() < .58)
        prod = max(.2, rng.gauss(1, .24))
        job = int(rng.random() < .46)
        qualified = int(rng.random() < min(.96, .35 + .55*prod))
        md, sibling_draw = rng.random(), rng.random()
        origins.append((sch,prod,job,qualified,md,sibling_draw))
    for route in (0,1):
      for remit in (0,1):
        school_sum=output=earnings=resources=migcount=local_employed=0
        sibling_school=0
        for sch,prod,job,qualified,md,sd in origins:
            p=(.025 + .13*route) * (.78 if sch else 1.18)
            if route: p *= (1.65 if qualified else .45)
            migrant=md<p
            migcount+=migrant
            # Future sibling choice is a separate outcome; no rewriting of past schooling.
            sibling_p=min(.98,max(.02,.50 + .16*sch + .07*(remit and migrant)))
            sibling_school += sd < sibling_p
            school_sum+=sch
            local_employed+=bool(job and not migrant)
            output+=prod*(1.0 if not migrant else .62)
            mearn=2.1*prod if migrant else 0
            earnings+=mearn
            resources+=prod*(.72 if migrant else 1.0) + (mearn*.35 if remit and migrant else 0)
        emit('6',f'route={route};remittances={remit}',f'route={1-route};remittances={remit}',{
            'migration_share':migcount/N,'qualified_share_among_migrants':sum(1 for x in origins if x[4] < ((.025+.13*route)*(.78 if x[0] else 1.18)*(1.65 if x[3] else .45) if route else (.025+.13*route)*(.78 if x[0] else 1.18)))/max(migcount,1),
            'past_origin_schooling_share':school_sum/N,'next_cohort_sibling_school_choice_share':sibling_school/N,
            'local_resident_output_per_origin':output/N,'migrant_earnings_per_origin':earnings/N,
            'remittance_transfer_per_origin':earnings*.35/N if remit else 0,
            'household_resources_index_per_origin':resources/N,'local_employment_share':local_employed/N})

    # Pair all hiring draws by entrant and route; skill formation is identical.
    cohort=[]
    for _ in range(N): cohort.append((rng.gauss(0,1),rng.gauss(0,.22),rng.random()))
    for route in ('school','accredited','unaccredited'):
      for test in (0,1):
        skills=[]; hired=earn=output=0
        for aptitude,noise,draw in cohort:
            skill=aptitude*.55+noise+.55; skills.append(skill)
            score=(.9*skill+.16*aptitude if test else .52*skill+(.26 if route in ('school','accredited') else 0))
            got=draw < 1/(1+math.exp(-score))
            hired+=got
            wage=(1+.28*skill+(.08 if route=='accredited' else 0)) if got else .35
            earn+=wage; output+=max(.1,skill+.9)*(1 if got else .48)
        emit('7',f'route={route};employer_test={test}',f'route=school;employer_test={test}',{
            'skill_index':mean(skills),'hiring_access_rate':hired/N,
            'earnings_index_per_entrant':earn/N,'output_index_per_entrant':output/N,
            'skill_test_common_across_routes':float(test==1),
            'skill_formation_identical_across_routes':1.0})
    # Family route choice is measured under both accreditation states for the
    # same family draw and skill test; accreditation affects choice, not skill.
    fam=[(rng.random(),rng.gauss(0,1)) for _ in range(N)]
    for accredited in (0,1):
      chosen=0
      for draw,ability in fam:
        p=1/(1+math.exp(-(.1+.35*ability+.55*accredited)))
        chosen += draw<p
      emit('7',f'family_accreditation={accredited}',f'family_accreditation={1-accredited}',{
          'family_accredited_route_choice_share':chosen/N,
          'common_skill_test_applied':1.0,'common_skill_test_score_index':mean([a*.55+n+.55 for a,n,_ in cohort])})

    households=[]
    for _ in range(N): households.append((rng.random(),rng.random(),rng.random(),rng.random(),rng.random(),rng.random()))
    for reach in (0,1):
      for withdraw in (0,1):
       for transport in (0,1):
        regs=att=comp=work=nextreg=0
        for dist,need,idraw,adraw,cdraw,nraw in households:
            inspection=reach and idraw < (.82 if not withdraw else .16)
            to=transport and adraw<.78
            reg=idraw < min(.99,.46+.38*inspection+.26*to-.18*dist)
            attend=reg and adraw < max(.03,min(.98,.84-.44*dist+.18*inspection+.22*to-.16*need))
            complete=attend and cdraw < (.76-.20*dist+.10*inspection)
            household_work=need and (not attend or nraw < (.12+.18*dist))
            regs+=reg; att+=attend; comp+=complete; work+=household_work
            pnext=.34+.22*reg+.10*complete+.13*inspection+.12*to-.12*dist
            nextreg+=nraw<max(.02,min(.98,pnext))
        emit('8',f'reach={reach};withdraw={withdraw};transport={transport}',f'reach={1-reach};withdraw={withdraw};transport={transport}',{
            'registration_rate':regs/N,'attendance_rate_population':att/N,'completion_rate_population':comp/N,
            'household_work_rate':work/N,'next_cohort_registration_rate':nextreg/N})
    assert len(rows)==(4*10 + 4*9 + 6*6 + 2*3 + 8*5)
    for r in rows:
        assert math.isfinite(r['value'])
        if 'rate' in r['measure'] or 'share' in r['measure']:
            assert 0 <= r['value'] <= 1, r
    return rows

if __name__=='__main__':
    data=run()
    with OUT.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=data[0].keys()); w.writeheader(); w.writerows(data)
    print(f'wrote {len(data)} rows to {OUT}; seed={SEED}; n={N}; sanity checks passed')
